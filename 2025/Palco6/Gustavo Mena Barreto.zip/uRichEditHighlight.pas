unit uRichEditHighlight;

interface

uses
  System.SysUtils, System.Classes, Vcl.Controls, Vcl.ComCtrls, Vcl.Graphics, System.StrUtils, Winapi.Messages;

type
  TRichEditHighlight = class(TRichEdit)
  private
    FKeywords: TStrings;
    FUpdating: Boolean;
    FAutoHighlight: Boolean;
    FHighlightColor: TColor;
    procedure SetKeywords(const Value: TStrings);
    procedure DoHighlight;
  protected
    procedure Change; override;
  public
    constructor Create(AOwner: TComponent); override;
    destructor Destroy; override;
  published
    property Keywords: TStrings read FKeywords write SetKeywords;
    property AutoHighlight: Boolean read FAutoHighlight write FAutoHighlight default True;
    property HighlightColor: TColor read FHighlightColor write FHighlightColor default clRed;
  end;

procedure Register;

implementation

procedure Register;
begin
  RegisterComponents('MeusComponentes', [TRichEditHighlight]);
end;

{ TRichEditHighlight }

constructor TRichEditHighlight.Create(AOwner: TComponent);
begin
  inherited Create(AOwner);
  FKeywords := TStringList.Create;
  // Palavras-chave padr�o
  FKeywords.Add('begin');
  FKeywords.Add('end');
  FKeywords.Add('procedure');
  FKeywords.Add('class');

  FAutoHighlight := True;
  FHighlightColor := clRed;
  FUpdating := False;

  WordWrap := False;
end;

destructor TRichEditHighlight.Destroy;
begin
  FKeywords.Free;
  inherited;
end;

procedure TRichEditHighlight.SetKeywords(const Value: TStrings);
begin
  if Value = nil then
  begin
    FKeywords.Clear;
    Exit;
  end;
  FKeywords.Assign(Value);
  if AutoHighlight and HandleAllocated then
    DoHighlight;
end;

procedure TRichEditHighlight.Change;
begin
  inherited;
  if (csLoading in ComponentState) or not HandleAllocated then
    Exit;

  if AutoHighlight then
    DoHighlight;
end;

procedure TRichEditHighlight.DoHighlight;
var
  i, j, posInLine, lineStart: Integer;
  lineText, lowerLine, kw: string;
  origSelStart, origSelLength: Integer;
begin
  if FUpdating then Exit;
  if not HandleAllocated then Exit;

  FUpdating := True;
  try
    // salva sele��o atual
    origSelStart := SelStart;
    origSelLength := SelLength;

    Lines.BeginUpdate;
    try
      // reset atributos em todo o texto
      SelStart := 0;
      SelLength := Length(Text);
      if SelLength > 0 then
      begin
        SelAttributes.Color := clWindowText;
        SelAttributes.Style := [];
      end;

      // percorre linha a linha
      for i := 0 to Lines.Count - 1 do
      begin
        lineText := Lines[i];
        lowerLine := LowerCase(lineText);

        // posi��o real da linha no buffer
        lineStart := Perform(EM_LINEINDEX, i, 0);

        for j := 0 to FKeywords.Count - 1 do
        begin
          kw := FKeywords[j];
          if kw = '' then Continue;

          posInLine := PosEx(LowerCase(kw), lowerLine, 1);
          while posInLine > 0 do
          begin
            SelStart := lineStart + posInLine - 1;
            SelLength := Length(kw);
            SelAttributes.Color := FHighlightColor;
            SelAttributes.Style := [fsBold];

            posInLine := PosEx(LowerCase(kw), lowerLine, posInLine + Length(kw));
          end;
        end;
      end;
    finally
      Lines.EndUpdate;
    end;

    // restaura sele��o
    if origSelStart > Length(Text) then
      SelStart := Length(Text)
    else
      SelStart := origSelStart;
    SelLength := origSelLength;

  finally
    FUpdating := False;
  end;
end;

end.

