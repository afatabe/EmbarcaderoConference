unit Classe.MyWizard;

interface

uses
  ToolsAPI, Vcl.Menus;

type
  TMyOTAWizard = class(TNotifierObject, IOTAWizard)
  private
    FMenuItem: TMenuItem;
    procedure MenuItemClick(Sender: TOBject);

  public
    constructor Create;
    destructor Destroy; override;

    function GetIDString: string;
    function GetName: string;
    function GetState: TWizardState;
    procedure Execute;
  end;

implementation

uses
  SysUtils, Vcl.Dialogs;

{ TMyOTAWizard }

constructor TMyOTAWizard.Create;
var
  MainMenu: TMainMenu;
  ToolsMenuItem: TMenuItem;
begin
  inherited Create;

  MainMenu := (BorlandIDEServices as INTAServices).MainMenu;
  ToolsMenuItem := MainMenu.Items.Find('Tools');
  if Assigned(ToolsMenuItem) then
  begin
    FMenuItem := TMenuItem.Create(nil);
    FMenuItem.Caption := 'Embacardero Conference 2025';
    FMenuItem.OnClick := MenuItemClick;
    ToolsMenuItem.Add(FMenuItem);
  end;
end;

destructor TMyOTAWizard.Destroy;
begin
  FMenuItem.Free;
  inherited Destroy;
end;

procedure TMyOTAWizard.Execute;
begin
  Showmessage('Econ2025');
end;

function TMyOTAWizard.GetIDString: string;
begin
  Result := 'Embarcadero';
end;

function TMyOTAWizard.GetName: string;
begin
  Result := 'Gustavo';
end;

function TMyOTAWizard.GetState: TWizardState;
begin
  Result := [wsEnabled];
end;

procedure TMyOTAWizard.MenuItemClick(Sender: TOBject);
begin
  Showmessage('Wizard Econ2025');
end;

initialization
  RegisterPackageWizard(TMyOTAWizard.Create);

end.
