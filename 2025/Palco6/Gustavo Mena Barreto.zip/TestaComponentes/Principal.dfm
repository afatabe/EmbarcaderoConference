object Form1: TForm1
  Left = 0
  Top = 0
  Caption = 'Form1'
  ClientHeight = 441
  ClientWidth = 624
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -12
  Font.Name = 'Segoe UI'
  Font.Style = []
  TextHeight = 15
  object RichEditHighlight1: TRichEditHighlight
    Left = 0
    Top = 0
    Width = 624
    Height = 441
    Align = alClient
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -12
    Font.Name = 'Segoe UI'
    Font.Style = []
    Lines.Strings = (
      '')
    ParentFont = False
    TabOrder = 0
    WordWrap = False
    Keywords.Strings = (
      'begin'
      'end'
      'procedure'
      'class')
    HighlightColor = clBlue
    ExplicitLeft = 40
    ExplicitTop = 48
    ExplicitWidth = 481
    ExplicitHeight = 265
  end
end
