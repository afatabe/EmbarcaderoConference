object EConference2025: TEConference2025
  OnCreate = DataModuleCreate
  Height = 618
  Width = 794
  PixelsPerInch = 120
  object html: TEMSFileResource
    PathTemplate = 'C:\Users\azapater\Desktop\test\html\{filename}'
    Left = 50
    Top = 10
  end
  object WebStencilsEngine1: TWebStencilsEngine
    Dispatcher = html
    PathTemplates = <
      item
        Template = '/{filename}'
      end
      item
        Template = '/examples/{filename}'
      end>
    RootDirectory = 
      'C:\Users\lande\OneDrive\Documentos\Embarcadero\Studio\Projects\W' +
      'ebStencilsDemos-main\resources\html\'
    OnValue = WebStencilsEngine1Value
    Left = 290
    Top = 40
  end
  object WebStencilsProcessor: TWebStencilsProcessor
    Engine = WebStencilsEngine1
    OnValue = WebStencilsEngine1Value
    Left = 290
    Top = 130
  end
  object css: TEMSFileResource
    PathTemplate = 'C:\Users\azapater\Desktop\test\html\{filename}'
    Left = 50
    Top = 90
  end
  object js: TEMSFileResource
    PathTemplate = 'C:\Users\azapater\Desktop\test\html\{filename}'
    Left = 50
    Top = 170
  end
  object img: TEMSFileResource
    PathTemplate = 'C:\Users\azapater\Desktop\test\html\{filename}'
    Left = 50
    Top = 250
  end
  object EmployeeConnection: TFDConnection
    Params.Strings = (
      'ConnectionDef=EMPLOYEE')
    LoginPrompt = False
    Left = 681
    Top = 68
  end
  object CountryTable: TFDQuery
    Connection = EmployeeConnection
    SQL.Strings = (
      'SELECT * FROM COUNTRY')
    Left = 681
    Top = 138
  end
  object dsResCountry: TEMSDataSetResource
    AllowedActions = [List, Get, Post, Put, Delete]
    DataSet = CountryTable
    Left = 680
    Top = 210
  end
  object ECon2025Connection: TFDConnection
    Params.Strings = (
      'Database=C:\temp\RADServer_WebStencils\database\CURSO.IB'
      'User_Name=sysdba'
      'Password=masterkey'
      'Protocol=TCPIP'
      'Server=localhost'
      'DriverID=IB')
    LoginPrompt = False
    Left = 55
    Top = 351
  end
  object PalestrantesTable: TFDQuery
    Connection = ECon2025Connection
    SQL.Strings = (
      'SELECT * FROM cursistas'
      'order by id_cursista')
    Left = 196
    Top = 351
  end
  object dsResPalestrantes: TEMSDataSetResource
    AllowedActions = [List, Get, Post, Put, Delete]
    DataSet = PalestrantesTable
    PageSize = 2
    Left = 324
    Top = 351
  end
end
