﻿unit WebRresource;

// EMS Resource Module

interface

uses
  System.SysUtils, System.Classes, System.JSON,
  EMS.Services, EMS.ResourceAPI, EMS.ResourceTypes,
  Web.Stencils, Web.HTTPApp, EMS.FileResource, FireDAC.Stan.Intf,
  FireDAC.Stan.Option, FireDAC.Stan.Error, FireDAC.UI.Intf,
  FireDAC.Phys.Intf, FireDAC.Stan.Def, FireDAC.Stan.Pool,
  FireDAC.Stan.Async, FireDAC.Phys, FireDAC.ConsoleUI.Wait, Data.DB,
  FireDAC.Comp.Client, FireDAC.Phys.IB, FireDAC.Phys.IBDef,
  FireDAC.Stan.Param, FireDAC.DatS, FireDAC.DApt.Intf, FireDAC.Comp.DataSet,
  FireDAC.VCLUI.Wait, FireDAC.DApt,
  System.Generics.Collections,
  System.IOUtils, // Added for TPath
  EMS.DataSetResource;

type
  { TEnvironmentSettings: Class to hold environment/application settings for WebStencils }
  TEnvironmentSettings = class(TPersistent)
  private
    FAppVersion: string;
    FAppName: string;
    FAppEdition: string;
    FCompanyName: string;
    FResource: string;
    FIsRadServer: Boolean;
    FDebugMode: Boolean;
  public
    constructor Create;
  published
    property AppVersion: string read FAppVersion;
    property AppName: string read FAppName;
    property AppEdition: string read FAppEdition;
    property CompanyName: string read FCompanyName;
    property Resource: string read FResource; // Required for RAD Server compatibility
    property IsRadServer: Boolean read FIsRadServer;
    property DebugMode: Boolean read FDebugMode;
  end;

  [ResourceVersion('v1',TEMSVersionStatus.Deprecated)]
  [ResourceName('web')]
  TEConference2024 = class(TObject)
  private

  protected

  public


  published
    procedure Get(const AContext: TEndpointContext; const ARequest: TEndpointRequest; const AResponse: TEndpointResponse);

  end;

  [ResourceVersion('v2',TEMSVersionStatus.Default)]
  [ResourceName('web')]
  TEConference2025 = class(TDataModule)
//    [ResourceSuffix('./')]
    [ResourceSuffix('get', '/{filename}')]
    html: TEMSFileResource;
    [ResourceSuffix('get', '/static/css/{filename}')]
    css: TEMSFileResource;
    [ResourceSuffix('get', '/static/js/{filename}')]
    js: TEMSFileResource;
    [ResourceSuffix('get', '/static/img/{filename}')]
    img: TEMSFileResource;
    WebStencilsEngine1: TWebStencilsEngine;
    WebStencilsProcessor: TWebStencilsProcessor;

    //*** Add Countries
    EmployeeConnection: TFDConnection;
    [WebStencilsVar('countries', false)]
    CountryTable: TFDQuery;
    [ResourceSuffix('nacoes')]
    dsResCountry: TEMSDataSetResource;
    ECon2025Connection: TFDConnection;
    [WebStencilsVar('speakers', false)]
    PalestrantesTable: TFDQuery;
    [ResourceSuffix('palestrantes')]
    dsResPalestrantes: TEMSDataSetResource;

    //Add Landerson ***

    procedure DataModuleCreate(Sender: TObject);
    procedure WebStencilsEngine1Value(Sender: TObject; const AObjectName,
      APropName: string; var AReplaceText: string; var AHandled: Boolean);
  private

    FEnvironmentSettings: TEnvironmentSettings; // Changed from TDictionary
  published
    [ResourceSuffix('./')]
    procedure Get(const AContext: TEndpointContext; const ARequest: TEndpointRequest; const AResponse: TEndpointResponse);
     // *** Add Landerson
    [ResourceSuffix('./nacoes')]
    procedure GetAllCountriesEndpoint(const AContext: TEndpointContext; const ARequest: TEndpointRequest; const AResponse: TEndpointResponse);
    [ResourceSuffix('./palestrantes')]
    procedure GetAllPalestrantesEndpoint(const AContext: TEndpointContext; const ARequest: TEndpointRequest; const AResponse: TEndpointResponse);

  end;

implementation

{%CLASSGROUP 'System.Classes.TPersistent'}

{$R *.dfm}

{ TEnvironmentSettings }

constructor TEnvironmentSettings.Create;
begin
  inherited Create;
  // Initialize properties for RAD Server context
  FAppVersion := '1.0.0';
  FAppName := 'Embarcadero Conference 2025';
  FAppEdition := 'RAD Server WebStencils';
  FCompanyName := 'Embarcadero Inc.';
  FResource := '/web'; // Set RAD Server resource endpoint
  FIsRadServer := True;
{$IFDEF DEBUG}
  FDebugMode := True;
{$ELSE}
  FDebugMode := False;
{$ENDIF}
end;

{ TEConference }

procedure TEConference2025.DataModuleCreate(Sender: TObject);
const
  //////////////////////
  // Replace the constant LProjectPath with the absolute path to the resources folder of the reporitory
  //////////////////////
  LProjectPath: string = 'C:\temp\RADServer_WebStencils\site';
begin
  html.PathTemplate := TPath.Combine(LProjectPath, 'html\{filename}');
  css.PathTemplate := TPath.Combine(LProjectPath, 'html\static\css\{filename}');
  js.PathTemplate := TPath.Combine(LProjectPath, 'html\static\js\{filename}');
  img.PathTemplate := TPath.Combine(LProjectPath, 'html\static\img\{filename}');
  WebStencilsProcessor.PathTemplate := TPath.Combine(LProjectPath, 'html');
  WebStencilsEngine1.RootDirectory := TPath.Combine(LProjectPath, 'html');
  AddProcessor(html, WebStencilsEngine1);


  // Create and register the environment settings object
  FEnvironmentSettings := TEnvironmentSettings.Create;
  WebStencilsEngine1.AddVar('env', FEnvironmentSettings);
end;

procedure TEConference2025.Get(const AContext: TEndpointContext; const ARequest: TEndpointRequest; const AResponse: TEndpointResponse);
var
  LHTMLContent: string;
begin
  WebStencilsProcessor.InputFileName := TPath.Combine(WebStencilsProcessor.PathTemplate, 'home.html');
  LHTMLContent := WebStencilsProcessor.Content;
  AResponse.Body.SetString(LHTMLContent);
end;

procedure TEConference2025.GetAllCountriesEndpoint(
  const AContext: TEndpointContext; const ARequest: TEndpointRequest;
  const AResponse: TEndpointResponse);
var
  LHTMLContent: string;
begin
  CountryTable.Open;
  WebStencilsProcessor.InputFileName := TPath.Combine(WebStencilsEngine1.rootDirectory, 'countries/paises.html');
  LHTMLContent := WebStencilsProcessor.Content;
  AResponse.Body.SetString(LHTMLContent);
end;

procedure TEConference2025.GetAllPalestrantesEndpoint(
  const AContext: TEndpointContext; const ARequest: TEndpointRequest;
  const AResponse: TEndpointResponse);
begin
  PalestrantesTable.Open;
  WebStencilsProcessor.InputFileName := TPath.Combine(WebStencilsEngine1.rootDirectory, 'palestrantes/palestrantes.html');
  AResponse.Body.SetString(WebStencilsProcessor.Content);
end;


procedure TEConference2025.WebStencilsEngine1Value(Sender: TObject;
  const AObjectName, APropName: string; var AReplaceText: string;
  var AHandled: Boolean);
begin
  // Handle dynamic system information
  if SameText(AObjectName, 'system') then
  begin
    AHandled := True; // Handle all system properties here
    if SameText(APropName, 'timestamp') then
      AReplaceText := FormatDateTime('yyyy-mm-dd hh:nn:ss', Now)
    else if SameText(APropName, 'year') then
      AReplaceText := FormatDateTime('yyyy', Now)
    else
      AReplaceText := Format('SYSTEM_%s_NOT_FOUND', [APropName.ToUpper]);
  end;
end;


{ TEConference2024 }

procedure TEConference2024.Get(const AContext: TEndpointContext;
  const ARequest: TEndpointRequest; const AResponse: TEndpointResponse);
begin
  // Sample code
  AResponse.Body.SetValue(TJSONString.Create('Embarcadero Conference 2024'), True);
end;

procedure Register;
begin
  RegisterResource(TypeInfo(TEConference2025));
  RegisterResource(TypeInfo(TEConference2024));
end;

initialization
  Register;
end.
