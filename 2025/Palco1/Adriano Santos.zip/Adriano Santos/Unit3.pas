unit Unit3;

interface

uses
  RESTRequest4D,

  REST.Json,

  System.Json,
  System.SysUtils,
  System.Variants,
  System.Classes,
  System.Math,

  Winapi.Windows,
  Winapi.Messages,

  Vcl.Graphics,
  Vcl.Controls,
  Vcl.Forms,
  Vcl.Dialogs,
  Vcl.StdCtrls,
  Vcl.ExtCtrls;

type
  TForm3 = class(TForm)
    Button1: TButton;
    Memo1: TMemo;
    Button2: TButton;
    Bevel1: TBevel;
    radioCard: TRadioGroup;
    radioEquipamento: TRadioGroup;
    lblPaymentID: TLabel;
    Label1: TLabel;
    LblConfirmacao: TLabel;
    LblStatus: TLabel;
    Button3: TButton;
    procedure FormCreate(Sender: TObject);
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure Button3Click(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

const
  C_Token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJjbnBqIjoiMTQ0MTcyODIwMDAxMzEiLCJjbnBqX2ludGVncmFkb3IiOiIxNDQxNzI4MjAwMDEzMSIsInN0b3JlX2lkIjoxNSwic3RvcmVfaWRlbnRpZmllciI6IjAxOTY1ZDZiLTIxNWItN2MyOC04ZDgwLTMwN2NlN2IzNjk2ZiIsImlhdCI6MTc0NjU0ODQzMywiaXNzIjoiYXBwLXdlYi0wNC1zbXRlZi1hcGktcHJkLmF6dXJld2Vic2l0ZXMubmV0In0.0woeD8mzml1S0hUOKzzFfmTxT3R5apdnqK6-EFl-4G0';
  C_Chave = '63867169f7fa4d1c862494b916e872e6';

var
  Form3: TForm3;

implementation

{$R *.dfm}

procedure TForm3.FormCreate(Sender: TObject);
begin
  lblPaymentID.Caption := EmptyStr;
  LblConfirmacao.Caption := EmptyStr;
  LblStatus.Caption := EmptyStr;
  Memo1.Lines.Clear;
end;

procedure TForm3.Button1Click(Sender: TObject);
var
  LBody : TJSONObject;
  LExtras: TJSONObject;
  LResponse: IResponse;
  LRetornoJSON: TJSONValue;
  LPaymentID: string;

  LTipoCard: string;
  LEquipamento: string;
  LNumeroControle: string;
begin
  randomize;
  LNumeroControle := Format('%5.5d', [RandomRange(1000, 5000)]);

  LExtras :=
    TJSONObject
      .Create
        .AddPair('CPF', '255.255.255-10')
        .AddPair('NOME', 'Adriano Santos');

  LBody := TJSONObject.Create;

  //Escolhe para onde enviar o pagamento
  if radioEquipamento.ItemIndex = 0
  then LEquipamento := 'bf654d132f0a4d11'
  else LEquipamento := '1cdbb4edc62731f6';

  if radioCard.ItemIndex = 0
  then LTipoCard := 'CRD_UNICO'
  else LTipoCard := 'NRM';

  //Monta o Body
  LBody
    .AddPair('value'        , 5.00)            //Valor
    .AddPair('payment_type' , 'OTHERS')        //Tipo de Pagamento Cr�dito, D�bito, PIX
    .AddPair('installments' , 1)               //Parcelas
    .AddPair('serial_pos'   , LEquipamento)    //Equipamento
    .AddPair('charge_id'    , LNumeroControle) //N�mero �nico, seu sistema
    .AddPair('order_type'   , LTipoCard)       //Card M�ltipo - para card �nico usar CRD_UNICO
    .AddPair('extras'       , LExtras)         //Dados do cliente
    .AddPair('has_details', false);

  //Faz a chamada
  LResponse :=
    TRequest.New.BaseURL(Format('%s%s', ['https://api.smarttef.mobi', '/commands/order/create']))
    .Token('Bearer ' + C_Token)
    .AddHeader('Ocp-Apim-Subscription-Key', C_Chave)
    .AddBody(LBody)
    .Accept('application/json ')
    .ContentType('application/json')
    .Post;

  //Valida se enviou o card
  if LResponse.StatusCode = 201 then
  begin
    LRetornoJSON := TJSONObject.ParseJSONValue(LResponse.Content) as TJSONValue;
    LPaymentID := LRetornoJSON.GetValue<string>('payment_identifier');
    lblPaymentID.Caption := LPaymentID;
  end;
end;

procedure TForm3.Button2Click(Sender: TObject);
var
  LBody : TJSONObject;
  LResponse: IResponse;
  LJsonResposta: TJSONArray;
  LStatus: string;
begin
  LBody := TJSONObject.Create;
  LBody
    .AddPair('payment_identifier', lblPaymentID.Caption);

  LResponse :=
    TRequest.New.BaseURL(Format('%s%s', ['https://api.smarttef.mobi', '/pooling/order/get']))
    .Token('Bearer ' + C_Token)
    .AddHeader('Ocp-Apim-Subscription-Key', C_Chave)
    .AddBody(LBody)
    .Accept('application/json')
    .ContentType('application/json')
    .Post;

  LJsonResposta := TJSONObject.ParseJSONValue(LResponse.Content) as TJSONArray;

  Memo1.Lines.Clear;
  Memo1.Lines.Add(TJson.Format(LJsonResposta));

  LStatus := LJsonResposta.Items[0].GetValue<string>('payment_status');

  LblStatus.Caption := LStatus;

  if LStatus.Equals('CNC') then
  begin
    LblConfirmacao.Caption := 'Pagamento Confirmado';
    LblConfirmacao.Font.Color := clGreen;
  end
  else if LStatus.Equals('PDT') then
  begin
    LblConfirmacao.Caption := 'Aguardando Confirma��o...';
    LblConfirmacao.Font.Color := clBlue;
  end
  else if LStatus.Equals('REJ_PAG') then
  begin
    LblConfirmacao.Caption := 'Pagamento Rejeitado';
    LblConfirmacao.Font.Color := clRed;
  end;

end;

procedure TForm3.Button3Click(Sender: TObject);
begin
  lblPaymentID.Caption := EmptyStr;
  LblConfirmacao.Caption := EmptyStr;
  LblStatus.Caption := EmptyStr;
  Memo1.Lines.Clear;
end;

end.
