object Form3: TForm3
  Left = 0
  Top = 0
  Caption = 'Embarcadero Conference 2025'
  ClientHeight = 728
  ClientWidth = 816
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -12
  Font.Name = 'Segoe UI'
  Font.Style = []
  Position = poScreenCenter
  OnCreate = FormCreate
  TextHeight = 15
  object Bevel1: TBevel
    Left = 8
    Top = 119
    Width = 800
    Height = 105
  end
  object lblPaymentID: TLabel
    Left = 130
    Top = 155
    Width = 557
    Height = 32
    Alignment = taCenter
    AutoSize = False
    Caption = 'Payment ID'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -24
    Font.Name = 'Segoe UI'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object Label1: TLabel
    Left = 12
    Top = 240
    Width = 557
    Height = 32
    Alignment = taCenter
    AutoSize = False
    Caption = 'Retorno'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -19
    Font.Name = 'Segoe UI'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object LblConfirmacao: TLabel
    Left = 8
    Top = 278
    Width = 557
    Height = 32
    Alignment = taCenter
    AutoSize = False
    Caption = 'Aguardando Confirma'#231#227'o'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -19
    Font.Name = 'Segoe UI'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object LblStatus: TLabel
    Left = 8
    Top = 316
    Width = 561
    Height = 25
    Alignment = taCenter
    AutoSize = False
    Caption = 'LblStatus'
    Font.Charset = ANSI_CHARSET
    Font.Color = clBlue
    Font.Height = -19
    Font.Name = 'Segoe UI Semibold'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object Button1: TButton
    Left = 575
    Top = 15
    Width = 233
    Height = 98
    Caption = 'Enviar Pagamento'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -16
    Font.Name = 'Segoe UI'
    Font.Style = [fsBold]
    ParentFont = False
    TabOrder = 0
    OnClick = Button1Click
  end
  object Memo1: TMemo
    Left = 8
    Top = 360
    Width = 800
    Height = 321
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -21
    Font.Name = 'Courier New'
    Font.Style = []
    ParentFont = False
    ScrollBars = ssBoth
    TabOrder = 1
  end
  object Button2: TButton
    Left = 575
    Top = 240
    Width = 233
    Height = 98
    Caption = 'Consultar Pagamento'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -16
    Font.Name = 'Segoe UI'
    Font.Style = [fsBold]
    ParentFont = False
    TabOrder = 2
    OnClick = Button2Click
  end
  object radioCard: TRadioGroup
    Left = 8
    Top = 8
    Width = 273
    Height = 105
    Caption = ' Tipo de Card '
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -16
    Font.Name = 'Segoe UI'
    Font.Style = []
    ItemIndex = 0
    Items.Strings = (
      'Card '#218'nico (PinPad Sem Fio)'
      'Card M'#250'ltiplo (Lista)')
    ParentFont = False
    TabOrder = 3
  end
  object radioEquipamento: TRadioGroup
    Left = 296
    Top = 8
    Width = 273
    Height = 105
    Caption = ' Equipamento '
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -16
    Font.Name = 'Segoe UI'
    Font.Style = []
    ItemIndex = 0
    Items.Strings = (
      'Aplicativo Teste'
      'PagSeguro Maquininha Real')
    ParentFont = False
    TabOrder = 4
  end
  object Button3: TButton
    Left = 8
    Top = 687
    Width = 800
    Height = 33
    Caption = 'Reset'
    TabOrder = 5
    OnClick = Button3Click
  end
end
