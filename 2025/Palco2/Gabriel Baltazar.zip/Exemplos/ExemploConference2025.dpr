program ExemploConference2025;

{$APPTYPE CONSOLE}

{$R *.res}

uses
  System.SysUtils,
  Horse,
  Horse.Jhonson,
  Horse.OctetStream,
  Horse.GBSwagger,
  {$IFDEF MSWINDOWS}
  Winapi.ActiveX,
  {$ENDIF }
  DAO.DataModule in 'Fontes\DAO\DAO.DataModule.pas' {DAODataModule: TDataModule},
  DAO.Client in 'Fontes\DAO\DAO.Client.pas',
  Controller.Client in 'Fontes\Controller\Controller.Client.pas',
  Entity.Classes in 'Fontes\Entity\Entity.Classes.pas',
  Utils.Credentials in 'Fontes\Utils\Utils.Credentials.pas',
  Controller.Sale in 'Fontes\Controller\Controller.Sale.pas';

procedure SwaggerDoc;
begin
  Swagger
    .Version('2.0')
    .AddProtocol(TGBSwaggerProtocol.gbHttps)
    .AddProtocol(TGBSwaggerProtocol.gbHttp)
    .Config
      .Language('pt-BR')
    .&End
    .Info
      .Title('Embarcadero Conference 2025')
      .Description('Arquitetura de microservi�os - Embarcadero Conference 2025')
    .&End
  .&End;
end;

begin
  IsConsole := False;
  ReportMemoryLeaksOnShutdown := True;

  THorse.Use(Jhonson)
    .Use(OctetStream)
    .Use(HorseSwagger);

  SwaggerDoc;

  THorse.Listen(9001,
    procedure
    begin
{$IFDEF MSWINDOWS}
      CoInitialize(nil);
{$ENDIF}
      System.Writeln('Running in port 9001');
      System.Readln;
    end,
    procedure
    begin
{$IFDEF MSWINDOWS}
      CoUninitialize;
{$ENDIF}
    end);
end.
