
create table client (
	id numeric not null primary key,
	name varchar(100) not null,
	document varchar(30) not null,
	birthdayDate timestamp not null	
);


DO $$
DECLARE
    i INT := 1;
BEGIN
    WHILE i <= 10000 LOOP
        INSERT INTO client (id, name, birthdayDate, document) VALUES (
            i,
            'Person ' || md5(i::text),
            NOW() - (RANDOM() * INTERVAL '30 year')::interval, 
            substring(md5(random()::text), 1, 30)
        );
        i := i + 1;
    END LOOP;
END $$;
