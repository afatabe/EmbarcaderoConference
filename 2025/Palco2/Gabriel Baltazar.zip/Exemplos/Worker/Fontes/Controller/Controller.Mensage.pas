unit Controller.Mensage;

interface

uses
  System.SysUtils,
  System.JSON,
  AWS4D.SQS.Facade.Interfaces,
  Utils.Credentials;

procedure ProcessMessage;

implementation

procedure ProcessPayment(const AJSON: TJSONObject);
begin
  System.Writeln('Processing payment to sale ' + AJSON.GetValue<Double>('Id').ToString);
  Sleep(10000);
  System.Writeln('Sucess');
end;

procedure SendEmail(const AJSON: TJSONObject);
begin
  System.Writeln('Sending email to ' + AJSON.GetValue<string>('CustomerEmail'));
  Sleep(5000);
  System.Writeln('Sucess');
end;

procedure ProcessMessage;
var
  LSqs: IAWS4DSQSFacade;
  LJSONMessage: TJSONObject;
  LMessage: string;
begin
  while True do
  begin
    LSqs := NewSQSFacade;
    LSqs.AccessKey(CKeyId)
      .SecretKey(CSecretKey)
      .Region('us-east-1');

    System.Writeln(EmptyStr);
    System.Writeln('Search new messages...');
    LSqs.ReceiveMessage.Request
      .MaxNumberOfMessages(1)
      .QueueUrl('451809183281/conference-2025')
      .&End
      .Send;

    System.Writeln(Format('%d messages found', [LSqs.ReceiveMessage.Response.Messages.Count]));

    while LSqs.ReceiveMessage.Response.Messages.HasNext do
    begin
      System.Writeln(EmptyStr);
      LMessage := LSqs.ReceiveMessage.Response.Messages.Current.Body;
      LJSONMessage := TJSONObject.ParseJSONValue(LMessage) as TJSONObject;

      ProcessPayment(LJSONMessage);
      SendEmail(LJSONMessage);

      // Delete Message
      LSqs.DeleteMessage.Request
        .QueueName('451809183281/conference-2025')
        .ReceiptHandle(LSqs.ReceiveMessage.Response.Messages.Current.ReceiptHandle)
        .&End
        .Send;
    end;
  end;
end;

end.
