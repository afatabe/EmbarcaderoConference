program ExemploConference2025_Worker;

{$APPTYPE CONSOLE}

{$R *.res}

uses
  System.SysUtils,
  Utils.Credentials in 'Fontes\Utils\Utils.Credentials.pas',
  Controller.Mensage in 'Fontes\Controller\Controller.Mensage.pas';

begin
  try
    ProcessMessage;
  except
    on E: Exception do
      Writeln(E.ClassName, ': ', E.Message);
  end;
end.
