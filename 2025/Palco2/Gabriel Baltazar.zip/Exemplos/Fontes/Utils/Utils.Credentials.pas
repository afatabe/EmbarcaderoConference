unit Utils.Credentials;

interface

const
  // Colocar as credenciais do seu usuario da AWS
  CKeyId = '';
  CSecretKey = '';

implementation

end.
