unit Controller.Client;

interface

uses
  System.Classes,
  System.SysUtils,
  System.JSON,
  Horse,
  Horse.GBSwagger,
  Horse.GBSwagger.Registry,
  GBSwagger.Path.Attributes,
  Horse.GBSwagger.Controller,
  Entity.Classes,
  DAO.DataModule,
  DAO.Client;

type
  [SwagPath('client', 'Client')]
  TControllerClient = class(THorseGBSwagger)
  public
    [SwagGET('List clients')]
    [SwagResponse(200, TEntityClient, True)]
    procedure List;

    [SwagGET('{id}', 'Find a client')]
    [SwagParamPath('id', 'client id')]
    [SwagResponse(200, TEntityClient)]
    [SwagResponse(404)]
    procedure Find;

    [SwagPOST('{id}/image', 'Associate a user image')]
    [SwagParamPath('id', 'client id')]
    [SwagResponse(200)]
    procedure AssociateImage;

    [SwagGET('{id}/image', 'Get a user image')]
    [SwagParamPath('id', 'client id')]
    [SwagResponse(200)]
    procedure GetImage;
  end;

implementation

{ TControllerClient }

uses
  Utils.Credentials,
  AWS4D.S3.Facade.Interfaces;

procedure TControllerClient.AssociateImage;
var
  LImage: TMemoryStream;
  LId: string;
  LS3: IAWS4DS3Facade;
begin
  LId := FRequest.Params.Field('id').AsString;
  LImage := FRequest.Body<TMemoryStream>;
  LS3 := NewS3Facade;
  LS3.AccessKey(CKeyId)
    .SecretKey(CSecretKey)
    .Region('us-east-1')
    .CreateObject
      .Request
        .BucketName('embarcadero-conference-2025')
        .ObjectName(Format('image/client/%s.jpg', [LId]))
        .FileStream(LImage)
      .&End
      .Send;

  FResponse.Status(200);
end;

procedure TControllerClient.Find;
var
  LDataModule: TDAODataModule;
  LDAO: TDAOClient;
  LJSON: TJSONObject;
  LId: Double;
begin
  LId := FRequest.Params.Field('id').AsFloat;
  LDataModule := TDAODataModule.Create(nil);
  try
    LDAO := TDAOClient.Create(LDataModule);
    try
      LJSON := LDAO.Find(LId);
      FResponse.Send<TJSONObject>(LJSON);
    finally
      LDAO.Free;
    end;
  finally
    LDataModule.Free;
  end;
end;

procedure TControllerClient.GetImage;
var
  LImage: TMemoryStream;
  LId: string;
  LS3: IAWS4DS3Facade;
begin
  LId := FRequest.Params.Field('id').AsString;
  LS3 := NewS3Facade;
  LS3.AccessKey(CKeyId)
    .SecretKey(CSecretKey)
    .Region('us-east-1')
    .DownloadObject
      .Request
        .BucketName('embarcadero-conference-2025')
        .ObjectName(Format('image/client/%s.jpg', [LId]))
      .&End
      .Send;

  LImage := LS3.DownloadObject.Response.Stream;
  FResponse.Send<TMemoryStream>(LImage).ContentType('image/jpeg');
  FResponse.Status(200);
end;

procedure TControllerClient.List;
var
  LDataModule: TDAODataModule;
  LDAO: TDAOClient;
  LJSON: TJSONArray;
begin
  LDataModule := TDAODataModule.Create(nil);
  try
    LDAO := TDAOClient.Create(LDataModule);
    try
      LJSON := LDAO.List;
      FResponse.Send<TJSONArray>(LJSON);
    finally
      LDAO.Free;
    end;
  finally
    LDataModule.Free;
  end;
end;

initialization
  THorseGBSwaggerRegistry.RegisterPath(TControllerClient);

end.
