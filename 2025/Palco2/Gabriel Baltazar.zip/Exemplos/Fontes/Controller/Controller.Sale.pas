unit Controller.Sale;

interface

uses
  System.Classes,
  System.SysUtils,
  System.JSON,
  Horse,
  Horse.GBSwagger,
  Horse.GBSwagger.Registry,
  GBSwagger.Path.Attributes,
  Horse.GBSwagger.Controller,
  Entity.Classes,
  DAO.DataModule,
  DAO.Client;

type
  [SwagPath('sale', 'Sale')]
  TControllerSale = class(THorseGBSwagger)
  private
    procedure SaveInDataBase(const AJSON: TJSONObject);
    procedure ProcessPayment(const AJSON: TJSONObject);
    procedure SendEmail(const AJSON: TJSONObject);
    procedure SendMessage(const AJSON: TJSONObject);
  public
    [SwagPost('Send a sale')]
    [SwagParamBody('sale', TEntitySale)]
    [SwagResponse(202)]
    procedure Sale;
  end;

implementation

{ TControllerSale }

uses
  AWS4D.SQS.Facade.Interfaces,
  Utils.Credentials;

procedure TControllerSale.ProcessPayment(const AJSON: TJSONObject);
begin
  Sleep(30000);
end;

procedure TControllerSale.Sale;
var
  LJSONSale: TJSONObject;
begin
  LJSONSale := FRequest.Body<TJSONObject>;

  SaveInDataBase(LJSONSale); // 1s
//  ProcessPayment(LJSONSale); //
//  SendEmail(LJSONSale);
  SendMessage(LJSONSale); // 1s

  FResponse.Status(202);
end;

procedure TControllerSale.SaveInDataBase(const AJSON: TJSONObject);
begin
  // Save sale data in database
  Sleep(1000);
end;

procedure TControllerSale.SendEmail(const AJSON: TJSONObject);
begin
  Sleep(10000);
end;

procedure TControllerSale.SendMessage(const AJSON: TJSONObject);
var
  LSqs: IAWS4DSQSFacade;
begin
  LSqs := NewSQSFacade;
  LSqs.AccessKey(CKeyId)
    .SecretKey(CSecretKey)
    .Region('us-east-1');

  LSqs.SendMessage
    .Request
      .MessageBody(AJSON.ToString)
      .QueueUrl('451809183281/conference-2025')
    .&End
    .Send;
end;

initialization
  THorseGBSwaggerRegistry.RegisterPath(TControllerSale);

end.
