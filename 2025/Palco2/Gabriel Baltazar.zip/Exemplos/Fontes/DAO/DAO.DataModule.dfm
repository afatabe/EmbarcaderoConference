object DAODataModule: TDAODataModule
  Height = 252
  Width = 404
  object FDConn: TFDConnection
    Params.Strings = (
      'Database=EConn2025'
      'User_Name=postgres'
      'Password=123'
      'DriverID=PG')
    LoginPrompt = False
    Left = 80
    Top = 48
  end
  object FDPhysPgDriverLink1: TFDPhysPgDriverLink
    Left = 216
    Top = 48
  end
  object FDQuery: TFDQuery
    Connection = FDConn
    Left = 80
    Top = 136
  end
end
