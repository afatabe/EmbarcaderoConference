unit DAO.Client;

interface

uses
  System.SysUtils,
  System.JSON,
  Data.DB,
  DAO.DataModule;

type
  TDAOClient = class
  private
    FDataModule: TDAODataModule;

    function DataSetToObject(ADataSet: TDataSet): TJSONObject;
    function DataSetToArray(ADataSet: TDataSet): TJSONArray;

    function FindInRedis(const AId: Double): TJSONObject;
    procedure SaveInRedis(const AId: Double; const AJSON: TJSONObject);
  public
    constructor Create(const ADataModule: TDAODataModule);

    function List: TJSONArray;
    function Find(const AId: Double): TJSONObject;
  end;

implementation

{ TDAOClient }

constructor TDAOClient.Create(const ADataModule: TDAODataModule);
begin
  FDataModule := ADataModule;
end;

function TDAOClient.DataSetToArray(ADataSet: TDataSet): TJSONArray;
begin
  ADataSet.First;
  Result := TJSONArray.Create;
  while not ADataSet.Eof do
  begin
    Result.Add(DataSetToObject(ADataSet));
    ADataSet.Next;
  end;
end;

function TDAOClient.DataSetToObject(ADataSet: TDataSet): TJSONObject;
begin
  Result := TJSONObject.Create
    .AddPair('Id', TJSONNumber.Create(ADataSet.FieldByName('Id').AsFloat))
    .AddPair('Name', ADataSet.FieldByName('Name').AsString)
    .AddPair('Document', ADataSet.FieldByName('Name').AsString)
    .AddPair('BirthdayDate', FormatDateTime('yyyy-MM-dd', ADataSet.FieldByName('BirthdayDate').AsDateTime));
end;

function TDAOClient.Find(const AId: Double): TJSONObject;
begin
  Result := FindInRedis(AId);
  if not Assigned(Result) then
  begin
    FDataModule.ExecSql('select id, name, document, birthdayDate from client where id = ' + AId.ToString);
    Result := DataSetToObject(FDataModule.FDQuery);
    SaveInRedis(AId, Result);
  end;
end;

function TDAOClient.FindInRedis(const AId: Double): TJSONObject;
var
  LKey: string;
begin
  LKey := 'client_' + AId.ToString;
  Result := FDataModule.ReadInRedis(LKey);
end;

function TDAOClient.List: TJSONArray;
begin
  FDataModule.ExecSql('select id, name, document, birthdayDate from client');
  Result := DataSetToArray(FDataModule.FDQuery);
end;

procedure TDAOClient.SaveInRedis(const AId: Double; const AJSON: TJSONObject);
var
  LKey: string;
begin
  LKey := 'client_' + AId.ToString;
  FDataModule.SaveInRedis(LKey, AJSON);
end;

end.
