unit DAO.DataModule;

interface

uses
  System.SysUtils, System.Classes, FireDAC.Stan.Intf, FireDAC.Stan.Option, FireDAC.Stan.Error,
  FireDAC.UI.Intf, FireDAC.Phys.Intf, FireDAC.Stan.Def, FireDAC.Stan.Pool, FireDAC.Stan.Async,
  FireDAC.Phys, FireDAC.Phys.PG, FireDAC.Phys.PGDef, FireDAC.ConsoleUI.Wait, Data.DB,
  FireDAC.Comp.Client, FireDAC.Stan.Param, FireDAC.DatS, FireDAC.DApt.Intf, FireDAC.DApt,
  FireDAC.Comp.DataSet,
  System.JSON,
  Redis.Commons,
  Redis.Client,
  Redis.NetLib.INDY,
  Redis.Values, FireDAC.VCLUI.Wait;

type
  TDAODataModule = class(TDataModule)
    FDConn: TFDConnection;
    FDPhysPgDriverLink1: TFDPhysPgDriverLink;
    FDQuery: TFDQuery;
  private
    FRedisClient: IRedisClient;
    { Private declarations }
  public
    procedure ExecSql(const ASql: string); overload;
    procedure ExecSql(const ASql: string; const AArgs: array of const); overload;

    procedure SaveInRedis(const AKey: string; const AJSON: TJSONObject);
    function ReadInRedis(const AKey: string): TJSONObject;
    { Public declarations }
  end;

var
  DAODataModule: TDAODataModule;

implementation

{%CLASSGROUP 'System.Classes.TPersistent'}

{$R *.dfm}

{ TDAODataModule }

procedure TDAODataModule.ExecSql(const ASql: string; const AArgs: array of const);
var
  LSql: string;
begin
  LSql := Format(ASql, AArgs);
  ExecSql(LSql);
end;

function TDAODataModule.ReadInRedis(const AKey: string): TJSONObject;
var
  LValue: TRedisString;
begin
  Result := nil;
  if not Assigned(FRedisClient) then
  begin
    FRedisClient := TRedisClient.Create;
    FRedisClient.Connect;
  end;

  LValue := FRedisClient.GET(AKey);
  if not LValue.IsNull then
    Result := TJSONObject.ParseJSONValue(LValue.Value) as TJSONObject;
end;

procedure TDAODataModule.SaveInRedis(const AKey: string; const AJSON: TJSONObject);
begin
  if not Assigned(FRedisClient) then
  begin
    FRedisClient := TRedisClient.Create;
    FRedisClient.Connect;
  end;

  FRedisClient.&SET(AKey, AJSON.ToString, 30);
end;

procedure TDAODataModule.ExecSql(const ASql: string);
begin
  if FDQuery.Active then
    FDQuery.Close;

  FDQuery.SQL.Text := ASql;
  FDQuery.Open;
end;

end.
