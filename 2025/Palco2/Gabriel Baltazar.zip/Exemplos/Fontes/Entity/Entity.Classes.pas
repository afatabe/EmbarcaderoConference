unit Entity.Classes;

interface

type
  TEntityClient = class
  private
    FId: Double;
    FName: string;
    FBirthdayDate: TDateTime;
    FDocument: string;
  public
    property Id: Double read FId write FId;
    property Name: string read FName write FName;
    property Document: string read FDocument write FDocument;
    property BirthdayDate: TDateTime read FBirthdayDate write FBirthdayDate;
  end;

  TEntitySale = class
  private
    FCustomerEmail: string;
    FCustomerName: string;
    FTotal: Double;
    FId: Double;
  public
    property Id: Double read FId write FId;
    property CustomerName: string read FCustomerName write FCustomerName;
    property CustomerEmail: string read FCustomerEmail write FCustomerEmail;
    property Total: Double read FTotal write FTotal;
  end;

implementation

end.
