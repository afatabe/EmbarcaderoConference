unit Controller.Bills.Payable;

interface

uses Model.Bills.Interfaces, System.Generics.Collections,
     Model.Bills.Payable, System.Classes, System.SysUtils;

type
  TControllerBillsPayable = class(TInterfacedObject, IControllerBillsPayable)
  private
    FBill      : TBillsPayable;
    FListOfBills: TObjectList<TBillsPayable>;

    function GetBills: TObjectList<TBillsPayable>;
    function GetBill: TBillsPayable;
  public
    class function New: IControllerBillsPayable;
    constructor Create;
    destructor Destroy; override;

    function Validate: IControllerBillsPayable;
    function Save: IControllerBillsPayable;
    function Inactivate(const aId: Integer): IControllerBillsPayable;
    function Load(AId: Integer): IControllerBillsPayable;

    function Assign(aDescription: string; aValue: Currency; aFixedExpense, aInstallments: Boolean;
                     aNumberOfInstallments: string): IControllerBillsPayable; overload;
    function Assign(aBill: TBillsPayable): IControllerBillsPayable; overload;

    property Bills: TObjectList<TBillsPayable> read GetBills;
    property Bill: TBillsPayable read GetBill;
  end;

implementation

uses
  StrUtils;

{ TControllerBills }

class function TControllerBillsPayable.New: IControllerBillsPayable;
begin
  Result := Self.Create;
end;

constructor TControllerBillsPayable.Create;
begin
  FBill := TBillsPayable.Create;
end;

destructor TControllerBillsPayable.Destroy;
begin
  if Assigned(FBill) then
    FreeAndNil(FBill);

  if Assigned(FListOfBills) then
    FreeAndNil(FListOfBills);

  inherited;
end;

function TControllerBillsPayable.GetBills: TObjectList<TBillsPayable>;
begin
  if not Assigned(FListOfBills) then
    FListOfBills := FBill.GetListOfBills;

  Result := FListOfBills;
end;

function TControllerBillsPayable.GetBill: TBillsPayable;
begin
  Result := FBill;
end;

function TControllerBillsPayable.Load(AId: Integer): IControllerBillsPayable;
begin
  FBill.Id := AId;
  FBill.GetBill;

  Result := Self;
end;

function TControllerBillsPayable.Assign(aDescription: string; aValue: Currency; aFixedExpense, aInstallments: Boolean;
  aNumberOfInstallments: string): IControllerBillsPayable;
begin
  FBill.Description  := aDescription;
  FBill.Value        := aValue;
  FBill.Fixed        := aFixedExpense;
  FBill.Installments := aInstallments;
  FBill.Installment  := aNumberOfInstallments;

  Result := Self;
end;

function TControllerBillsPayable.Assign(aBill: TBillsPayable): IControllerBillsPayable;
begin
  FBill.Assign(aBill);

  Result := Self;
end;

function TControllerBillsPayable.Validate: IControllerBillsPayable;
begin
  FBill.Validate;

  Result := Self;
end;

function TControllerBillsPayable.Save: IControllerBillsPayable;
begin
  FBill.Save;

  Result := Self;
end;

function TControllerBillsPayable.Inactivate(const aId: Integer): IControllerBillsPayable;
begin
  try
    Load(aId);
    FBill.Inactivate;
  except on E: Exception do
    raise Exception.Create(E.Message);
  end;
end;
end.
