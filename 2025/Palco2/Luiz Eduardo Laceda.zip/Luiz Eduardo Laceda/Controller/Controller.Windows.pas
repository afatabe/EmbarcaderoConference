unit Controller.Windows;

interface

uses FMX.Types, FMX.Forms, Factory.Windows;

type
  EWindows = EWindow;

  TControllerWindows = class
  private
    FParent: TFmxObject;
    FWindow: TFrame;
  public
    constructor Create(aParent: TFmxObject);
    destructor  Destroy; override;

    procedure CreateWindow(aWindow: EWindows);
  end;

  EWindowHelper = record helper for EWindows
    function toString: string;
  end;

  const EWindowString: array[Low(EWindows)..High(EWindows)] of string = ('Aba exemplo',
                                                                         'Configura��es');

implementation

uses System.SysUtils;

{ TControllerWindows }

constructor TControllerWindows.Create(aParent: TFmxObject);
begin
  FParent := aParent;
end;

destructor TControllerWindows.Destroy;
begin
  if Assigned(FWindow) then
    FreeAndNil(FWindow);
end;

procedure TControllerWindows.CreateWindow(aWindow: EWindows);
begin
  if Assigned(FWindow) then
    FreeAndNil(FWindow);

  FWindow        := TFactoryWindows.New.CreateWindow(aWindow);
  FWindow.Parent := FParent;
end;

{ EWindowHelper }

function EWindowHelper.toString: string;
begin
  Result := EWindowString[Self];
end;

end.
