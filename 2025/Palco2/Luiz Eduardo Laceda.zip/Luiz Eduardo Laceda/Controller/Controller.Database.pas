unit Controller.Database;

interface

uses
  FireDAC.Comp.Client, DAO.Database;

type
  TControllerDatabase = class
  private
    FSQLiteConn,
    FFBConn: TFDConnection;
    FDaoSQLite,
    FDaoFirebird: TDaoDatabase;
    FPathDB    : string;

    procedure SetPathDB;

    procedure CreateSQLiteDatabase;
    procedure CreateFirebirdDatabase;
  public
    constructor Create(ASqliteConn, AFirebirdConn: TFDConnection);
    destructor Destroy; override;

    procedure CreateTables;
  end;

implementation

uses
  System.SysUtils;

{ TControllerDatabase }

constructor TControllerDatabase.Create(ASqliteConn, AFirebirdConn: TFDConnection);
begin
  FSQLiteConn := ASqliteConn;
  FFBConn     := AFirebirdConn;

  SetPathDB;

  CreateSQLiteDatabase;
  CreateFirebirdDatabase;

  FDaoSQLite   := TDaoDatabase.Create(FSQLiteConn);
  FDaoFirebird := TDaoDatabase.Create(FFBConn);
end;

procedure TControllerDatabase.CreateFirebirdDatabase;
begin
  FFBConn.Params.Values['Database']       := FPathDB + 'Database.fdb';
  FFBConn.Params.Values['User_Name']      := 'SYSDBA';
  FFBConn.Params.Values['Password']       := 'masterkey';
  FFBConn.Params.Values['CharacterSet']   := 'UTF8';
  FFBConn.Params.Values['PageSize']       := '8192';
  FFBConn.Params.Values['SQLDialect']     := '3';
  FFBConn.Params.Values['CreateDatabase'] := 'False';

  if not FileExists(FPathDB + 'Database.fdb') then
    FFBConn.Params.Values['CreateDatabase'] := 'True';

  FFBConn.Connected                       := True;
end;

procedure TControllerDatabase.CreateSQLiteDatabase;
begin
  FSQLiteConn.Params.Values['Database'] := FPathDB + 'Database.db';
  FSQLiteConn.Params.Values['OpenMode'] := 'CreateUTF8';
  FSQLiteConn.LoginPrompt               := False;

  FSQLiteConn.Connected                 := True;
end;

destructor TControllerDatabase.Destroy;
begin
  if Assigned(FDaoSQLite) then
    FreeAndNil(FDaoSQLite);
  if Assigned(FDaoFirebird) then
    FreeAndNil(FDaoFirebird);
  inherited;
end;

procedure TControllerDatabase.SetPathDB;
begin
  FPathDB := ExtractFilePath(ParamStr(0)) + 'DB\';

  if not DirectoryExists(FPathDB) then
    ForceDirectories(FPathDB);
end;

procedure TControllerDatabase.CreateTables;
begin
  FDaoSQLite.CreateTables;
  FDaoFirebird.CreateTables;
end;

end.
