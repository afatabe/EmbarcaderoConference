unit Frame.Bills.Payable.Registration;

interface

uses
  System.SysUtils, System.Types, System.UITypes, System.Classes, System.Variants, 
  FMX.Types, FMX.Graphics, FMX.Controls, FMX.Forms, FMX.Dialogs, FMX.StdCtrls,
  Frame.Base.Registration, System.Skia, FMX.ListView.Types, FMX.ListView.Appearances,
  FMX.ListView.Adapters.Base, System.ImageList, FMX.ImgList, System.Actions, FMX.ActnList,
  FMX.ListView, FMX.Controls.Presentation, FMX.Edit, FMX.Objects, FMX.Skia, FMX.Effects,
  FMX.Layouts, FMX.TabControl, Frame.Edit;

type
  TfrBillsPayableRegistration = class(TfrBaseRegistration)
    layEditsTop: TLayout;
    laySwFixedExpense: TLayout;
    swFixedExpense: TSwitch;
    sklblTitleFixedExpense: TSkLabel;
    laySwNumberOfInstallments: TLayout;
    swInstallments: TSwitch;
    sklblTitleInstalments: TSkLabel;
    layFrDescription: TLayout;
    frEdtDescription: TFrEdit;
    layFrValue: TLayout;
    frEdtValue: TFrEdit;
    layFrNumberOfInstallments: TLayout;
    frEdtNumberOfInstallments: TFrEdit;
    sklblTitleLv1: TSkLabel;
    SkLabel1: TSkLabel;
    SkLabel2: TSkLabel;
    procedure frEdtValueedtTyping(Sender: TObject);
    procedure swInstallmentsSwitch(Sender: TObject);
    procedure frEdtValueedtExit(Sender: TObject);
    procedure ListViewItemClickEx(const Sender: TObject; ItemIndex: Integer;
      const LocalClickPos: TPointF; const ItemObject: TListItemDrawable);
  private
    { Private declarations }
  public
    { Public declarations }
    procedure Save; override;
    procedure PopulateListView; override;
    procedure Load(const aItemIndex: Integer); override;
    procedure Delete(const AItemIndex: Integer); override;
    procedure CleanEdits; override;
  end;

var
  frBillsPayableRegistration: TfrBillsPayableRegistration;

implementation

uses
  Controller.Bills.Payable, Model.Helper.FormatOptions, Model.Bills.Interfaces,
  Model.Helper.ListView, System.StrUtils;

{$R *.fmx}

{ TfrBaseRegistration1 }

procedure TfrBillsPayableRegistration.frEdtValueedtExit(Sender: TObject);
begin
  inherited;
  frEdtValue.edt.Text := FormatFloat('R$#,##0.00', frEdtValue.edt.ToCurrency);
end;

procedure TfrBillsPayableRegistration.frEdtValueedtTyping(Sender: TObject);
begin
  inherited;
  frEdtValue.edt.FormatMoney;
end;

procedure TfrBillsPayableRegistration.swInstallmentsSwitch(Sender: TObject);
begin
  frEdtNumberOfInstallments.edt.Enabled := swInstallments.IsChecked;

  if not swInstallments.IsChecked then
    frEdtNumberOfInstallments.edt.Text := '0'
  else
    swFixedExpense.IsChecked := swInstallments.IsChecked;
end;

procedure TfrBillsPayableRegistration.CleanEdits;
begin
  frEdtDescription.Clean;
  frEdtValue.Clean;
  swFixedExpense.IsChecked        := False;
  swInstallments.IsChecked        := False;
  frEdtNumberOfInstallments.Clean;
end;

procedure TfrBillsPayableRegistration.Delete(const AItemIndex: Integer);
begin
  try
    TControllerBillsPayable.New.Inactivate(ListView.Items[AItemIndex].Tag);

    inherited;
  except on E: Exception do
    raise Exception.Create(E.Message);
  end;
end;

procedure TfrBillsPayableRegistration.PopulateListView;
begin
  try
    ListView.Items.Clear;

    for var xItem in TControllerBillsPayable.New.Bills do
    begin
      ListView.Populate(['lscDescription',
                        'lscValue',
                        'lscFixedExpense',
                        'lscNumberOfInstallments'],
                       [xItem.Description,
                        FormatFloat('R$#,##0.00', xItem.Value),
                        IfThen(xItem.Fixed               , 'Sim', 'N�o'),
                        IfThen(xItem.Installments        , 'Sim', 'N�o'),
                        xItem.Installment],
                       xItem.Id);
    end;
  except on E: Exception do
    raise Exception.Create(E.Message);
  end;
end;

procedure TfrBillsPayableRegistration.Save;
var xController: IControllerBillsPayable;
begin
  try
    swInstallmentsSwitch(nil);

    xController := TControllerBillsPayable.New;

    xController.Assign(frEdtDescription.Text,
                       frEdtValue.Money,
                       swFixedExpense.IsChecked,
                       swInstallments.IsChecked,
                       frEdtNumberOfInstallments.Text);
    xController.Validate.Save;
  except on E: Exception do
    raise Exception.Create(E.Message);
  end;
end;

procedure TfrBillsPayableRegistration.ListViewItemClickEx(const Sender: TObject; ItemIndex: Integer;
  const LocalClickPos: TPointF; const ItemObject: TListItemDrawable);
begin
  inherited;
  if ItemObject is TListItemAccessory then
  begin
    Load(ItemIndex);
    tbcMain.ActiveTab := tbiRegistration;
  end;
end;

procedure TfrBillsPayableRegistration.Load(const aItemIndex: Integer);
begin
  try
    with TControllerBillsPayable.New.Load(ListView.Items[aItemIndex].Tag).Bill do
    begin
        frEdtDescription.Text          := Description;
        frEdtValue.Text                := Value.ToString;
        swFixedExpense.IsChecked       := Fixed;
        swInstallments.IsChecked       := Installments;
        frEdtNumberOfInstallments.Text := Installment;
    end;

    swInstallmentsSwitch(nil);
    inherited;
  except on E: Exception do
    raise Exception.Create(E.Message);
  end;
  inherited;
end;

end.
