unit Frame.Base.Registration;

interface

uses
  System.SysUtils, System.Types, System.UITypes, System.Classes, System.Variants, 
  FMX.Types, FMX.Graphics, FMX.Controls, FMX.Forms, FMX.Dialogs, FMX.StdCtrls,
  FMX.TabControl, FMX.Layouts, FMX.ListView.Types, FMX.ListView.Appearances,
  FMX.ListView.Adapters.Base, FMX.ListView, FMX.Objects, FMX.Controls.Presentation, FMX.Edit,
  FMX.EditBox, FMX.NumberBox, FMX.SpinBox, System.Generics.Collections, System.Skia, FMX.Skia,
  FMX.Effects, System.Actions, FMX.ActnList, System.ImageList, FMX.ImgList,
  FireDAC.Stan.Intf, FireDAC.Stan.Option, FireDAC.Stan.Param, FireDAC.Stan.Error,
  FireDAC.DatS, FireDAC.Phys.Intf, FireDAC.DApt.Intf, FireDAC.Comp.DataSet,
  FireDAC.Comp.Client;

type
  TfrBaseRegistration = class(TFrame)
    tbcMain: TTabControl;
    tbiSearch: TTabItem;
    tbiRegistration: TTabItem;
    StyleBook: TStyleBook;
    layTop: TLayout;
    layListView: TLayout;
    recGrid: TRectangle;
    layBtnAdd: TLayout;
    recEditSearch: TRectangle;
    layEditSearch: TLayout;
    edtSearch: TEdit;
    crcBtnAdd: TCircle;
    layBottomRegistration: TLayout;
    layBtnSave: TLayout;
    layBtnBack: TLayout;
    crcBtnSave: TCircle;
    crcBtnBack: TCircle;
    layMainRegistration: TLayout;
    SKSave: TSkAnimatedImage;
    shBtnSave: TShadowEffect;
    shBtnAdd: TShadowEffect;
    SKAdd: TSkAnimatedImage;
    SKBack: TSkAnimatedImage;
    shBtnBack: TShadowEffect;
    imlistLV: TImageList;
    recBgTitlesLv: TRectangle;
    sklblTitleLv: TSkLabel;
    ListView: TListView;
    procedure crcBtnAddClick(Sender: TObject);
    procedure crcBtnBackClick(Sender: TObject);
    procedure crcBtnSaveMouseLeave(Sender: TObject);
    procedure crcBtnSaveMouseMove(Sender: TObject; Shift: TShiftState; X, Y: Single);
    procedure crcBtnAddMouseMove(Sender: TObject; Shift: TShiftState; X, Y: Single);
    procedure crcBtnAddMouseLeave(Sender: TObject);
    procedure crcBtnBackMouseMove(Sender: TObject; Shift: TShiftState; X, Y: Single);
    procedure crcBtnBackMouseLeave(Sender: TObject);
    procedure edtSearchKeyUp(Sender: TObject; var Key: Word; var KeyChar: WideChar;
      Shift: TShiftState);
    procedure crcBtnSaveClick(Sender: TObject);
  private
    { Private declarations }
  protected
    procedure Save; virtual; abstract;
    procedure PopulateListView; virtual; abstract;
    procedure Load(const aItemIndex: Integer); virtual; abstract;
    procedure Delete(const AItemIndex: Integer); virtual;
    procedure CleanEdits; virtual; abstract;
  public
    { Public declarations }
    constructor Create(AOwner: TComponent); override;
    destructor  Destroy; override;
  end;

implementation

uses
  Model.Helper.ListView;

{$R *.fmx}

constructor TfrBaseRegistration.Create(AOwner: TComponent);
begin
  inherited;
  PopulateListView;

  tbcMain.ActiveTab := tbiSearch;
end;

destructor TfrBaseRegistration.Destroy;
begin

  inherited;
end;

procedure TfrBaseRegistration.edtSearchKeyUp(Sender: TObject; var Key: Word; var KeyChar: WideChar;
  Shift: TShiftState);
begin
  if CharInSet(KeyChar, ['A'..'Z', 'a'..'z']) or (edtSearch.Text = EmptyStr)  then
  begin
    TThread.Queue(nil,
                  procedure
                  begin
                     ListView.SearchVisible := True;
                     try
                       ListView.SearchBox.Text := edtSearch.Text;
                     finally
                       ListView.SearchVisible := True;
                     end;
                  end);
  end;
end;

procedure TfrBaseRegistration.crcBtnAddClick(Sender: TObject);
begin
  CleanEdits;
  tbcMain.ActiveTab := tbiRegistration;
end;

procedure TfrBaseRegistration.Delete(const AItemIndex: Integer);
begin
  ListView.Items.Delete(AItemIndex);
end;

procedure TfrBaseRegistration.crcBtnAddMouseMove(Sender: TObject; Shift: TShiftState; X, Y: Single);
begin
  SKAdd.Animation.Enabled := True;
end;

procedure TfrBaseRegistration.crcBtnAddMouseLeave(Sender: TObject);
begin
  SKAdd.Animation.Enabled := False;
end;

procedure TfrBaseRegistration.crcBtnBackClick(Sender: TObject);
begin
  tbcMain.ActiveTab := tbiSearch;
  CleanEdits;
end;

procedure TfrBaseRegistration.crcBtnSaveMouseMove(Sender: TObject; Shift: TShiftState; X,
  Y: Single);
begin
  SKSave.Animation.Enabled := True;
end;

procedure TfrBaseRegistration.crcBtnSaveClick(Sender: TObject);
begin
  Save;
  PopulateListView;
  tbcMain.ActiveTab := tbiSearch;
end;

procedure TfrBaseRegistration.crcBtnSaveMouseLeave(Sender: TObject);
begin
  SKSave.Animation.Enabled := False;
end;

procedure TfrBaseRegistration.crcBtnBackMouseMove(Sender: TObject; Shift: TShiftState; X,
  Y: Single);
begin
  SKBack.Animation.Enabled := True;
end;

procedure TfrBaseRegistration.crcBtnBackMouseLeave(Sender: TObject);
begin
  SKBack.Animation.Enabled := False;
end;

end.
