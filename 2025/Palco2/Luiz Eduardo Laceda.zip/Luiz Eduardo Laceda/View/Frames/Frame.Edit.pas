unit Frame.Edit;

interface

uses
  System.SysUtils, System.Types, System.UITypes, System.Classes, System.Variants, 
  FMX.Types, FMX.Graphics, FMX.Controls, FMX.Forms, FMX.Dialogs, FMX.StdCtrls, FMX.Objects,
  FMX.Controls.Presentation, FMX.Layouts, FMX.Edit, System.Skia, FMX.Skia, FMX.MultiView,
  FMX.Effects;

type
  TFrEdit = class(TFrame)
    layMainEdit: TLayout;
    recEdit: TRectangle;
    edt: TEdit;
    sklblTitle: TSkLabel;
    glwError: TGlowEffect;
    sklblErrorMessage: TSkLabel;
  private
    { Private declarations }
    function GetText: string;
    function GetMoney: Currency;

    procedure SetText(const Value: string);
    procedure SetMoney(const Value: Currency);
  public
    { Public declarations }

    procedure Clean;
    procedure ApplyMask(const AValue: Currency; AFormat: string = 'R$#,##0.00');

    property Text: string read GetText write SetText;
    property Money: Currency read GetMoney write SetMoney;
  end;

implementation

uses Model.Helper.FormatOptions;

{$R *.fmx}

{ TFrEdit }

function TFrEdit.GetText: string;
begin
  Result := edt.Text;
end;

procedure TFrEdit.Clean;
begin
  edt.Text := EmptyStr;
end;

function TFrEdit.GetMoney: Currency;
begin
  Result := StrToCurrDef(edt.Text.Replace('R$', EmptyStr).Replace('.', EmptyStr), 0);
end;

procedure TFrEdit.SetMoney(const Value: Currency);
begin
  edt.Text := Value.ToString;
  edt.FormatMoney;
end;

procedure TFrEdit.SetText(const Value: string);
begin
  edt.Text := Value;
end;

procedure TFrEdit.ApplyMask(const AValue: Currency; AFormat: string);
begin
  edt.Text := FormatFloat(AFormat, AValue);
end;

end.
