unit View.Home;

interface

uses
  System.SysUtils, System.Types, System.UITypes, System.Classes, System.Variants,
  FMX.Types, FMX.Controls, FMX.Forms, FMX.Graphics, FMX.Dialogs, FMX.Effects,
  FMX.Objects, FMX.Layouts, Controller.Windows, System.Skia, FMX.Skia, FMX.Controls.Presentation,
  FMX.StdCtrls, FMX.Colors, FMX.ListBox, FMX.ExtCtrls;

type
  TFrHome = class(TForm)
    recBackground: TRectangle;
    shBackground: TShadowEffect;
    layTopBar: TLayout;
    layBtnClose: TLayout;
    crcBtnClose: TCircle;
    shBtnClose: TShadowEffect;
    layBtnMinimize: TLayout;
    crcBtnMinimize: TCircle;
    shBtnMinimize: TShadowEffect;
    layMainPage: TLayout;
    layMenuBar: TLayout;
    recMenubar: TRectangle;
    shMenubar: TShadowEffect;
    layWindows: TLayout;
    recBackgroundWindows: TRectangle;
    shWidows: TShadowEffect;
    layTitlesWindows: TLayout;
    recBgTitleHome: TRectangle;
    shBgTitleHome: TShadowEffect;
    SKHome: TSkAnimatedImage;
    recBgTitles: TRectangle;
    shBgTitles: TShadowEffect;
    sklblTitleWindow: TSkLabel;
    layBtnProducts: TLayout;
    recBtnProducts: TRectangle;
    glwBtnProducts: TGlowEffect;
    SKBtnProducts: TSkAnimatedImage;
    layBtnConfigs: TLayout;
    recBtnConfigs: TRectangle;
    glwBtnConfigs: TGlowEffect;
    SKBtnConfigs: TSkAnimatedImage;
    procedure crcBtnCloseClick(Sender: TObject);
    procedure crcBtnMinimizeClick(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure recBtnBillsRegistrationMouseMove(Sender: TObject; Shift: TShiftState; X, Y: Single);
    procedure recBtnBillsRegistrationMouseLeave(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure HandleExceptions(Sender: TObject; E: Exception);
    procedure recBgTitleHomeMouseMove(Sender: TObject; Shift: TShiftState; X, Y: Single);
    procedure recBgTitleHomeMouseLeave(Sender: TObject);
    procedure recBgTitleHomeClick(Sender: TObject);
    procedure layBtnProductsMouseLeave(Sender: TObject);
    procedure layBtnProductsMouseMove(Sender: TObject; Shift: TShiftState; X, Y: Single);
    procedure layBtnProductsClick(Sender: TObject);
    procedure layBtnConfigsMouseMove(Sender: TObject; Shift: TShiftState; X, Y: Single);
    procedure layBtnConfigsMouseLeave(Sender: TObject);
  private
    { Private declarations }
    FControllerWindows: TControllerWindows;

    procedure LeaveSelected(aComponents: array of TFmxObject; aTurnOn: Boolean);
    procedure SetWindowTitle(aTitle: string);
    procedure CreateWindow(aWindow: EWindows);
  public
    { Public declarations }
  end;

var
  FrHome: TFrHome;

implementation

uses
  View.Messages;

{$R *.fmx}

procedure TFrHome.crcBtnCloseClick(Sender: TObject);
begin
  Close;
end;

procedure TFrHome.crcBtnMinimizeClick(Sender: TObject);
begin
  WindowState := TWindowState.wsMinimized;
end;

procedure TFrHome.FormCreate(Sender: TObject);
begin
  Application.OnException := HandleExceptions;
end;

procedure TFrHome.FormDestroy(Sender: TObject);
begin
  if Assigned(FControllerWindows) then
      FreeAndNil(FControllerWindows);
end;

procedure TFrHome.HandleExceptions(Sender: TObject; E: Exception);
begin
  TFrMessages.NewMessage(E.ClassName + #13 + E.Message);
end;

procedure TFrHome.recBtnBillsRegistrationMouseMove(Sender: TObject; Shift: TShiftState; X,
  Y: Single);
begin
  shMenubar.Enabled := True;
end;

procedure TFrHome.recBgTitleHomeMouseLeave(Sender: TObject);
begin
  SKHome.Animation.Enabled := False;
end;

procedure TFrHome.recBgTitleHomeMouseMove(Sender: TObject; Shift: TShiftState; X, Y: Single);
begin
  SKHome.Animation.Enabled := True;
end;

procedure TFrHome.recBtnBillsRegistrationMouseLeave(Sender: TObject);
begin
  shMenubar.Enabled := False;
end;

procedure TFrHome.recBgTitleHomeClick(Sender: TObject);
begin
  recBgTitles.Visible := False;

  if Assigned(FControllerWindows) then
    FreeAndNil(FControllerWindows);
end;

procedure TFrHome.layBtnProductsClick(Sender: TObject);
begin
  CreateWindow(EWindows.wTeste);
end;

procedure TFrHome.CreateWindow(aWindow: EWindows);
begin
  if Assigned(FControllerWindows) then
    FreeAndNil(FControllerWindows);

  FControllerWindows := TControllerWindows.Create(recBackgroundWindows);

  FControllerWindows.CreateWindow(aWindow);
  SetWindowTitle(aWindow.toString);
end;

procedure TFrHome.layBtnProductsMouseMove(Sender: TObject; Shift: TShiftState; X, Y: Single);
begin
  LeaveSelected([recBtnProducts, glwBtnProducts, SKBtnProducts], True);
end;

procedure TFrHome.layBtnProductsMouseLeave(Sender: TObject);
begin
  LeaveSelected([recBtnProducts, glwBtnProducts, SKBtnProducts], False);
end;

procedure TFrHome.layBtnConfigsMouseMove(Sender: TObject; Shift: TShiftState; X, Y: Single);
begin
  LeaveSelected([recBtnConfigs, glwBtnConfigs, SKBtnConfigs], True);
end;

procedure TFrHome.layBtnConfigsMouseLeave(Sender: TObject);
begin
  LeaveSelected([recBtnConfigs, glwBtnConfigs, SKBtnConfigs], False);
end;

procedure TFrHome.LeaveSelected(aComponents: array of TFmxObject; aTurnOn: Boolean);
var I: integer;
begin
  for I := Low(aComponents) to High(aComponents) do
  begin
    if aComponents[I] is TRectangle then
      TRectangle(aComponents[I]).Visible := aTurnOn
    else
    if aComponents[I] is TGlowEffect then
      TGlowEffect(aComponents[I]).Enabled := aTurnOn
    else
    if aComponents[I] is TSkAnimatedImage then
      TSkAnimatedImage(aComponents[I]).Animation.Enabled := aTurnOn;

    shMenubar.Enabled := aTurnOn;
  end;
end;

procedure TFrHome.SetWindowTitle(aTitle: string);
begin
  recBgTitles.Visible   := True;
  sklblTitleWindow.Text := aTitle;
end;

end.
