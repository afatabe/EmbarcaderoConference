unit View.Messages;

interface

uses
  System.SysUtils, System.Types, System.UITypes, System.Classes, System.Variants,
  FMX.Types, FMX.Controls, FMX.Forms, FMX.Graphics, FMX.Dialogs, FMX.Objects, FMX.Effects,
  FMX.Layouts, FMX.Controls.Presentation, FMX.StdCtrls, System.Skia, FMX.Skia;

type
  ETypeMessage = (tpError, tpWarning, tpInfo);

  TFrMessages = class(TForm)
    recBackground: TRectangle;
    shBackground: TShadowEffect;
    crcIcon: TCircle;
    shIcon: TShadowEffect;
    layBottomRegistration: TLayout;
    layBtnSave: TLayout;
    crcBtnConfirm: TCircle;
    layMessage: TLayout;
    shBtnConfirm: TShadowEffect;
    SKConfirm: TSkAnimatedImage;
    SKIcon: TSkAnimatedImage;
    recBgMessage: TRectangle;
    sklblMessage: TSkLabel;
    procedure crcBtnConfirmClick(Sender: TObject);
    procedure SKConfirmMouseMove(Sender: TObject; Shift: TShiftState; X, Y: Single);
    procedure SKConfirmMouseLeave(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }

    class procedure NewMessage(const aMessage: string; aType: ETypeMessage = tpWarning);
  end;

var
  FrMessages: TFrMessages;

implementation

{$R *.fmx}

{ TFrMessages }

procedure TFrMessages.crcBtnConfirmClick(Sender: TObject);
begin
  Close;
end;

class procedure TFrMessages.NewMessage(const aMessage: string; aType: ETypeMessage);
var FrMessage: TFrMessages;
begin
  FrMessage := TFrMessages.Create(nil);
  try
    FrMessage.sklblMessage.Text := aMessage;

    FrMessage.ShowModal;
  finally
    FreeAndNil(FrMessage);
  end;
end;

procedure TFrMessages.SKConfirmMouseLeave(Sender: TObject);
begin
  SKConfirm.Animation.Enabled := False;
end;

procedure TFrMessages.SKConfirmMouseMove(Sender: TObject; Shift: TShiftState; X, Y: Single);
begin
  SKConfirm.Animation.Enabled := True;
end;

end.
