unit DAO.Bills.Payable;

interface

uses SrORM.Interfaces, DTO.Bills.Payable,
     System.Generics.Collections;

type
  TDaoBillsPayable = class
  private
    FDaoSQLite: IControllerSrORM<TDTOBillsPayable>;
    FDaoFirebird: IControllerSrORM<TDTOBillsPayable>;
    FTableBills: TDTOBillsPayable;

    function GetTableBills: TDTOBillsPayable;

    procedure SetTableBills(const Value: TDTOBillsPayable);
  public
    constructor Create;
    destructor Destroy; override;

    function BillsAlreadyExists: Boolean;
    function GetListOfBills: TObjectList<TDTOBillsPayable>;
    function GetBillById: TDTOBillsPayable;

    procedure Insert;
    procedure Update;
    procedure Delete;
    procedure Inactivate;

    property TableBills: TDTOBillsPayable read GetTableBills write SetTableBills;
  end;

implementation

uses
  DmConection, System.SysUtils, Controller.SrORM;

{ TDaoBills }

constructor TDaoBillsPayable.Create;
begin
  FDaoSQLite  := TControllerSrORM<TDTOBillsPayable>.New(DmConn.FdConnSQLite);
  FDaoFirebird:= TControllerSrORM<TDTOBillsPayable>.New(DmConn.FdConnFirebird);
  FTableBills := TDTOBillsPayable.Create;
end;

destructor TDaoBillsPayable.Destroy;
begin
  if Assigned(FTableBills) then
    FreeAndNil(FTableBills);

  inherited;
end;

function TDaoBillsPayable.GetTableBills: TDTOBillsPayable;
begin
  Result := FTableBills;
end;

procedure TDaoBillsPayable.SetTableBills(const Value: TDTOBillsPayable);
begin
  FTableBills := Value;
end;

procedure TDaoBillsPayable.Inactivate;
begin
  FTableBills.Inactive := True;

  FDaoSQLite.DML.Update(FTableBills);
  FDaoFirebird.DML.Update(FTableBills);
end;

procedure TDaoBillsPayable.Insert;
begin
  FTableBills.Description := FTableBills.Description + ' ' + DmConn.FdConnSQLite.DriverName;
  FDaoSQLite.DML.Insert(FTableBills);
  FTableBills.Description := FTableBills.Description.Replace(DmConn.FdConnSQLite.DriverName,
    DmConn.FdConnFirebird.DriverName);
  FDaoFirebird.DML.Insert(FTableBills);
end;

procedure TDaoBillsPayable.Update;
begin
  FDaoSQLite.DML.Update(FTableBills);
  FDaoFirebird.DML.Update(FTableBills);
end;

procedure TDaoBillsPayable.Delete;
begin
  FDaoSQLite.DML.Delete(FTableBills);
  FDaoFirebird.DML.Delete(FTableBills);
end;

function TDaoBillsPayable.BillsAlreadyExists: Boolean;
var xList: TObjectList<TDTOBillsPayable>;
    xItem: TDTOBillsPayable;
begin
  Result := False;
  try
    xList := TObjectList<TDTOBillsPayable>.Create;

    FDaoSQLite.DML
              .Select
              .Fields
              .Where(' Description = ' + QuotedStr(FTableBills.Description))
              .Execute(xList);

    for xItem in xList do
    begin
      Result := xItem.Id > 0;

      FTableBills.Id := xItem.Id;
    end;
  finally
      FreeAndNil(xList);
  end;
end;

function TDaoBillsPayable.GetBillById: TDTOBillsPayable;
begin
  Result := TDTOBillsPayable.Create;
  FDaoSQLite.DML
            .Select
            .Fields
            .Where(' Id = ' + IntToStr(FTableBills.Id))
            .Execute(Result);

  FDaoFirebird.DML
              .Select
              .Fields
              .Where(' Id = ' + IntToStr(FTableBills.Id))
              .Execute(Result);
end;

function TDaoBillsPayable.GetListOfBills: TObjectList<TDTOBillsPayable>;
begin
  Result := TObjectList<TDTOBillsPayable>.Create;
  FDaoSQLite.DML
            .Select
            .OrderBy('Description')
            .Execute(Result);

  FDaoFirebird.DML
              .Select
              .OrderBy('Description')
              .Execute(Result);
end;

end.
