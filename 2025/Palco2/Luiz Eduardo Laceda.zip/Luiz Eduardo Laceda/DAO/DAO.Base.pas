unit DAO.Base;

interface

uses
  FireDAC.Comp.Client, FireDAC.DApt;

type
  TDAOBase = class
  private
    FConnection: TFDConnection;

    function GetConnection: TFDConnection;
  public
    constructor Create;

    property Connection: TFDConnection read GetConnection;
  end;

implementation

uses DmConection;

{ TDAOBase }

constructor TDAOBase.Create;
begin
  FConnection := DmConn.FdConn;
end;

function TDAOBase.GetConnection: TFDConnection;
begin
  Result := FConnection;
end;

end.
