unit DTO.Bills.Payable;

interface

uses SrORM.Attributes, Model.Bills.Payable;

type
  [TTable('BillsPayable', True)]
  TDTOBillsPayable = class sealed
  private
    {$REGION ' Fields '}
    FId: Integer;
    FDescription: string;
    FValue: Currency;
    FFixedExpense: Boolean;
    FInstallments: Boolean;
    FNumberOfInstallments: Integer;
    FActualInstallment: Integer;
    FInactive: Boolean;
    {$ENDREGION}
  public
    [TField('Id'), PK, AutoInc]
    property Id: Integer                   read FId                   write FId;
    [TField('Description', '75'), NotNull]
    property Description: string           read FDescription          write FDescription;
    [TField('Bill_Value', '15,2'), NotNull]
    property Value: Currency               read FValue                write FValue;
    [TField('FixedExpense'), NotNull]
    property FixedExpense: Boolean         read FFixedExpense         write FFixedExpense;
    property Installments: Boolean         read FInstallments         write FInstallments;
    [TField('NumberOfInstallments')]
    property NumberOfInstallments: Integer read FNumberOfInstallments write FNumberOfInstallments;
    [TField('ActualInstallment')]
    property ActualInstallment: Integer    read FActualInstallment    write FActualInstallment;
    property Inactive: Boolean             read FInactive             write FInactive;

    procedure Assign(ABill: TDTOBillsPayable); overload;
    procedure Assign(ABill: TBillsPayable); overload;
    procedure Bind(ABill: TBillsPayable);
  end;

implementation

{ TDTOBillsPayable }

procedure TDTOBillsPayable.Assign(ABill: TDTOBillsPayable);
begin
  FId                   := ABill.Id;
  FDescription          := ABill.Description;
  FValue                := ABill.Value;
  FFixedExpense         := ABill.FixedExpense;
  FInstallments         := ABill.Installments;
  FNumberOfInstallments := ABill.NumberOfInstallments;
  FActualInstallment    := ABill.ActualInstallment;
  FInactive             := ABill.Inactive;
end;

procedure TDTOBillsPayable.Assign(ABill: TBillsPayable);
begin
  FId                   := ABill.Id;
  FDescription          := ABill.Description;
  FValue                := ABill.Value;
  FFixedExpense         := ABill.Fixed;
  FInstallments         := ABill.Installments;
  FNumberOfInstallments := ABill.NumberOfInstallments;
  FActualInstallment    := ABill.ActualInstallment;
  FInactive             := ABill.Inactive;
end;

procedure TDTOBillsPayable.Bind(ABill: TBillsPayable);
begin
  ABill.Id                    := FId;
  ABill.Description           := FDescription;
  ABill.Value                 := FValue;
  ABill.Fixed                 := FFixedExpense;
  ABill.Installments          := FInstallments;
  ABill.NumberOfInstallments  := FNumberOfInstallments;
  ABill.ActualInstallment     := FActualInstallment;
  ABill.Inactive              := FInactive;
end;

end.
