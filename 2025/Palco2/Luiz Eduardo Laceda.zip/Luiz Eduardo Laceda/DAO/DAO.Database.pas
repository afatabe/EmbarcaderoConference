unit DAO.Database;

interface

uses
  FireDAC.Comp.Client, FireDAC.DApt;

type
  TDaoDatabase = class
  private
    FConnection: TFDConnection;
  public
    constructor Create(AConnection: TFDConnection);

    procedure CreateTables;
  end;

implementation

uses
  System.SysUtils, Controller.SrORM, DTO.Bills.Payable,
  System.Generics.Collections;

{ TDaoDatabase }

constructor TDaoDatabase.Create(AConnection: TFDConnection);
begin
  FConnection := AConnection;
end;

procedure TDaoDatabase.CreateTables;
begin
  try
    TControllerSrORM<TDTOBillsPayable>.New(FConnection).DDL.CreateTable.AddNewFields;
  except on E: Exception do
    raise Exception.Create(E.Message);
  end;
end;

end.
