unit Model.Validation.Codes;

interface

type
  EValidationCodes = (vcNone= 700, vcInvalidValue = 701);

  TValidationCodes = class
  private
    const
      ECodeString: array[EValidationCodes] of string = (
        '',
        'Conte�do Inv�lido');
  public
    class function Description(ACode: EValidationCodes): string;
  end;

implementation

{ TValidationCodes }

class function TValidationCodes.Description(ACode: EValidationCodes): string;
begin
  Result := ECodeString[ACode];
end;

end.
