unit Model.Helper.FormatOptions;

interface

uses FMX.Edit, System.SysUtils;

type
  TEditHelper = class helper for TEdit
  private

  public
    function OnlyNumbers: string;
    function GetActualMonth(const aLocaleName: string): string;
    function UpperCaseFirstLetter: string;

    function ToCurrency: Currency;

    procedure FormatMoney;
  end;

implementation

uses
  System.Character, DateUtils;

{ TEditHelper }

function TEditHelper.OnlyNumbers: string;
var Aux : Char;
    Text: string;
begin
  Result := EmptyStr;

  Text  := Trim(Self.Text);

  for Aux in Text do
  begin
    if Aux.IsDigit then
      Result := Result + Aux;
  end;
end;

procedure TEditHelper.FormatMoney;
var
  Value: Double;
  Text : string;
begin
  Text := StringReplace(Self.Text, '.', '', [rfReplaceAll]);
  Text := StringReplace(Text, ',', '', [rfReplaceAll]);

  if TryStrToFloat(Text, Value) then
    Self.Text := FormatFloat('#,##0.00', Value / 100)
  else
    Self.Text := '0,00';

  Self.GoToTextEnd;
end;

function TEditHelper.ToCurrency: Currency;
begin
  Result := StrToCurrDef(Self.Text.Replace('R$', EmptyStr).Replace('.', EmptyStr), 0);
end;

function TEditHelper.GetActualMonth(const aLocaleName: string): string;
var Fs: TFormatSettings;
begin
  Fs       := TFormatSettings.Create(aLocaleName);
  Self.Text := Fs.LongMonthNames[MonthOf(Now)];
end;

function TEditHelper.UpperCaseFirstLetter: string;
begin
  Self.Text := UpperCase(Self.Text[1]) + LowerCase(Copy(Self.Text, 2, Length(Self.Text)));
end;

end.
