unit Model.Helper.ListView;

interface

uses FMX.ListView, FMX.ListView.Appearances, FMX.ListView.Types, FMX.SearchBox, FMX.Types,
    System.SysUtils, Generics.Collections;

type
  EListViewCheckBoxControl = (cbUnchecked = 1, cbChecked = 2);

  THelperListView = class helper for TListView
  public
    function SearchBox: TSearchBox;

    function SumValue(aField: string): Currency;
    function SumValueIfChecked(aField: string): Currency;
    function ItemAlreadyExists(aField, aValue: string): Boolean;

    procedure Populate(const aFields, AValues: array of string; aTag: Integer = 0; aTagString: string = '');
    procedure GetListOfCheckeds(AList: TList<Integer>);
  end;

  THelperListViewItemText = class helper for TListViewItem
  public
    procedure AddItemTextValue(const aName: string; aValue: string);
    function GetItemTextValue(const aName: string): string;
  end;

implementation

uses System.UITypes;

{ THelperListView }

function THelperListView.SearchBox: TSearchBox;
var I: Integer;
begin
  Result := nil;

  for I := 0 to Pred(Self.ChildrenCount) do
  begin
    if Self.Children[I] is TSearchBox then
      Result := TSearchBox(Self.Children[I]);
  end;
end;

function THelperListView.SumValue(aField: string): Currency;
var Item: TListViewItem;
    Obj: TListItemText;
begin
  Result := 0;

  for Item in Self.Items do
  begin
    Obj   := TListItemText(Item.Objects.FindDrawable(aField));
    Result := Result + StrToCurr(Obj.Text.Replace('R$', EmptyStr).Replace('.', EmptyStr));
  end;
end;

function THelperListView.SumValueIfChecked(aField: string): Currency;
var Item: TListViewItem;
    Obj: TListItemText;
begin
  Result := 0;

  for Item in Self.Items do
  begin
    var xCheckbox := Item.Objects.FindObjectT<TListItemImage>('liCheckbox');

    if (Assigned(xCheckbox)) and (xCheckbox.ImageIndex = TImageIndex(cbChecked)) then
    begin
      Obj   := TListItemText(Item.Objects.FindDrawable(aField));
      Result := Result + StrToCurr(Obj.Text.Replace('R$', EmptyStr).Replace('.', EmptyStr));
    end;
  end;
end;

procedure THelperListView.GetListOfCheckeds(AList: TList<Integer>);
var Item: TListViewItem;
begin
  for Item in Self.Items do
  begin
    var xCheckbox := Item.Objects.FindObjectT<TListItemImage>('liCheckbox');

    if (Assigned(xCheckbox)) and (xCheckbox.ImageIndex = TImageIndex(cbChecked)) then
    begin
      if AList.IndexOf(Item.Tag) < 0 then
        AList.Add(Item.Tag);
    end;
  end;
end;

function THelperListView.ItemAlreadyExists(aField, aValue: string): Boolean;
var Item: TListViewItem;
    Obj: TListItemText;
begin
  Result := False;

  for Item in Self.Items do
  begin
    Obj   := TListItemText(Item.Objects.FindDrawable(aField));
    Result := Obj.Text = aValue;

    if Result then
      Break;
  end;
end;

procedure THelperListView.Populate(const aFields, AValues: array of string;
    aTag: Integer = 0; aTagString: string = '');
var Item: TListViewItem;
    I    : Integer;
begin
  Self.BeginUpdate;
  try
    Item := Self.Items.Add;

    if aTag > 0 then
      Item.Tag := aTag
    else
      Item.TagString := aTagString;

    for I := Low(aFields) to High(aFields) do
      Item.AddItemTextValue(aFields[I], AValues[I]);
  finally
    Self.EndUpdate;
  end;
end;

{ THelperListViewItemText }

procedure THelperListViewItemText.AddItemTextValue(const aName: string; aValue: string);
var Obj: TListItemText;
begin
  Obj      := TListItemText(Self.Objects.FindDrawable(aName));
  Obj.Text := aValue;
end;

function THelperListViewItemText.GetItemTextValue(const aName: string): string;
begin
  Result := TListItemText(Self.Objects.FindDrawable(aName)).Text;
end;

end.

