unit Model.Bills.Payable;

interface

uses
  Model.Bills, System.Generics.Collections;

type
  TBillsPayable = class sealed(TBills)
  private
    FInstallments: Boolean;
    FInstallment: string;
    FNumberOfInstallments: Integer;
    FActualInstallment: Integer;

    function GetInstallments: Boolean;
    function GetInstallment: string;
    function GetNumberOfInstallments: Integer;
    function GetActualInstallment: Integer;

    procedure SetInstallments(const Value: Boolean);
    procedure SetInstallment(const Value: string);
    procedure SetNumberOfInstallments(const Value: Integer);
    procedure SetActualInstallment(const Value: Integer);
  public
    procedure Assign(aBill: TBillsPayable; aMonthlyClosing: Boolean = False);

    procedure Validate;

    function GetListOfBills: TObjectList<TBillsPayable>;

    procedure Save;
    procedure Inactivate;
    procedure GetBill;

    property Installments: Boolean         read GetInstallments         write SetInstallments;
    property Installment: string           read GetInstallment          write SetInstallment;
    property NumberOfInstallments: Integer read GetNumberOfInstallments write SetNumberOfInstallments;
    property ActualInstallment: Integer    read GetActualInstallment    write SetActualInstallment;
  end;

implementation

uses
  System.SysUtils, DAO.Bills.Payable, DTO.Bills.Payable;

{ TBills }

function TBillsPayable.GetInstallments: Boolean;
begin
  Result := FInstallments;
end;

function TBillsPayable.GetInstallment: string;
begin
  if FNumberOfInstallments > 0 then
    Result := IntToStr(FActualInstallment) + '/' + IntToStr(FNumberOfInstallments)
  else
    Result := EmptyStr;
end;

function TBillsPayable.GetNumberOfInstallments: Integer;
begin
  Result := FNumberOfInstallments;
end;

function TBillsPayable.GetActualInstallment: Integer;
begin
  Result := FActualInstallment;
end;

procedure TBillsPayable.SetInstallments(const Value: Boolean);
begin
  FInstallments := Value;
end;

procedure TBillsPayable.SetInstallment(const Value: string);
begin
  if Pos('/', Value) > 0 then
  begin
    FActualInstallment    := StrToInt(Copy(Value,
                                       1,
                                       Pos('/', Value) - 1));
    FNumberOfInstallments := StrToInt(Copy(Value,
                                       Pos('/', Value) + 1,
                                       Length(Value)));
  end
  else
  begin
    FActualInstallment    := 1;
    FNumberOfInstallments := StrToInt(Value);
  end;
end;

procedure TBillsPayable.SetNumberOfInstallments(const Value: Integer);
begin
  FNumberOfInstallments := Value;
end;

procedure TBillsPayable.SetActualInstallment(const Value: Integer);
begin
  FActualInstallment := Value;
end;

procedure TBillsPayable.Assign(aBill: TBillsPayable; aMonthlyClosing: Boolean);
begin
  inherited Assign(aBill);

  FInstallments        := aBill.Installments;
  FInstallment         := aBill.Installment;
  FNumberOfInstallments:= aBill.NumberOfInstallments;

  if (aMonthlyClosing) and (aBill.ActualInstallment < aBill.NumberOfInstallments) then
    FActualInstallment := aBill.ActualInstallment + 1
  else
    FActualInstallment   := aBill.ActualInstallment;
end;

procedure TBillsPayable.Validate;
begin
  if Self.Description.Trim.IsEmpty then
    raise Exception.Create('Descri��o da conta n�o poder� ser vazia, por favor verifique!');

  if Self.Value <= 0 then
    raise Exception.Create('Valor da conta n�o poder� ser menor ou igual a zero, por favor verifique!');

  if (FInstallments) and (FNumberOfInstallments = 0) then
    raise Exception.Create('Foi indicado conta a prazo e N�O foi informado o n�mero de parcelas, por favor verifique!');
end;

function TBillsPayable.GetListOfBills: TObjectList<TBillsPayable>;
begin
  Result := TObjectList<TBillsPayable>.Create;

  var xDao := TDaoBillsPayable.Create;
  var xList:= xDao.GetListOfBills;
  try
    for var xItem in xList do
    begin
      var xBill := TBillsPayable.Create;
      xItem.Bind(xBill);
      Result.Add(xBill);
    end;
  finally
    FreeAndNil(xList);
    FreeAndNil(xDao);
  end;
end;

procedure TBillsPayable.GetBill;
var xTable: TDTOBillsPayable;
begin
  var xDao := TDaoBillsPayable.Create;
  try
    xDao.TableBills.Id := Self.Id;

    xTable := xDao.GetBillById;
    xTable.Bind(Self);
  finally
    FreeAndNil(xTable);
    FreeAndNil(xDao);
  end;
end;

procedure TBillsPayable.Save;
begin
  var xDao := TDaoBillsPayable.Create;
  try
    xDao.TableBills.Assign(Self);

    if not xDao.BillsAlreadyExists then
      xDao.Insert
    else
      xDao.Update;
  finally
    FreeAndNil(xDao);
  end;
end;

procedure TBillsPayable.Inactivate;
begin
  var xDao := TDaoBillsPayable.Create;
  try
    xDao.TableBills.Assign(Self);
    xDao.Inactivate;
  finally
    FreeAndNil(xDao);
  end;
end;

end.
