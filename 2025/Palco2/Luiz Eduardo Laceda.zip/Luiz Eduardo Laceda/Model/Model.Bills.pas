unit Model.Bills;

interface

type
  TBills = class
  private
    FId: Integer;
    FFK: Integer;
    FDescription: string;
    FValue: Currency;
    FFixed: Boolean;
    FInactive: Boolean;
  protected
    procedure Assign(aBill: TBills);
  public
    property Id: Integer               read FId          write FId;
    property FK: Integer               read FFK          write FFK;
    property Description: string       read FDescription write FDescription;
    property Value: Currency           read FValue       write FValue;
    property Fixed: Boolean            read FFixed       write FFixed;
    property Inactive: Boolean         read FInactive    write FInactive;
  end;

implementation

uses
  System.SysUtils;

{ TBills }

procedure TBills.Assign(aBill: TBills);
begin
  FId         := aBill.Id;
  FFK         := aBill.FK;
  FDescription:= aBill.Description;
  FValue      := aBill.Value;
  FFixed      := aBill.Fixed;
end;
end.
