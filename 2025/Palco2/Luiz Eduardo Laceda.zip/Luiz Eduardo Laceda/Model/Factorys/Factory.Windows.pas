unit Factory.Windows;

interface

uses FMX.Forms, System.Classes;

type
  EWindow = (wTeste, wConfigs);

  IFactoryWindows = interface
    ['{B78DD598-18CC-4A6B-9EBB-E0186F4437FC}']

    function CreateWindow(AWindow: EWindow): TFrame;
  end;

  TFactoryWindows = class(TInterfacedObject, IFactoryWindows)
  private

  public
    class function New: IFactoryWindows;

    function CreateWindow(AWindow: EWindow): TFrame;
  end;

implementation

uses Frame.Base.Registration, Frame.Bills.Payable.Registration;

{ TFactoryWindows }

class function TFactoryWindows.New: IFactoryWindows;
begin
  Result := Self.Create;
end;

function TFactoryWindows.CreateWindow(AWindow: EWindow): TFrame;
begin
  Result := TfrBillsPayableRegistration.Create(nil);
end;

end.
