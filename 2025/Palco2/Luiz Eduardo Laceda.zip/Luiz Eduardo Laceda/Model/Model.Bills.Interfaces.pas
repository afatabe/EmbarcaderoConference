unit Model.Bills.Interfaces;

interface

uses
  System.Generics.Collections, Model.Bills.Payable,
  System.Classes, System.SysUtils;

type
  IControllerBillsPayable = interface
    ['{80656C22-60CF-42A6-B211-158CFE34A40C}']

    function GetBills: TObjectList<TBillsPayable>;
    function GetBill: TBillsPayable;

    function Validate: IControllerBillsPayable;
    function Save: IControllerBillsPayable;
    function Inactivate(const aId: Integer): IControllerBillsPayable;
    function Load(AId: Integer): IControllerBillsPayable;

    function Assign(aDescription: string; aValue: Currency; aFixedExpense, aInstallments: Boolean;
                    aNumberOfInstallments: string): IControllerBillsPayable; overload;
    function Assign(aBill: TBillsPayable): IControllerBillsPayable; overload;

    property Bills: TObjectList<TBillsPayable> read GetBills;
    property Bill: TBillsPayable read GetBill;
  end;

implementation

end.
