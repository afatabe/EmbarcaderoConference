program SrCrudRTTI;

uses
  System.StartUpCopy,
  FMX.Forms,
  View.Home in 'View\View.Home.pas' {FrHome},
  Controller.Windows in 'Controller\Controller.Windows.pas',
  View.Messages in 'View\View.Messages.pas' {FrMessages},
  Factory.Windows in 'Model\Factorys\Factory.Windows.pas',
  Frame.Base.Registration in 'View\Frames\Frame.Base.Registration.pas' {frBaseRegistration: TFrame},
  Model.Helper.ListView in 'Model\Helpers\Model.Helper.ListView.pas',
  Model.Helper.FormatOptions in 'Model\Helpers\Model.Helper.FormatOptions.pas',
  DmConection in 'Datamodules\DmConection.pas' {DmConn: TDataModule},
  Controller.Database in 'Controller\Controller.Database.pas',
  DAO.Database in 'DAO\DAO.Database.pas',
  Controller.SrORM.DB in 'ORM\Controller\Controller.SrORM.DB.pas',
  Controller.SrORM in 'ORM\Controller\Controller.SrORM.pas',
  DAO.SrORM in 'ORM\DAO\DAO.SrORM.pas',
  SrORM.Data.Interfaces in 'ORM\Model\DataInfo\SrORM.Data.Interfaces.pas',
  SrORM.Data in 'ORM\Model\DataInfo\SrORM.Data.pas',
  SrORM.Data.TableMetadata in 'ORM\Model\DataInfo\SrORM.Data.TableMetadata.pas',
  SrORM.DB.Consts in 'ORM\Model\DB\SrORM.DB.Consts.pas',
  SrORM.DB.Factory in 'ORM\Model\DB\SrORM.DB.Factory.pas',
  SrORM.DB.Interfaces in 'ORM\Model\DB\SrORM.DB.Interfaces.pas',
  SrORM.DB.SQLite in 'ORM\Model\DB\SrORM.DB.SQLite.pas',
  SrORM.DDL in 'ORM\Model\DDL\SrORM.DDL.pas',
  SrORM.DML in 'ORM\Model\DML\SrORM.DML.pas',
  SrORM.Attributes in 'ORM\Model\SrORM.Attributes.pas',
  SrORM.Interfaces in 'ORM\Model\SrORM.Interfaces.pas',
  DTO.Bills.Payable in 'DAO\DTOs\DTO.Bills.Payable.pas',
  SrORM.DB.Firebird in 'ORM\Model\DB\SrORM.DB.Firebird.pas',
  SrORM.QueryBuilder in 'ORM\Model\SrORM.QueryBuilder.pas',
  SrORM.RTTI in 'ORM\Model\SrORM.RTTI.pas',
  SrORM.Utils in 'ORM\Model\SrORM.Utils.pas',
  Frame.Edit in 'View\Frames\Frame.Edit.pas' {FrEdit: TFrame},
  Controller.Bills.Payable in 'Controller\Controller.Bills.Payable.pas',
  Model.Bills.Interfaces in 'Model\Model.Bills.Interfaces.pas',
  Model.Bills.Payable in 'Model\Model.Bills.Payable.pas',
  Model.Bills in 'Model\Model.Bills.pas',
  DAO.Bills.Payable in 'DAO\DAO.Bills.Payable.pas',
  Frame.Bills.Payable.Registration in 'View\Frames\Frame.Bills.Payable.Registration.pas' {frBillsPayableRegistration: TFrame};

{$R *.res}

begin
  Application.Initialize;
  Application.CreateForm(TFrHome, FrHome);
  Application.CreateForm(TDmConn, DmConn);
  Application.CreateForm(TfrBillsPayableRegistration, frBillsPayableRegistration);
  Application.Run;
end.
