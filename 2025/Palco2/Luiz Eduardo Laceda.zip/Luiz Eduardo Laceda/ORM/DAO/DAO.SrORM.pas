unit DAO.SrORM;

interface
{$M+}
uses
  SrORM.Interfaces, SrORM.Data.Interfaces, Rtti, FireDAC.Comp.Client, FireDAC.DApt, System.TypInfo,
  Generics.Collections, Data.DB, SrORM.Data.TableMetadata;

type
  TDAOSrORM<T: class, constructor> = class(TInterfacedObject, IDAO<T>)
  private
    FConnection: TFDConnection;
    FRTTI: IRTTI<T>;

    procedure ProcessQryResult(AQry: TFDQuery; const ATableData: ITableData;
      const AFieldsData: TList<IFieldData>; out AObj: T; out AList: TObjectList<T>);
    procedure SetPKValue(AQry: TFDQuery; const ATableData: ITableData;
      const AFieldsData: TList<IFieldData>; out AObj: T);
  public
    class function New(const AConnection: TFDConnection): IDAO<T>;
    constructor Create(const AConnection: TFDConnection);

    class function TableExists(const AConnection: TFDConnection): Boolean;
    class function TableMatadata(const AConnection: TFDConnection): TDictionary<string, ITableMetadata>;

    procedure ExecuteComand(const ASQL: string; const AComand: EQueryComand; const ATableData: ITableData;
      const AFieldsData: TList<IFieldData>; out AObj: T; out AList: TObjectList<T>);
  end;

implementation

uses System.SysUtils, SrORM.Data, System.StrUtils, SrORM.RTTI, SrORM.DB.Consts,
  SrORM.Utils;

{ TDAOSrORM<T> }

class function TDAOSrORM<T>.New(const AConnection: TFDConnection): IDAO<T>;
begin
  Result := Self.Create(AConnection);
end;

constructor TDAOSrORM<T>.Create(const AConnection: TFDConnection);
begin
  FConnection := AConnection;
  FRTTI := TSrORMRTTI<T>.New;
end;

class function TDAOSrORM<T>.TableExists(const AConnection: TFDConnection): Boolean;
var TableData : ITableData;
    FieldsData: TList<IFieldData>;
    RTTI: IRTTI<T>;
begin
  TableData  := TTableData.New;
  FieldsData := TList<IFieldData>.Create;
  RTTI       := TSrORMRTTI<T>.New;
  try
    try
      RTTI.GetObjData(TableData, FieldsData);
      Result := TTableMetadata.New.TableExists(TableData.Name, AConnection);
    finally
      FreeAndNil(FieldsData);
    end;
  except on E: Exception do
    raise Exception.Create(Format('N�o foi possivel verificar se a tabela "%s" existe, motivo: ' +
      E.Message, [TableData.Name]));
  end;
end;

class function TDAOSrORM<T>.TableMatadata(const AConnection: TFDConnection): TDictionary<string, ITableMetadata>;
var TableData : ITableData;
    FieldsData: TList<IFieldData>;
    RTTI: IRTTI<T>;
begin
  TableData  := TTableData.New;
  FieldsData := TList<IFieldData>.Create;
  RTTI       := TSrORMRTTI<T>.New;
  try
    try
      RTTI.GetObjData(TableData, FieldsData);
      Result := TTableMetadata.New.GetTableMetadata(TableData.Name, AConnection);
    finally
      FreeAndNil(FieldsData);
    end;
  except on E: Exception do
    raise Exception.Create(Format('N�o foi possivel verificar os dados da tabela "%s", motivo: ' +
      E.Message, [TableData.Name]));
  end;
end;

procedure TDAOSrORM<T>.ExecuteComand(const ASQL: string; const AComand: EQueryComand; const ATableData: ITableData;
  const AFieldsData: TList<IFieldData>; out AObj: T; out AList: TObjectList<T>);
var Qry: TFDQuery;
begin
  try
    Qry := TFDQuery.Create(nil);
    try
      Qry.Connection := FConnection;
      Qry.SQL.Add(ASQL);

      if (not (AComand in ESelectComands)) and (not FConnection.InTransaction) then
        FConnection.StartTransaction;

      if AComand in ESelectComands then
        Qry.Open
      else
        Qry.ExecSQL;

      if FConnection.InTransaction then
        FConnection.Commit;

      if (AComand in ESelectComands) and (not Qry.IsEmpty) then
        ProcessQryResult(Qry, ATableData, AFieldsData, AObj, AList);

      if AComand = qcINSERT  then
        SetPKValue(Qry, ATableData, AFieldsData, AObj)
    finally
      FreeAndNil(Qry);
    end;
  except on E: Exception do
    begin
      if FConnection.InTransaction then
        FConnection.Rollback;

      raise Exception.Create('N�o foi possivel executar o comando: ' + ASQL);
    end;
  end;
end;

procedure TDAOSrORM<T>.ProcessQryResult(AQry: TFDQuery;
  const ATableData: ITableData; const AFieldsData: TList<IFieldData>; out AObj: T;
  out AList: TObjectList<T>);
begin
  FRTTI.GetQryData(AQry, ATableData, AObj, AList);
end;

procedure TDAOSrORM<T>.SetPKValue(AQry: TFDQuery; const ATableData: ITableData;
  const AFieldsData: TList<IFieldData>; out AObj: T);
var ValuePk, IndexPk: Integer;
begin
  IndexPk := TSrORMUtils<T>.GetIndexPkField(AFieldsData);
  if FConnection.DriverName.ToUpper = 'FB' then
  begin
    AQry.Open(Format(cMax_PK, [AFieldsData[IndexPk].Name, ATableData.Name]));
    ValuePk := AQry.Fields[0].AsInteger;
  end
  else
    ValuePk := FConnection.GetLastAutoGenValue(ATableData.Name);

  FRTTI.SetPkValue(AObj, ValuePk);
end;

end.
