unit SrORM.Data.Interfaces;

interface

uses
  SrORM.Attributes, System.TypInfo;

type
  ITableData = interface
    ['{3BB28350-6B29-49E9-B709-4AEE55868C01}']
    function GetName: string;
    function GetDefaultNameFields: Boolean;

    procedure SetName(const Value: string);
    procedure SetDefaultNameFields(const Value: Boolean);

    property Name             : string  read GetName              write SetName;
    property DefaultNameFields: Boolean read GetDefaultNameFields write SetDefaultNameFields;
  end;

  IFKData = interface
    ['{D3D8FFEF-3FEF-4266-8550-6CF86709FF91}']
    function GetTableName: string;
    function GetField: string;
    function GetDefaultValue: string;

    procedure SetTableName(const Value: string);
    procedure SetField(const Value: string);
    procedure SetDefaultValue(const Value: string);

    property TableName   : string read GetTableName    write SetTableName;
    property Field       : string read GetField        write SetField;
    property DefaultValue: string read GetDefaultValue write SetDefaultValue;
  end;

  IFieldData = interface
    ['{F9E95C87-57CA-4738-85C1-9BC2AF737E0C}']
    function GetName: string;
    function GetTType: TTypeKind;
    function GetHandle: PTypeInfo;
    function GetPK: Boolean;
    function GetFK: IFKData;
    function GetAutoInc: Boolean;
    function GetNotNull: Boolean;
    function GetIgnore: Boolean;
    function GetDefaultValue: string;
    function GetSize: string;

    procedure SetName(const Value: string);
    procedure SetTType(const Value: TTypeKind);
    procedure SetHandle(const Value: PTypeInfo);
    procedure SetPK(const Value: Boolean);
    procedure SetFK(const Value: IFKData);
    procedure SetAutoInc(const Value: Boolean);
    procedure SetNotNull(const Value: Boolean);
    procedure SetIgnore(const Value: Boolean);
    procedure SetDefaultValue(const Value: string);
    procedure SetSize(const Value: string);

    property Name        : string    read GetName         write SetName;
    property TType       : TTypeKind read GetTType        write SetTType;
    property Handle      : PTypeInfo read GetHandle       write SetHandle;
    property PK          : Boolean   read GetPK           write SetPK;
    property FK          : IFKData   read GetFK           write SetFK;
    property AutoInc     : Boolean   read GetAutoInc      write SetAutoInc;
    property NotNull     : Boolean   read GetNotNull      write SetNotNull;
    property Ignore      : Boolean   read GetIgnore       write SetIgnore;
    property DefaultValue: string    read GetDefaultValue write SetDefaultValue;
    property Size        : string    read GetSize         write SetSize;
  end;

implementation

end.
