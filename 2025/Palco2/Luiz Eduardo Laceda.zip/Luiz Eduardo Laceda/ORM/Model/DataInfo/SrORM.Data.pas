unit SrORM.Data;

interface

uses
  SrORM.Data.Interfaces, SrORM.Attributes, System.TypInfo;

type
  TTableData = class sealed(TInterfacedObject, ITableData)
  strict private
    FName: string;
    FDefaultFields: Boolean;

    function GetName: string;
    function GetDefaultNameFields: Boolean;

    procedure SetName(const Value: string);
    procedure SetDefaultNameFields(const Value: Boolean);
  public
    class function New: ITableData;

    property Name         : string      read GetName              write SetName;
    property DefaultNameFields: Boolean read GetDefaultNameFields write SetDefaultNameFields;
  end;

  TFKData = class sealed(TInterfacedObject, IFKData)
  strict private
    FTableName: string;
    FField: string;
    FDefaultValue: string;

    function GetTableName: string;
    function GetField: string;
    function GetDefaultValue: string;

    procedure SetTableName(const Value: string);
    procedure SetField(const Value: string);
    procedure SetDefaultValue(const Value: string);
  public
    class function New: IFKData;

    property TableName   : string read GetTableName    write SetTableName;
    property Field       : string read GetField        write SetField;
    property DefaultValue: string read GetDefaultValue write SetDefaultValue;
  end;

  TFieldData = class sealed(TInterfacedObject, IFieldData)
  strict private
    FName: string;
    FTType: TTypeKind;
    FHandle: PTypeInfo;
    FPK: Boolean;
    FFK: IFKData;
    FAutoInc: Boolean;
    FNotNull: Boolean;
    FIgnore: Boolean;
    FDefaultValue: string;
    FSize: string;

    function GetName: string;
    function GetTType: TTypeKind;
    function GetHandle: PTypeInfo;
    function GetPK: Boolean;
    function GetFK: IFKData;
    function GetAutoInc: Boolean;
    function GetNotNull: Boolean;
    function GetIgnore: Boolean;
    function GetDefaultValue: string;
    function GetSize: string;

    procedure SetName(const Value: string);
    procedure SetTType(const Value: TTypeKind);
    procedure SetHandle(const Value: PTypeInfo);
    procedure SetPK(const Value: Boolean);
    procedure SetFK(const Value: IFKData);
    procedure SetAutoInc(const Value: Boolean);
    procedure SetNotNull(const Value: Boolean);
    procedure SetIgnore(const Value: Boolean);
    procedure SetDefaultValue(const Value: string);
    procedure SetSize(const Value: string);
  public
    class function New: IFieldData;
    constructor Create;

    property Name        : string    read GetName         write SetName;
    property TType       : TTypeKind read GetTType        write SetTType;
    property Handle      : PTypeInfo read GetHandle       write SetHandle;
    property PK          : Boolean   read GetPK           write SetPK;
    property FK          : IFKData   read GetFK           write SetFK;
    property AutoInc     : Boolean   read GetAutoInc      write SetAutoInc;
    property NotNull     : Boolean   read GetNotNull      write SetNotNull;
    property Ignore      : Boolean   read GetIgnore       write SetIgnore;
    property DefaultValue: string    read GetDefaultValue write SetDefaultValue;
    property Size        : string    read GetSize         write SetSize;
  end;

implementation

{ TTableData }

class function TTableData.New: ITableData;
begin
  Result := Self.Create;
end;

function TTableData.GetName: string;
begin
  Result := FName;
end;

function TTableData.GetDefaultNameFields: Boolean;
begin
  Result := FDefaultFields;
end;

procedure TTableData.SetName(const Value: string);
begin
  FName := Value;
end;

procedure TTableData.SetDefaultNameFields(const Value: Boolean);
begin
  FDefaultFields := Value;
end;

{ TFKData }

class function TFKData.New: IFKData;
begin
  Result := Self.Create;
end;

function TFKData.GetTableName: string;
begin
  Result := FTableName;
end;

function TFKData.GetField: string;
begin
  Result := FField;
end;

function TFKData.GetDefaultValue: string;
begin
  Result := FDefaultValue;
end;

procedure TFKData.SetTableName(const Value: string);
begin
  FTableName := Value;
end;

procedure TFKData.SetField(const Value: string);
begin
  FField := Value;
end;

procedure TFKData.SetDefaultValue(const Value: string);
begin
  FDefaultValue := Value;
end;

{ TFieldData }

class function TFieldData.New: IFieldData;
begin
  Result := Self.Create;
end;

constructor TFieldData.Create;
begin
  FFK := TFKData.New;
end;

function TFieldData.GetName: string;
begin
  Result := FName;
end;

function TFieldData.GetTType: TTypeKind;
begin
  Result := FTType;
end;

function TFieldData.GetHandle: PTypeInfo;
begin
  Result := FHandle;
end;

function TFieldData.GetPK: Boolean;
begin
  Result := FPK;
end;

function TFieldData.GetFK: IFKData;
begin
  Result := FFK;
end;

function TFieldData.GetAutoInc: Boolean;
begin
  Result := FAutoInc;
end;

function TFieldData.GetNotNull: Boolean;
begin
  Result := FNotNull;
end;

function TFieldData.GetIgnore: Boolean;
begin
  Result := FIgnore;
end;

function TFieldData.GetDefaultValue: string;
begin
  Result := FDefaultValue;
end;

function TFieldData.GetSize: string;
begin
  Result := FSize;
end;

procedure TFieldData.SetName(const Value: string);
begin
  FName := Value;
end;

procedure TFieldData.SetTType(const Value: TTypeKind);
begin
  FTType := Value;
end;

procedure TFieldData.SetHandle(const Value: PTypeInfo);
begin
  FHandle := Value;
end;

procedure TFieldData.SetPK(const Value: Boolean);
begin
  FPK := Value;
end;

procedure TFieldData.SetFK(const Value: IFKData);
begin
  FFK := Value;
end;

procedure TFieldData.SetAutoInc(const Value: Boolean);
begin
  FAutoInc := Value;
end;

procedure TFieldData.SetNotNull(const Value: Boolean);
begin
  FNotNull := Value;
end;

procedure TFieldData.SetIgnore(const Value: Boolean);
begin
  FIgnore := Value;
end;

procedure TFieldData.SetDefaultValue(const Value: string);
begin
  FDefaultValue := Value;
end;

procedure TFieldData.SetSize(const Value: string);
begin
  FSize := Value;
end;

end.
