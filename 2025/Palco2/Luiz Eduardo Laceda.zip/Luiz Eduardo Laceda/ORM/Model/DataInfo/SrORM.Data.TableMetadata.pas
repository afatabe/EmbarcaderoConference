unit SrORM.Data.TableMetadata;

interface

uses
  System.Generics.Collections, FireDAC.Comp.Client;

type
  ITableMetadata = interface
    ['{583F115E-27E8-40AC-9371-358A5A24CC25}']
    function GetName: string;
    function GetTType: string;

    procedure SetName(const Value: string);
    procedure SetTType(const Value: string);

    property Name     : string read GetName    write SetName;
    property TType    : string read GetTType   write SetTType;

    function GetTableMetadata(const ATableName: string;
      AConnection: TFDConnection): TDictionary<string, ITableMetadata>;
    function TableExists(const ATableName: string;
      AConnection: TFDConnection): Boolean;
  end;

  TTableMetadata = class sealed(TInterfacedObject, ITableMetadata)
  private
    FName: string;
    FTType: string;
    FFieldName: string;
    FDriveName: string;

    function GetName: string;
    function GetTType: string;

    procedure SetName(const Value: string);
    procedure SetTType(const Value: string);
  public
    class function New: ITableMetadata;

    property Name     : string read GetName    write SetName;
    property TType    : string read GetTType   write SetTType;

    property FieldName: string read FFieldName write FFieldName;
    property DriveName: string read FDriveName write FDriveName;

    function GetMetadata(AFDMetaInfo: TFDMetaInfoQuery): TTableMetadata;

    function GetTableMetadata(const ATableName: string;
      AConnection: TFDConnection): TDictionary<string, ITableMetadata>;

    function TableExists(const ATableName: string;
      AConnection: TFDConnection): Boolean;
  end;

implementation

uses
  System.SysUtils, FireDAC.Phys.Intf, Data.DB;

{ TTableMetadata }

class function TTableMetadata.New: ITableMetadata;
begin
  Result := Self.Create;
end;

function TTableMetadata.GetName: string;
begin
  Result := FName;
end;

function TTableMetadata.GetTType: string;
begin
  Result := FTType;
end;

procedure TTableMetadata.SetName(const Value: string);
begin
  FName := Value;
end;

procedure TTableMetadata.SetTType(const Value: string);
begin
  FTType := Value;
end;

function TTableMetadata.GetTableMetadata(const ATableName: string;
  AConnection: TFDConnection): TDictionary<string, ITableMetadata>;
var FDMetaInfo: TFDMetaInfoQuery;
begin
  Result := nil;
  FDMetaInfo := TFDMetaInfoQuery.Create(nil);
  try
    FDMetaInfo.Connection   := AConnection;
    FDMetaInfo.MetaInfoKind := mkTableFields;
    FDMetaInfo.ObjectName   := ATableName;

    FDMetaInfo.Open;

    FDriveName := AConnection.DriverName;

    if not FDMetaInfo.IsEmpty then
    begin
      Result := TDictionary<string, ITableMetadata>.Create;

      FDMetaInfo.First;
      while not FDMetaInfo.Eof do
      begin
        var xMetaInfo := GetMetadata(FDMetaInfo);

        if not xMetaInfo.Name.Trim.IsEmpty then
        begin
          Result.AddOrSetValue(xMetaInfo.Name, xMetaInfo);
          Result.TrimExcess;
        end;

        FDMetaInfo.Next;
      end;
    end;
  finally
    FreeAndNil(FDMetaInfo);
  end;
end;

function TTableMetadata.GetMetadata(AFDMetaInfo: TFDMetaInfoQuery): TTableMetadata;
begin
  Result := TTableMetadata.Create;

  Result.Name  := UpperCase(AFDMetaInfo.FieldByName('COLUMN_NAME').AsString);
  Result.TType := UpperCase(AFDMetaInfo.FieldByName('COLUMN_TYPENAME').AsString);
end;

function TTableMetadata.TableExists(const ATableName: string; AConnection: TFDConnection): Boolean;
var FDMetaInfo: TFDMetaInfoQuery;
begin
  FDMetaInfo := TFDMetaInfoQuery.Create(nil);
  try
    FDMetaInfo.Connection   := AConnection;
    FDMetaInfo.MetaInfoKind := mkTables;
    FDMetaInfo.ObjectName   := ATableName;

    if UpperCase(AConnection.DriverName) = 'FB' then
      FDMetaInfo.ObjectName := UpperCase(ATableName);

    FDMetaInfo.Open;

    Result := not FDMetaInfo.IsEmpty;
  finally
    FreeAndNil(FDMetaInfo);
  end;
end;

end.
