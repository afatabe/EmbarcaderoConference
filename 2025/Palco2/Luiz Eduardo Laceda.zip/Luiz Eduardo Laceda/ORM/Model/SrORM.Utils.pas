unit SrORM.Utils;

interface

uses
  SrORM.Data.Interfaces, System.Generics.Collections, SrORM.Interfaces,
  System.TypInfo;

type
  TSrORMUtils<T: class> = class
  public
    class function GetFields(AFieldsData: TList<IFieldData>; AIncludePK: Boolean = False): string;
    class function GetFieldsUpdate(AObj: T; AFieldsData: TList<IFieldData>; ARTTI: IRTTI<T>): string;
    class function GetValues(AObj: T; AFieldsData: TList<IFieldData>; ARTTI: IRTTI<T>): string;
    class function GetIndexPkField(AFieldsData: TList<IFieldData>): Integer;
  end;

  THelperAttributes = record helper for TArray<TCustomAttribute>
  public
    function ContainsFieldName(const ASearch: string): Boolean;
  end;

implementation

uses System.SysUtils, System.StrUtils, SrORM.DB.Consts, SrORM.Attributes;

{ TSrORMUtils<T> }

class function TSrORMUtils<T>.GetFields(AFieldsData: TList<IFieldData>; AIncludePK: Boolean): string;
begin
  Result := EmptyStr;

  for var xField in AFieldsData do
  begin
    if (not xField.PK) or (AIncludePK) then
    begin
      Result := Result.Replace(cSeparator, ', ');
      Result := Result + xField.Name + cSeparator;
    end;
  end;

  Result := Result.Replace(cSeparator, EmptyStr);
end;

class function TSrORMUtils<T>.GetFieldsUpdate(AObj: T; AFieldsData: TList<IFieldData>;
  ARTTI: IRTTI<T>): string;
begin
  Result := EmptyStr;

  for var xField in AFieldsData do
  begin
    if not xField.PK then
    begin
      Result := Result.Replace(cSeparator, ', ');
      Result := Result + xField.Name + cEQUALS + ARTTI.GetPropValue(AObj, xField.Name) + cSeparator;
    end;
  end;

  Result := Result.Replace(cSeparator, EmptyStr);
end;

class function TSrORMUtils<T>.GetValues(AObj: T; AFieldsData: TList<IFieldData>;
  ARTTI: IRTTI<T>): string;
begin
  Result := EmptyStr;

  for var xField in AFieldsData do
  begin
    if not xField.PK then
    begin
      Result := Result.Replace(cSeparator, ', ');
      Result := Result + ARTTI.GetPropValue(AObj, xField.Name) + cSeparator;
    end;
  end;

  Result := Result.Replace(cSeparator, EmptyStr);
end;

class function TSrORMUtils<T>.GetIndexPkField(AFieldsData: TList<IFieldData>): Integer;
begin
  Result := -1;

  for var xField in AFieldsData do
  begin
    if xField.PK then
    begin
      Result := AFieldsData.IndexOf(xField);
      Exit;
    end;
  end;
end;

function THelperAttributes.ContainsFieldName(const ASearch: string): Boolean;
begin
  Result := False;

  for var xAtrribute in Self do
  begin
    if (xAtrribute is TField) and (TField(xAtrribute).Name = ASearch) then
    begin
      Result := TField(xAtrribute).Name = ASearch;
      Exit;
    end;
  end;
end;

end.
