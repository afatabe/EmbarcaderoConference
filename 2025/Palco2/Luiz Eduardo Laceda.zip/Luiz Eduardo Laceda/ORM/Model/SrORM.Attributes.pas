unit SrORM.Attributes;

interface

type
  TTable = class(TCustomAttribute)
  private
    FName: string;
    FDefaultNameFields: Boolean;
  public
    property Name: string read FName write FName;
    property DefaultNameFields: Boolean read FDefaultNameFields write FDefaultNameFields;

    constructor Create(AName: string; ADefaultNameFields: Boolean = False);
  end;

  TField = class(TCustomAttribute)
  private
    FName: string;
    FSize: string;
    FDefault: string;
  public
    property Name: string         read FName    write FName;
    property Size: string         read FSize    write FSize;
    property DefaultValue: string read FDefault write FDefault;

    constructor Create(AName: string; ASize: string = ''; ADefaultValue: string = '');
  end;

  PK = class(TCustomAttribute)
  end;

  FK = class(TCustomAttribute)
  private
    FTable: string;
    FField: string;
    FDefault: string;
  public
    property Table: string               read FTable   write FTable;
    property Field: string               read FField   write FField;
    property DefaultValue: string read FDefault write FDefault;

    constructor Create(ATable, AField: string; ADefaultValue: string = '');
  end;

  AutoInc = class(TCustomAttribute)
  end;

  NotNull = class(TCustomAttribute)
  end;

  Ignore = class(TCustomAttribute)
  end;

implementation

{ TTableName }

constructor TTable.Create(AName: string; ADefaultNameFields: Boolean);
begin
  FName             := AName;
  FDefaultNameFields:= ADefaultNameFields;
end;

{ TField }

constructor TField.Create(AName: string; ASize: string; ADefaultValue: string);
begin
  FName    := AName;
  FSize    := ASize;
  FDefault := ADefaultValue;
end;

{ FK }

constructor FK.Create(ATable, AField: string; ADefaultValue: string);
begin
  FTable   := ATable;
  FField   := AField;
  FDefault := ADefaultValue;
end;

end.
