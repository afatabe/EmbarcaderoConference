unit SrORM.RTTI;

interface
{$M+}
uses
  SrORM.Interfaces, SrORM.Data.Interfaces, System.Generics.Collections,
  System.Rtti, FireDAC.Comp.Client;

type
  TSrORMRTTI<T: class, constructor> = class(TInterfacedObject, IRTTI<T>)
  private
    procedure GetObjDataFromPropAttributes(var ATable: ITableData; AFields: TList<IFieldData>;
      AAtributes: TArray<TCustomAttribute>; AProp: TRttiProperty);
    procedure GetObjDataFromProperty(AFields: TList<IFieldData>; AProp: TRttiProperty);
    procedure GetQryDataFromPropAttributes(AQry: TFDQuery; AProp: TRttiProperty;
      AAtributes: TArray<TCustomAttribute>; var AName: string; out AItem: T; AValue: TValue);
    procedure GetQryDataFromProperty(AQry: TFDQuery; AProp: TRttiProperty;
      var AName: string; out AItem: T; AValue: TValue);
    function GetQryValue(ATypeKing: TTypeKind; AQry: TFDQuery; AName: string; APropType: TRttiType): TValue;
    procedure GetQryDataToList(AQry: TFDQuery; ATable: ITableData; out AList: TObjectList<T>);
    procedure GetQryDataToObj(AQry: TFDQuery; ATable: ITableData; out AObj: T);

    function GetClassProperties: TArray<TRttiProperty>;
    function GetClassType: TRttiType;
  public
    class function New: IRTTI<T>;

    function GetPropValue(AObj: T; const APropName: string): string;
    procedure GetObjData(var ATable: ITableData; AFields: TList<IFieldData>);
    procedure GetQryData(AQry: TFDQuery; ATable: ITableData; out AObj: T; out AList: TObjectList<T>);
    procedure SetPkValue(AObj: T; AValue: Integer);
  end;

implementation

uses
  SrORM.Attributes, SrORM.Data, System.SysUtils, System.StrUtils, System.TypInfo,
  SrORM.Utils;

{ TSrORMRTTI<T> }

class function TSrORMRTTI<T>.New: IRTTI<T>;
begin
  Result := Self.Create;
end;

function TSrORMRTTI<T>.GetClassProperties: TArray<TRttiProperty>;
begin
  var Context: TRttiContext;
  var ClassType := Context.GetType(TypeInfo(T));

  Result := ClassType.GetProperties;
end;

function TSrORMRTTI<T>.GetClassType: TRttiType;
begin
  var Context: TRttiContext;
  Result := Context.GetType(TypeInfo(T));
end;

procedure TSrORMRTTI<T>.GetObjData(var ATable: ITableData; AFields: TList<IFieldData>);
var Prop: TRttiProperty;
begin
  var ClassType := GetClassType;

  for var Attribute in ClassType.GetAttributes do
  begin
    if Attribute is TTable then
    begin
      ATable.Name             := TTable(Attribute).Name;
      ATable.DefaultNameFields:= TTable(Attribute).DefaultNameFields;
    end
  end;

  for Prop in ClassType.GetProperties do
  begin
    if not Assigned(Prop) then
      Continue;

    var Attributes := Prop.GetAttributes;

    if Length(Attributes) > 0 then
      GetObjDataFromPropAttributes(ATable, AFields, Attributes, Prop)
    else
    if ATable.DefaultNameFields then
      GetObjDataFromProperty(AFields, Prop);
  end;
end;

procedure TSrORMRTTI<T>.GetObjDataFromPropAttributes(var ATable: ITableData; AFields: TList<IFieldData>;
  AAtributes: TArray<TCustomAttribute>; AProp: TRttiProperty);
var Field     : IFieldData;
    IsIgnore  : Boolean;
    Attribute: TCustomAttribute;
begin
  IsIgnore := False;
  Field  := TFieldData.New;
  for Attribute in AAtributes do
  begin
    If Attribute is Ignore then
    begin
      IsIgnore := True;
      Break;
    end;

    if ATable.DefaultNameFields and Field.Name.IsEmpty then
      Field.Name := AProp.Name;

    if Attribute is TField then
    begin
      Field.Name         := TField(Attribute).Name;
      Field.Size         := TField(Attribute).Size;
      Field.DefaultValue := TField(Attribute).DefaultValue;
    end;

    Field.TType  := AProp.PropertyType.TypeKind;
    Field.Handle := AProp.PropertyType.Handle;

    if Attribute is PK then
      Field.PK := Attribute is PK;

    if Attribute is FK then
    begin
      Field.FK.TableName := FK(Attribute).Table;
      Field.FK.Field     := FK(Attribute).Field;
      Field.DefaultValue := FK(Attribute).DefaultValue;
    end;

    if Attribute is AutoInc then
      Field.AutoInc := Attribute is AutoInc;

    if Attribute is NotNull then
      Field.NotNull := Attribute is NotNull;
  end;
  if not IsIgnore then
    AFields.Add(Field);
end;

procedure TSrORMRTTI<T>.GetObjDataFromProperty(AFields: TList<IFieldData>; AProp: TRttiProperty);
var Field: IFieldData;
begin
  Field := TFieldData.New;

  Field.Name   := AProp.Name;
  Field.TType  := AProp.PropertyType.TypeKind;
  Field.Handle := AProp.PropertyType.Handle;

  AFields.Add(Field);
end;

procedure TSrORMRTTI<T>.GetQryData(AQry: TFDQuery; ATable: ITableData; out AObj: T;
  out AList: TObjectList<T>);
begin
  if Assigned(AList) then
    GetQryDataToList(AQry, ATable, AList)
  else
    GetQryDataToObj(AQry, ATable, AObj);
end;

procedure TSrORMRTTI<T>.GetQryDataToList(AQry: TFDQuery; ATable: ITableData; out AList: TObjectList<T>);
var Item : T;
    Value: TValue;
    Prop: TRttiProperty;
    Name: string;
begin
  AQry.First;
  while not AQry.Eof do
  begin
    Item := T.Create;

    for Prop in GetClassProperties do
    begin
      Name := EmptyStr;

      if not Assigned(Prop) then
        Continue;

      var Attributes := Prop.GetAttributes;

      if Length(Attributes) > 0 then
        GetQryDataFromPropAttributes(AQry, Prop, Attributes, Name, Item, Value)
      else
      if ATable.DefaultNameFields then
        GetQryDataFromProperty(AQry, Prop, Name, Item, Value);
    end;
    AList.Add(Item);
    AQry.Next;
  end;
end;

procedure TSrORMRTTI<T>.GetQryDataToObj(AQry: TFDQuery; ATable: ITableData; out AObj: T);
var Value: TValue;
    Prop: TRttiProperty;
    Name: string;
begin
  AObj := T.Create;

  AQry.First;
  while not AQry.Eof do
  begin
    for Prop in GetClassProperties do
    begin
      Name := EmptyStr;

      if not Assigned(Prop) then
        Continue;

      var Attributes := Prop.GetAttributes;

      if Length(Attributes) > 0 then
        GetQryDataFromPropAttributes(AQry, Prop, Attributes, Name, AObj, Value)
      else
      if ATable.DefaultNameFields then
        GetQryDataFromProperty(AQry, Prop, Name, AObj, Value);
    end;

    AQry.Next;
  end;
end;

procedure TSrORMRTTI<T>.GetQryDataFromPropAttributes(AQry: TFDQuery; AProp: TRttiProperty;
  AAtributes: TArray<TCustomAttribute>; var AName: string; out AItem: T;
  AValue: TValue);
begin
  if AName.Trim.IsEmpty then
  begin
    for var Attribute in AAtributes do
    begin
      AName := AProp.Name;

      if Attribute is TField then
        AName := TField(Attribute).Name;

      if not Assigned(AQry.FindField(AName)) then
        Continue;

      if Assigned(AQry.FindField(AName)) then
        Break;
    end;
  end;

  AValue := GetQryValue(AProp.PropertyType.TypeKind,
                        AQry,
                        AName,
                        AProp.PropertyType);
  AProp.SetValue(TObject(AItem), AValue);
end;

procedure TSrORMRTTI<T>.GetQryDataFromProperty(AQry: TFDQuery; AProp: TRttiProperty;
  var AName: string; out AItem: T; AValue: TValue);
begin
  AName := AProp.Name;

  AValue := GetQryValue(AProp.PropertyType.TypeKind,
                        AQry,
                        AName,
                        AProp.PropertyType);
  AProp.SetValue(TObject(AItem), AValue);
end;

function TSrORMRTTI<T>.GetQryValue(ATypeKing: TTypeKind; AQry: TFDQuery; AName: string;
  APropType: TRttiType): TValue;
var Aux: Variant;
begin
  case ATypeKing of
    tkFloat:
    begin
      if APropType.Handle = TypeInfo(TDateTime) then
      begin
        Aux:= AQry.FieldByName(AName).AsString;
        Result  := TValue.From<TDateTime>(StrToDateTime(Aux));
      end
      else
      begin
        Aux:= AQry.FieldByName(AName).AsFloat;
        Result  := TValue.From<Currency>(Aux);
      end;
    end;
    tkInteger, tkEnumeration:
    begin
      if APropType.Handle = TypeInfo(Boolean) then
      begin
        Aux:= AQry.FieldByName(AName).AsVariant;
        Result  := TValue.From<Variant>(Aux);
      end
      else
      begin
        Aux:= AQry.FieldByName(AName).AsInteger;
        Result  := TValue.From<Integer>(Aux);
      end;
    end;
    tkString, tkChar, tkWChar, tkLString, tkWString, tkUString:
    begin
      Aux:= AQry.FieldByName(AName).AsString;
      Result  := TValue.From<string>(Aux);
    end;
  end;
end;

function TSrORMRTTI<T>.GetPropValue(AObj: T; const APropName: string): string;
begin
  for var Prop in GetClassProperties do
  begin
    if Assigned(Prop) then
    begin
      if (Prop.Name = APropName) or
         ((Prop.Name <> APropName) and
         (Prop.GetAttributes.ContainsFieldName(APropName)))
      then
      begin
        case Prop.PropertyType.TypeKind of
          tkInteger, tkEnumeration:
            Result := Prop.GetValue(TObject(AObj)).ToString;
          tkFloat:
          begin
            if Prop.PropertyType.Handle = TypeInfo(TDateTime) then
              Result := QuotedStr(Prop.GetValue(TObject(AObj)).ToString)
            else
              Result := Prop.GetValue(TObject(AObj)).ToString.Replace(',', '.');
          end;
          tkString, tkChar, tkWChar,
          tkLString, tkWString,
          tkUString:
            Result := QuotedStr(Prop.GetValue(TObject(AObj)).ToString);
        end;

        Exit;
      end;
    end;
  end;
end;

procedure TSrORMRTTI<T>.SetPkValue(AObj: T; AValue: Integer);
var Value: TValue;
    Prop: TRttiProperty;
    Attributes: TArray<TCustomAttribute>;
    Attribute: TCustomAttribute;
begin
  Value := TValue.From<Integer>(AValue);

  for Prop in GetClassProperties do
  begin
    if not Assigned(Prop) then
      Continue;

    Attributes := Prop.GetAttributes;

    if Length(Attributes) > 0 then
    begin
      for Attribute in Attributes do
      begin
        if Attribute is PK then
        begin
          Prop.SetValue(TObject(AObj), AValue);
          Exit;
        end;
      end;
    end;
  end;
end;

end.
