unit SrORM.Interfaces;

interface

uses
  FireDAC.Comp.Client, System.Generics.Collections, SrORM.Data.Interfaces;

type
  EQueryComand = (qcSELECT, qcINSERT, qcUPDATE, qcDELETE, qcDELETE_CUSTOM, qcCREATETABLE,
    qcADDNEWFIELDS, qcDROPTABLE);

  const
    ECustomComands = [qcDELETE_CUSTOM];
    ESelectComands = [qcSELECT];

type
  IDDL<T: class> = interface
    ['{D40E708D-ACAC-467E-93D0-484B8FA7B5C3}']
    function CreateTable: IDDL<T>;
    function AddNewFields: IDDL<T>;
    function Drop: IDDL<T>;
  end;

  IDML<T: class> = interface;

  IQueryBuilder<T: class> = interface
    ['{78831B9F-A52E-4894-9AEF-E1AEB87818C2}']
    function GetFieldsData: TList<IFieldData>;
    function GetTableData: ITableData;

    function Fields(const AFields: string = ''): IQueryBuilder<T>;
    function Join(const AJoin: string): IQueryBuilder<T>;
    function Where(const AWhere: string): IQueryBuilder<T>;
    function OrderBy(const AOrderBy: string): IQueryBuilder<T>;

    procedure Execute(out AList: TObjectList<T>); overload;
    procedure Execute(out AObj: T); overload;
    procedure Execute(AIndex: Integer = -1); overload;

    property TableData : ITableData        read GetTableData;
    property FieldsData: TList<IFieldData> read GetFieldsData;
  end;

  IQueryExecutor<T: class>  = interface
    ['{90B058D3-208B-436B-9D2B-4330FC94136E}']
    procedure DoComand(AIndex: Integer = -1); overload;
    procedure DoComand(out AObj: T; out AList: TObjectList<T>; AIndex: Integer = -1); overload;
  end;

  IDML<T: class> = interface
    ['{C1ACF6A1-5094-4E62-8C38-86C3BC172618}']
    function Select: IQueryBuilder<T>;
    function Delete: IQueryBuilder<T>; overload;

    function Insert(AObj: T): IDML<T>;
    function Update(AObj: T): IDML<T>;
    function Delete(AObj: T): IDML<T>; overload;
  end;

  IControllerSrORM<T: class> = interface
    ['{42C4E98A-29D8-4B65-B2D8-52FAB7E2BB10}']
    function DDL: IDDL<T>;
    function DML: IDML<T>;
  end;

  IDAO<T: class> = interface
    ['{11E4C87F-BE23-42C1-9C2E-5AA1258E2573}']
    procedure ExecuteComand(const ASQL: string; const AComand: EQueryComand; const ATableData: ITableData;
      const AFieldsData: TList<IFieldData>; out AObj: T; out AList: TObjectList<T>);
  end;

  IRTTI<T: class> = interface
    ['{F8114E60-53C8-4DF9-8E51-19C929A72082}']
    function GetPropValue(AObj: T; const APropName: string): string;

    procedure GetObjData(var ATable: ITableData; AFields: TList<IFieldData>);
    procedure GetQryData(AQry: TFDQuery; ATable: ITableData; out AObj: T; out AList: TObjectList<T>);
    procedure SetPkValue(AObj: T; AValue: Integer);
  end;

implementation

end.
