unit SrORM.DDL.Table;

interface

uses
  SrORM.Interfaces, FireDAC.Comp.Client;

type
  TSQLTable<T: class, constructor> = class(TInterfacedObject, ITable<T>)
  private
    FDAO: IDAO<T>;
  public
    class function New(const AConnection: TFDConnection): ITable<T>;
    constructor Create(const AConnection: TFDConnection);

    function CreateTable: ITable<T>;
    function AddNewFields: ITable<T>;
    function Drop: ITable<T>;
  end;

implementation

uses
  DAO.SrORM;

{ TQueryTable<T> }

class function TSQLTable<T>.New(const AConnection: TFDConnection): ITable<T>;
begin
  Result := Self.Create(AConnection);
end;

constructor TSQLTable<T>.Create(const AConnection: TFDConnection);
begin
  FDAO := TDAOSrORM<T>.New(AConnection);
end;

function TSQLTable<T>.CreateTable: ITable<T>;
begin
  FDAO.CreateTable;

  Result := Self;
end;

function TSQLTable<T>.AddNewFields: ITable<T>;
begin
  FDAO.AddNewFields;

  Result := Self;
end;

function TSQLTable<T>.Drop: ITable<T>;
begin
  FDAO.Drop;

  Result := Self;
end;

end.
