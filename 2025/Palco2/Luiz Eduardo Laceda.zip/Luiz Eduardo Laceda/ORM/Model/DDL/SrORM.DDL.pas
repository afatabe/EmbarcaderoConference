unit SrORM.DDL;

interface

uses
  FireDAC.Comp.Client, SrORM.Interfaces;

type
  TDDLSrORM<T: class, constructor> = class(TInterfacedObject, IDDL<T>)
  private
    FConnection: TFDConnection;
  public
    class function New(const AConnection: TFDConnection): IDDL<T>;
    constructor Create(const AConnection: TFDConnection);

    function CreateTable: IDDL<T>;
    function AddNewFields: IDDL<T>;
    function Drop: IDDL<T>;
  end;

implementation

uses
  DAO.SrORM, SrORM.QueryBuilder, System.Generics.Collections, SrORM.Data.TableMetadata,
  SrORM.Data.Interfaces, System.SysUtils, StrUtils;

{ TDDLSrORM<T> }

class function TDDLSrORM<T>.New(const AConnection: TFDConnection): IDDL<T>;
begin
  Result := Self.Create(AConnection);
end;

constructor TDDLSrORM<T>.Create(const AConnection: TFDConnection);
begin
  FConnection := AConnection;
end;

function TDDLSrORM<T>.CreateTable: IDDL<T>;
begin
  if not TDAOSrORM<T>.TableExists(FConnection) then
     TQueryBuilder<T>.New(qcCREATETABLE, FConnection).Execute;

  Result := Self;
end;

function TDDLSrORM<T>.AddNewFields: IDDL<T>;
var Metadata: TDictionary<string, ITableMetadata>;
    QueryBuilder: IQueryBuilder<T>;
begin
  if TDAOSrORM<T>.TableExists(FConnection) then
  begin
    QueryBuilder := TQueryBuilder<T>.New(qcADDNEWFIELDS, FConnection);
    Metadata := TDAOSrORM<T>.TableMatadata(FConnection);

    for var xItem in QueryBuilder.FieldsData do
    begin
      if not Metadata.ContainsKey(xItem.Name.ToUpper) then
        TQueryBuilder<T>.New(qcADDNEWFIELDS, FConnection).Execute(QueryBuilder.FieldsData.IndexOf(xItem));
    end;
  end;

  Result := Self;
end;

function TDDLSrORM<T>.Drop: IDDL<T>;
begin
  if TDAOSrORM<T>.TableExists(FConnection) then
    TQueryBuilder<T>.New(qcDROPTABLE, FConnection).Execute;

  Result := Self;
end;

end.
