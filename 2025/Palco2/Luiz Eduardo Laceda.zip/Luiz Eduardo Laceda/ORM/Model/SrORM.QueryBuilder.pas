unit SrORM.QueryBuilder;

interface

uses
  SrORM.Interfaces, Generics.Collections, FireDAC.Comp.Client,
  SrORM.Data.Interfaces;

type
  TQueryBuilder<T: class, constructor> = class(TInterfacedObject, IQueryBuilder<T>, IQueryExecutor<T>)
  private
    FConnection: TFDConnection;
    FComand: EQueryComand;
    FTableData: ITableData;
    FFieldsData: TList<IFieldData>;
    FRTTI: IRTTI<T>;

    FFields,
    FJoins,
    FWhere,
    FOrderBy,
    FSQL: string;

    function GetFieldsData: TList<IFieldData>;
    function GetTableData: ITableData;

    function SQLSelect: string;
    function SQLDelete: string;

    procedure BuildQuery(AObj: T; Index: Integer = -1);
  public
    class function New(AComand: EQueryComand; AConnection: TFDConnection): IQueryBuilder<T>;
    constructor Create(AComand: EQueryComand; AConnection: TFDConnection);
    destructor Destroy; override;

    function Fields(const AFields: string = ''): IQueryBuilder<T>;
    function Join(const AJoin: string): IQueryBuilder<T>;
    function Where(const AWhere: string): IQueryBuilder<T>;
    function OrderBy(const AOrderBy: string): IQueryBuilder<T>;

    procedure Execute(out AList: TObjectList<T>); overload;
    procedure Execute(out AObj: T); overload;
    procedure Execute(AIndex: Integer = -1); overload;

    procedure DoComand(AIndex: Integer = -1); overload;
    procedure DoComand(out AObj: T; out AList: TObjectList<T>; AIndex: Integer = -1); overload;

    property TableData : ITableData        read GetTableData;
    property FieldsData: TList<IFieldData> read GetFieldsData;
  end;

implementation

uses
  System.SysUtils, StrUtils, SrORM.DB.Consts, DAO.SrORM, SrORM.Data,
  Controller.SrORM.DB, SrORM.DB.Interfaces, SrORM.RTTI, SrORM.Utils;

{ TDMLQueryBuilder<T> }

class function TQueryBuilder<T>.New(AComand: EQueryComand; AConnection: TFDConnection): IQueryBuilder<T>;
begin
  Result := Self.Create(AComand, AConnection);
end;

constructor TQueryBuilder<T>.Create(AComand: EQueryComand; AConnection: TFDConnection);
begin
  FConnection := AConnection;
  FComand     := AComand;
  FTableData  := TTableData.New;
  FFieldsData := TList<IFieldData>.Create;
  FRTTI       := TSrORMRTTI<T>.New;

  FRTTI.GetObjData(FTableData, FFieldsData);
end;

destructor TQueryBuilder<T>.Destroy;
begin
  if Assigned(FFieldsData) then
    FreeAndNil(FFieldsData);
  inherited;
end;

function TQueryBuilder<T>.GetTableData: ITableData;
begin
  Result := FTableData;
end;

function TQueryBuilder<T>.GetFieldsData: TList<IFieldData>;
begin
  Result := FFieldsData;
end;

function TQueryBuilder<T>.Fields(const AFields: string): IQueryBuilder<T>;
begin
  FFields := AFields;

  if FFields.Trim.IsEmpty then
  begin
    FFields := TSrORMUtils<T>.GetFields(FFieldsData, True);
  end;

  Result := Self;
end;

function TQueryBuilder<T>.Join(const AJoin: string): IQueryBuilder<T>;
begin
  FJoins := AJoin;

  Result := Self;
end;

function TQueryBuilder<T>.Where(const AWhere: string): IQueryBuilder<T>;
begin
  FWhere := AWhere;

  Result := Self;
end;

function TQueryBuilder<T>.OrderBy(const AOrderBy: string): IQueryBuilder<T>;
begin
  FOrderBy := AOrderBy;

  Result := Self;
end;

function TQueryBuilder<T>.SQLSelect: string;
begin
  Result := Format(cSELECT, [IfThen(FFields.IsEmpty, TSrORMUtils<T>.GetFields(FFieldsData, True), FFields),
                             FTableData.Name,
                             IfThen(FJoins.IsEmpty, EmptyStr, FJoins),
                             IfThen(FWhere.IsEmpty, EmptyStr, cWHERE + FWhere),
                             IfThen(FOrderBy.IsEmpty, EmptyStr, cOrderBy + FOrderBy)]);
end;

function TQueryBuilder<T>.SQLDelete: string;
begin
  Result := Format(cDELETE, [FTableData.Name,
                             IfThen(FWhere.IsEmpty, EmptyStr, cWHERE + FWhere)]);
end;

procedure TQueryBuilder<T>.BuildQuery(AObj: T; Index: Integer);
var ControllerSrORMDB: IControllerSrORMDB<T>;
begin
  ControllerSrORMDB := TControllerSrORMDB<T>.New(FConnection.DriverName);

  case FComand of
    qcCREATETABLE  : FSQL := ControllerSrORMDB.SQLCreateTable(FTableData, FFieldsData);
    qcADDNEWFIELDS : FSQL := ControllerSrORMDB.SQLAlterTableAddColumn(FTableData, FFieldsData[Index]);
    qcDROPTABLE    : FSQL := ControllerSrORMDB.SQLDropTable(FTableData);
    qcSELECT       : FSQL := SQLSelect;
    qcINSERT       : FSQL := ControllerSrORMDB.SQLInsert(AObj, FTableData, FFieldsData);
    qcUPDATE       : FSQL := ControllerSrORMDB.SQLUpdate(AObj, FTableData, FFieldsData);
    qcDELETE_CUSTOM: FSQL := SQLDelete;
    qcDELETE       : FSQL := ControllerSrORMDB.SQLDelete(AObj, FTableData, FFieldsData);
  else
    raise Exception.Create('Tipo de comando n�o definido, por favor verifique!');
  end;
end;

procedure TQueryBuilder<T>.Execute(out AObj: T);
var List: TObjectList<T>;
begin
  List := nil;
  DoComand(AObj, List);
end;

procedure TQueryBuilder<T>.Execute(out AList: TObjectList<T>);
var Obj: T;
begin
  Obj := nil;
  DoComand(Obj, AList);
end;

procedure TQueryBuilder<T>.Execute(AIndex: Integer);
begin
  DoComand(AIndex);
end;

procedure TQueryBuilder<T>.DoComand(AIndex: Integer);
var List: TObjectList<T>;
    Obj: T;
begin
  List := nil;
  Obj  := nil;
  DoComand(Obj, List, AIndex);
end;

procedure TQueryBuilder<T>.DoComand(out AObj: T; out AList: TObjectList<T>; AIndex: Integer);
begin
  if FComand in [qcINSERT, qcUPDATE, qcDELETE] then
    BuildQuery(AObj, AIndex)
  else
    BuildQuery(nil, AIndex);

  if FSQL.Trim.IsEmpty then
    raise Exception.Create('Nenhuma query identificada, por favor verifique!');

  TDAOSrORM<T>.New(FConnection).ExecuteComand(FSQL, FComand, FTableData, FFieldsData, AObj, AList);
end;

end.
