unit SrORM.DML;

interface

uses
  FireDAC.Comp.Client, SrORM.Interfaces, Generics.Collections;

type
  TDMLSrORM<T: class, constructor> = class(TInterfacedObject, IDML<T>)
  private
    FConnection: TFDConnection;
  public
    class function New(const AConnection: TFDConnection): IDML<T>;
    constructor Create(const AConnection: TFDConnection);

    function Select: IQueryBuilder<T>;
    function Delete: IQueryBuilder<T>; overload;

    function Insert(AObj: T): IDML<T>;
    function Update(AObj: T): IDML<T>;
    function Delete(AObj: T): IDML<T>; overload;
  end;

implementation

uses DAO.SrORM, System.SysUtils, SrORM.DB.Consts, StrUtils,
  SrORM.QueryBuilder;

{ TDMLSrORM<T> }

class function TDMLSrORM<T>.New(const AConnection: TFDConnection): IDML<T>;
begin
  Result := Self.Create(AConnection);
end;

constructor TDMLSrORM<T>.Create(const AConnection: TFDConnection);
begin
  FConnection := AConnection;
end;

function TDMLSrORM<T>.Select: IQueryBuilder<T>;
begin
  Result := TQueryBuilder<T>.New(qcSELECT, FConnection);
end;

function TDMLSrORM<T>.Delete: IQueryBuilder<T>;
begin
  Result := TQueryBuilder<T>.New(qcDELETE_CUSTOM, FConnection);
end;

function TDMLSrORM<T>.Insert(AObj: T): IDML<T>;
begin
  TQueryBuilder<T>.New(qcINSERT, FConnection).Execute(AObj);

  Result := Self;
end;

function TDMLSrORM<T>.Update(AObj: T): IDML<T>;
begin
  TQueryBuilder<T>.New(qcUPDATE, FConnection).Execute(AObj);

  Result := Self;
end;

function TDMLSrORM<T>.Delete(AObj: T): IDML<T>;
begin
  TQueryBuilder<T>.New(qcDELETE, FConnection).Execute(AObj);

  Result := Self;
end;

end.
