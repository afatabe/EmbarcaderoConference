unit SrORM.DB.Interfaces;

interface

uses
  SrORM.Data.Interfaces, System.Generics.Collections, SrORM.Interfaces,
  System.TypInfo;

type
  ISrORMDB<T: class> = interface
    ['{A0B68035-2FCD-4763-9659-3B0EF448AACA}']

    function ReturnFieldDBType(ATypeKind: TTypeKind; AHandle: PTypeInfo; AFieldData: IFieldData): string;

    function SQLCreateTable(ATableData: ITableData; AFieldsData: TList<IFieldData>): string;
    function SQLAlterTableAddColumn(ATableData: ITableData; AFieldData: IFieldData): string;
    function SQLDropTable(ATableData: ITableData): string;
    function SQLInsert(AObj: T; ATableData: ITableData; AFieldsData: TList<IFieldData>): string;
    function SQLUpdate(AObj: T; ATableData: ITableData; AFieldsData: TList<IFieldData>): string;
    function SQLDelete(AObj: T; ATableData: ITableData; AFieldsData: TList<IFieldData>): string;
  end;

  IFactorySrORMDB<T: class> = interface
    ['{A1401D2A-DA2B-42D0-B805-08E5A9BA7AED}']
    function GetInstance(const ADriveName: string): ISrORMDB<T>;
  end;

  IControllerSrORMDB<T: class> = interface
    ['{8C932F6B-BE5B-4D6B-981E-EB808A67D0A0}']

    function SQLCreateTable(ATableData: ITableData; AFieldsData: TList<IFieldData>): string;
    function SQLAlterTableAddColumn(ATableData: ITableData; AFieldData: IFieldData): string;
    function SQLDropTable(ATableData: ITableData): string;
    function SQLInsert(AObj: T; ATableData: ITableData; AFieldsData: TList<IFieldData>): string;
    function SQLUpdate(AObj: T; ATableData: ITableData; AFieldsData: TList<IFieldData>): string;
    function SQLDelete(AObj: T; ATableData: ITableData; AFieldsData: TList<IFieldData>): string;
  end;

implementation

end.
