unit SrORM.DB.SQLite;

interface

uses
  SrORM.Data.Interfaces, System.Generics.Collections, SrORM.DB.Interfaces,
  SrORM.Interfaces, System.TypInfo;

type
  TSrORMSQlite<T: class, constructor> = class sealed(TInterfacedObject, ISrORMDB<T>)
  private
    FRTTI: IRTTI<T>;

    function GetPropertiesField(AFieldData: IFieldData): string;
    function GetFksFields(ATableData: ITableData; AFieldsData: TList<IFieldData>): string;
  public
    class function New: ISrORMDB<T>;
    constructor Create;

    function ReturnFieldDBType(ATypeKind: TTypeKind; AHandle: PTypeInfo; AFieldData: IFieldData): string;

    function SQLCreateTable(ATableData: ITableData; AFieldsData: TList<IFieldData>): string;
    function SQLAlterTableAddColumn(ATableData: ITableData; AFieldData: IFieldData): string;
    function SQLDropTable(ATableData: ITableData): string;
    function SQLInsert(AObj: T; ATableData: ITableData; AFieldsData: TList<IFieldData>): string;
    function SQLUpdate(AObj: T; ATableData: ITableData; AFieldsData: TList<IFieldData>): string;
    function SQLDelete(AObj: T; ATableData: ITableData; AFieldsData: TList<IFieldData>): string;
  end;

implementation

uses
  System.SysUtils, SrORM.DB.Consts, System.StrUtils, SrORM.RTTI, SrORM.Utils;

{ TSrORMSQlite }

class function TSrORMSQlite<T>.New: ISrORMDB<T>;
begin
  Result := Self.Create;
end;

constructor TSrORMSQlite<T>.Create;
begin
  FRTTI := TSrORMRTTI<T>.New;
end;


function TSrORMSQlite<T>.GetFksFields(ATableData: ITableData;
  AFieldsData: TList<IFieldData>): string;
begin
  Result := EmptyStr;

  for var I := 0 to Pred(AFieldsData.Count) do
  begin
    if not AFieldsData[I].FK.TableName.IsEmpty then
    begin
      Result  := Result.Replace(cSeparator, ', ');
      var xFk := Format(cFK_SQLITE, [AFieldsData[I].Name, AFieldsData[I].FK.TableName, AFieldsData[I].FK.Field]);
      Result  := Result + xFk + cSeparator;
    end;
  end;
end;

function TSrORMSQlite<T>.GetPropertiesField(AFieldData: IFieldData): string;
begin
  Result := EmptyStr;

  if AFieldData.PK then
    Result := cPK;

  if AFieldData.AutoInc then
    Result := Result + cAutoInc_SQLITE;

  if AFieldData.NotNull then
    Result := Result + cNotNull;
end;

function TSrORMSQlite<T>.ReturnFieldDBType(ATypeKind: TTypeKind; AHandle: PTypeInfo; AFieldData: IFieldData): string;
begin
  Result := EmptyStr;

  case ATypeKind of
    tkInteger,
    tkEnumeration, tkInt64: Result := ' INTEGER ';
    tkFloat               : Result := ' REAL ';
    tkString, tkLString,
    tkWString, tkUString,
    tkChar, tkWChar       : Result := ' TEXT ';
  end;
end;

function TSrORMSQlite<T>.SQLCreateTable(ATableData: ITableData;
  AFieldsData: TList<IFieldData>): string;
var SQL, SQLFields, PropField: string;
begin
  for var xField in AFieldsData do
  begin
    SQLFields := SQLFields.Replace(cSeparator, ', ');

    SQLFields := SQLFields + xField.Name + ' ' + ReturnFieldDBType(xField.TType, xField.Handle, xField);
    PropField := GetPropertiesField(xField);
    SQLFields := Concat(SQLFields, PropField);

    SQLFields := Concat(SQLFields, cSeparator);
  end;

  SQLFields := SQLFields.Replace(cSeparator, EmptyStr);
  SQLFields := Concat(SQLFields, cSeparator);
  SQLFields := Concat(SQLFields, GetFksFields(ATableData, AFieldsData));
  SQLFields := SQLFields.Replace(cSeparator, EmptyStr);

  SQL       := Concat(SQL, SQLFields);

  Result := Format(cCREATETABLE, [ATableData.Name, SQL]);
end;

function TSrORMSQlite<T>.SQLAlterTableAddColumn(ATableData: ITableData;
  AFieldData: IFieldData): string;
begin
  Result := Format(cADDCOLUMN_SQLITE, [ATableData.Name, AFieldData.Name,
    ReturnFieldDBType(AFieldData.TType, AFieldData.Handle, AFieldData)]);
end;

function TSrORMSQlite<T>.SQLDropTable(ATableData: ITableData): string;
begin
  Result := Format(cDROPTABLE_SQLITE, [ATableData.Name]);
end;

function TSrORMSQlite<T>.SQLInsert(AObj: T; ATableData: ITableData; AFieldsData: TList<IFieldData>): string;
var Fields, Values: string;
begin
  Fields := TSrORMUtils<T>.GetFields(AFieldsData);
  Values := TSrORMUtils<T>.GetValues(AObj, AFieldsData, FRTTI);

  Result := Format(cINSERT, [ATableData.Name, Fields, Values]) ;
end;

function TSrORMSQlite<T>.SQLUpdate(AObj: T; ATableData: ITableData; AFieldsData: TList<IFieldData>): string;
var FieldsUpdate, xWhere: string;
    IndexPk: Integer;
begin
  FieldsUpdate := TSrORMUtils<T>.GetFieldsUpdate(AObj, AFieldsData, FRTTI);
  IndexPk      := TSrORMUtils<T>.GetIndexPkField(AFieldsData);

  if IndexPk < 0 then
    raise Exception.Create('N�o foi encontrada a PK da tabela ' + ATableData.Name);

  xWhere := AFieldsData[IndexPk].Name + cEQUALS + FRTTI.GetPropValue(AObj, AFieldsData[IndexPk].Name);

  Result := Format(cUPDATEByPK, [ATableData.Name, FieldsUpdate, xWhere]);
end;

function TSrORMSQlite<T>.SQLDelete(AObj: T; ATableData: ITableData; AFieldsData: TList<IFieldData>): string;
var Where: string;
    IndexPk: Integer;
begin
  IndexPk := TSrORMUtils<T>.GetIndexPkField(AFieldsData);

  if IndexPk < 0 then
    raise Exception.Create('N�o foi encontrada a PK da tabela ' + ATableData.Name);

  Where := AFieldsData[IndexPk].Name + cEQUALS + FRTTI.GetPropValue(AObj, AFieldsData[IndexPk].Name);
  Result := Format(cDELETE, [ATableData.Name, Where]);
end;

end.
