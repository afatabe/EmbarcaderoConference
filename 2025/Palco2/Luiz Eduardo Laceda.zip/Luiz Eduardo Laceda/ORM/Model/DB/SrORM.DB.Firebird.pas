unit SrORM.DB.Firebird;

interface

uses
  SrORM.Data.Interfaces, System.Generics.Collections, SrORM.DB.Interfaces,
  SrORM.Interfaces, System.TypInfo;

type
  TSrORMFirebird<T: class, constructor> = class sealed(TInterfacedObject, ISrORMDB<T>)
  private
    FRTTI: IRTTI<T>;

    function GetPropertiesField(AFieldData: IFieldData): string;
    function GetFksFields(ATableData: ITableData; AFieldsData: TList<IFieldData>): string;
  public
    class function New: ISrORMDB<T>;
    constructor Create;

    function ReturnFieldDBType(ATypeKind: TTypeKind; AHandle: PTypeInfo; AFieldData: IFieldData): string;

    function SQLCreateTable(ATableData: ITableData; AFieldsData: TList<IFieldData>): string;
    function SQLAlterTableAddColumn(ATableData: ITableData; AFieldData: IFieldData): string;
    function SQLDropTable(ATableData: ITableData): string;
    function SQLInsert(AObj: T; ATableData: ITableData; AFieldsData: TList<IFieldData>): string;
    function SQLUpdate(AObj: T; ATableData: ITableData; AFieldsData: TList<IFieldData>): string;
    function SQLDelete(AObj: T; ATableData: ITableData; AFieldsData: TList<IFieldData>): string;
  end;

implementation

uses
  System.SysUtils, SrORM.DB.Consts, SrORM.RTTI, SrORM.Utils;

{ TSrORMSQlite<T> }

class function TSrORMFirebird<T>.New: ISrORMDB<T>;
begin
  Result := Self.Create;
end;

constructor TSrORMFirebird<T>.Create;
begin
  FRTTI := TSrORMRTTI<T>.New;
end;

function TSrORMFirebird<T>.GetPropertiesField(AFieldData: IFieldData): string;
begin
  Result := EmptyStr;

  if AFieldData.PK then
  begin
    Result := cNotNull + cPK;

    if AFieldData.AutoInc then
      Result := cAutoInc_FB + cPK;
  end;

  if AFieldData.NotNull then
    Result := Result + cNotNull;
end;

function TSrORMFirebird<T>.GetFksFields(ATableData: ITableData;
  AFieldsData: TList<IFieldData>): string;
begin
  Result := EmptyStr;

  for var I := 0 to Pred(AFieldsData.Count) do
  begin
    if not AFieldsData[I].FK.TableName.IsEmpty then
    begin
      Result      := Result.Replace(cSeparator, ', ');
      var xFkName := 'FK_' + ATableData.Name + '_' + AFieldsData[I].FK.TableName;
      var xFk     := Format(cFK_FB, [xFkName, AFieldsData[I].Name, AFieldsData[I].FK.TableName, AFieldsData[I].FK.Field]);
      Result      := Result + xFk + cSeparator;
    end;
  end;
end;

function TSrORMFirebird<T>.ReturnFieldDBType(ATypeKind: TTypeKind; AHandle: PTypeInfo; AFieldData: IFieldData): string;
begin
  Result := EmptyStr;

  case ATypeKind of
    tkInteger,
    tkEnumeration, tkInt64:
    begin
      if AHandle = TypeInfo(Boolean) then
        Result := ' BOOLEAN ';

      if Result.Trim.IsEmpty then
        Result := ' INTEGER ';
    end;
    tkFloat               :
    begin
      if AHandle = TypeInfo(TDateTime) then
        Result := ' TIMESTAMP ';

      if AHandle = TypeInfo(TTime) then
        Result := ' TIME ';

      if AHandle = TypeInfo(TDate) then
        Result := ' DATE ';

      if Result.Trim.IsEmpty then
        Result := Format(' NUMERIC(%s) ', [AFieldData.Size]);
    end;
    tkString, tkLString,
    tkWString, tkUString  : Result := Format(' VARCHAR(%s) ', [AFieldData.Size]);
    tkChar, tkWChar       : Result := Format(' CHAR(%s) ', [AFieldData.Size]);
  end;
end;

function TSrORMFirebird<T>.SQLCreateTable(ATableData: ITableData;
  AFieldsData: TList<IFieldData>): string;
var SQL, SQLFields, PropField: string;
    Field: IFieldData;
begin
  for Field in AFieldsData do
  begin
    SQLFields := SQLFields.Replace(cSeparator, ', ');

    SQLFields := SQLFields + Field.Name + ' ' + ReturnFieldDBType(Field.TType, Field.Handle, Field);
    PropField := GetPropertiesField(Field);
    SQLFields := Concat(SQLFields, PropField);

    SQLFields := Concat(SQLFields, cSeparator);
  end;

  SQLFields := SQLFields.Replace(cSeparator, EmptyStr);
  SQLFields := Concat(SQLFields, cSeparator);
  SQLFields := Concat(SQLFields, GetFksFields(ATableData, AFieldsData));
  SQLFields := SQLFields.Replace(cSeparator, EmptyStr);

  SQL       := Concat(SQL, SQLFields);

  Result := Format(cCREATETABLE, [ATableData.Name, SQL]);
end;

function TSrORMFirebird<T>.SQLAlterTableAddColumn(ATableData: ITableData;
  AFieldData: IFieldData): string;
begin
  Result := Format(cADDCOLUMN_FB, [ATableData.Name, AFieldData.Name,
    ReturnFieldDBType(AFieldData.TType, AFieldData.Handle, AFieldData)]);
end;

function TSrORMFirebird<T>.SQLDropTable(ATableData: ITableData): string;
begin
  Result := Format(cDROPTABLE_FB, [ATableData.Name]);
end;

function TSrORMFirebird<T>.SQLInsert(AObj: T; ATableData: ITableData; AFieldsData: TList<IFieldData>): string;
var Fields, Values: string;
begin
  Fields := TSrORMUtils<T>.GetFields(AFieldsData);
  Values := TSrORMUtils<T>.GetValues(AObj, AFieldsData, FRTTI);

  Result := Format(cINSERT, [ATableData.Name, Fields, Values]);
end;

function TSrORMFirebird<T>.SQLUpdate(AObj: T; ATableData: ITableData; AFieldsData: TList<IFieldData>): string;
var FieldsUpdate, Where: string;
    IndexPk: Integer;
begin
  FieldsUpdate := TSrORMUtils<T>.GetFieldsUpdate(AObj, AFieldsData, FRTTI);
  IndexPk      := TSrORMUtils<T>.GetIndexPkField(AFieldsData);

  if IndexPk < 0 then
    raise Exception.Create('N�o foi encontrada a PK da tabela ' + ATableData.Name);

  Where := AFieldsData[IndexPk].Name + cEQUALS + FRTTI.GetPropValue(AObj, AFieldsData[IndexPk].Name);

  Result := Format(cUPDATEByPK, [ATableData.Name, FieldsUpdate, Where]);
end;

function TSrORMFirebird<T>.SQLDelete(AObj: T; ATableData: ITableData; AFieldsData: TList<IFieldData>): string;
var Where: string;
    IndexPk: Integer;
begin
  IndexPk := TSrORMUtils<T>.GetIndexPkField(AFieldsData);

  if IndexPk < 0 then
    raise Exception.Create('N�o foi encontrada a PK da tabela ' + ATableData.Name);

  Where := AFieldsData[IndexPk].Name + cEQUALS + FRTTI.GetPropValue(AObj, AFieldsData[IndexPk].Name);
  Result := Format(cDELETE, [ATableData.Name, Where]);
end;

end.
