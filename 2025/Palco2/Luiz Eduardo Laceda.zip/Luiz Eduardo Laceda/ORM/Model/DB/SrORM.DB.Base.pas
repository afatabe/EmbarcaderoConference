unit SrORM.DB.Base;

interface

uses
  SrORM.Data.Interfaces, System.Generics.Collections;

type
  TSrORMDBBase = class
  protected
    function ReturnFieldDBType(ATypeKind: TTypeKind): string; virtual; abstract;

    function SQLTableExists(ATableData: ITableData): string; virtual; abstract;
    function SQLCreateTable(ATableData: ITableData; AFieldsData: TList<IFieldData>): string; virtual;
    function GetPropertiesField(AFieldData: IFieldData): string; virtual; abstract;
    function GetFksFields(ATableData: ITableData; AFieldsData: TList<IFieldData>): string; virtual; abstract;
    function SQLAlterTableAddColumn(ATableData: ITableData; AFieldData: IFieldData): string; virtual;
  end;

implementation

uses
  SrORM.DB.Consts, System.SysUtils;

{ TSrORMDBBase }

function TSrORMDBBase.SQLCreateTable(ATableData: ITableData; AFieldsData: TList<IFieldData>): string;
var xSQL, xSQLFields, xPropField: string;
begin
  for var I := 0 to Pred(AFieldsData.Count) do
  begin
    xSQLFields := xSQLFields + AFieldsData[I].Name + ' ' + ReturnFieldDBType(AFieldsData[I].TType);
    xPropField := GetPropertiesField(AFieldsData[I]);
    xSQLFields := Concat(xSQLFields, xPropField);

    if I < Pred(AFieldsData.Count) then
        xSQLFields := xSQLFields + ', ';
  end;

  xSQLFields := Concat(xSQLFields, cSeparator);
  xSQLFields := Concat(xSQLFields, GetFksFields(ATableData, AFieldsData));
  xSQLFields := xSQLFields.Replace(cSeparator, EmptyStr);

  xSQL       := Concat(xSQL, xSQLFields);

  Result := Format(cCREATETABLE, [ATableData.Name, xSQL]);
end;

function TSrORMDBBase.SQLAlterTableAddColumn(ATableData: ITableData;
  AFieldData: IFieldData): string;
begin
  Result := Format(cADDCOLUMN, [ATableData.Name, AFieldData.Name, ReturnFieldDBType(AFieldData.TType)]);
end;

end.
