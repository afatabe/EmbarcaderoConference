unit SrORM.DB.Factory;

interface

uses
  SrORM.DB.Interfaces;

type
  TFactorySrORMDB<T: class, constructor> = class sealed(TInterfacedObject, IFactorySrORMDB<T>)
  public
    class function New: IFactorySrORMDB<T>;

    function GetInstance(const ADriveName: string): ISrORMDB<T>;
  end;

implementation

uses
  SrORM.DB.SQLite, SrORM.DB.Firebird;

{ TFactorySrORMDB }

class function TFactorySrORMDB<T>.New: IFactorySrORMDB<T>;
begin
  Result := Self.Create;
end;

function TFactorySrORMDB<T>.GetInstance(const ADriveName: string): ISrORMDB<T>;
begin
  if ADriveName = 'SQLite' then
    Result := TSrORMSQlite<T>.New
  else
    Result := TSrORMFirebird<T>.New;
end;

end.
