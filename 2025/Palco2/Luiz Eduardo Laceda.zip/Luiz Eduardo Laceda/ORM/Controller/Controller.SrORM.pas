unit Controller.SrORM;

interface

uses
  SrORM.Interfaces, FireDAC.Comp.Client;

type
  TControllerSrORM<T: class, constructor> = class(TInterfacedObject, IControllerSrORM<T>)
  private
    FConnection: TFDConnection;
  public
    class function New(const AConnection: TFDConnection): IControllerSrORM<T>;
    constructor Create(const AConnection: TFDConnection);

    function DDL: IDDL<T>;
    function DML: IDML<T>;
  end;

implementation

uses SrORM.DML, SrORM.DDL;

{ TControllerSrORM<T> }

class function TControllerSrORM<T>.New(const AConnection: TFDConnection): IControllerSrORM<T>;
begin
  Result := Self.Create(AConnection);
end;

constructor TControllerSrORM<T>.Create(const AConnection: TFDConnection);
begin
  FConnection := AConnection;
end;

function TControllerSrORM<T>.DDL: IDDL<T>;
begin
  Result := TDDLSrORM<T>.New(FConnection);
end;

function TControllerSrORM<T>.DML: IDML<T>;
begin
  Result := TDMLSrORM<T>.New(FConnection);
end;

end.
