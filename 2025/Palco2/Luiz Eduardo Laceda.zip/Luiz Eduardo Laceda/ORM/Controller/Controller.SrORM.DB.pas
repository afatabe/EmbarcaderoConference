unit Controller.SrORM.DB;

interface

uses
  SrORM.Data.Interfaces, System.Generics.Collections,
  SrORM.DB.Interfaces, SrORM.Interfaces;

type
  TControllerSrORMDB<T: class, constructor> = class sealed(TInterfacedObject, IControllerSrORMDB<T>)
  private
    FDB: ISrORMDB<T>;
  public
    class function New(const ADriveName: string): IControllerSrORMDB<T>;
    constructor Create(const ADriveName: string);

    function SQLCreateTable(ATableData: ITableData; AFieldsData: TList<IFieldData>): string;
    function SQLAlterTableAddColumn(ATableData: ITableData; AFieldData: IFieldData): string;
    function SQLDropTable(ATableData: ITableData): string;
    function SQLInsert(AObj: T; ATableData: ITableData; AFieldsData: TList<IFieldData>): string;
    function SQLUpdate(AObj: T; ATableData: ITableData; AFieldsData: TList<IFieldData>): string;
    function SQLDelete(AObj: T; ATableData: ITableData; AFieldsData: TList<IFieldData>): string;
  end;

implementation

uses
  SrORM.DB.Factory;

{ TControllerSrORMDB }

class function TControllerSrORMDB<T>.New(const ADriveName: string): IControllerSrORMDB<T>;
begin
  Result := Self.Create(ADriveName);
end;

constructor TControllerSrORMDB<T>.Create(const ADriveName: string);
begin
  FDB := TFactorySrORMDB<T>.New.GetInstance(ADriveName);
end;

function TControllerSrORMDB<T>.SQLCreateTable(ATableData: ITableData; AFieldsData: TList<IFieldData>): string;
begin
  Result := FDB.SQLCreateTable(ATableData, AFieldsData);
end;

function TControllerSrORMDB<T>.SQLAlterTableAddColumn(ATableData: ITableData; AFieldData: IFieldData): string;
begin
  Result := FDB.SQLAlterTableAddColumn(ATableData, AFieldData);
end;

function TControllerSrORMDB<T>.SQLDropTable(ATableData: ITableData): string;
begin
  Result := FDB.SQLDropTable(ATableData);
end;

function TControllerSrORMDB<T>.SQLInsert(AObj: T; ATableData: ITableData;
  AFieldsData: TList<IFieldData>): string;
begin
  Result := FDB.SQLInsert(AObj, ATableData, AFieldsData);
end;

function TControllerSrORMDB<T>.SQLUpdate(AObj: T; ATableData: ITableData;
  AFieldsData: TList<IFieldData>): string;
begin
  Result := FDB.SQLUpdate(AObj, ATableData, AFieldsData);
end;

function TControllerSrORMDB<T>.SQLDelete(AObj: T; ATableData: ITableData;
  AFieldsData: TList<IFieldData>): string;
begin
  Result := FDB.SQLDelete(AObj, ATableData, AFieldsData);
end;

end.
