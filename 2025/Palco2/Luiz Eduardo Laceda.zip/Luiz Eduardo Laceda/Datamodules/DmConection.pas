unit DmConection;

interface

uses
  FireDAC.Stan.Intf, FireDAC.Stan.Option, FireDAC.Stan.Error,
  FireDAC.UI.Intf, FireDAC.Phys.Intf, FireDAC.Stan.Def, FireDAC.Stan.Pool, FireDAC.Stan.Async,
  FireDAC.Phys, FireDAC.Phys.SQLite, FireDAC.Phys.SQLiteDef, FireDAC.Stan.ExprFuncs,
  FireDAC.FMXUI.Wait, FireDAC.Phys.SQLiteWrapper.Stat, FireDAC.Comp.UI, Data.DB, FireDAC.Comp.Client,
  System.Classes, Controller.Database, FireDAC.Phys.FB, FireDAC.Phys.FBDef, FireDAC.Phys.IBBase;

type
  TDmConn = class(TDataModule)
    FdConnSQLite: TFDConnection;
    FDGUIxWaitCursor: TFDGUIxWaitCursor;
    FDPhysSQLiteDriverLink: TFDPhysSQLiteDriverLink;
    FdConnFirebird: TFDConnection;
    FDPhysFBDriverLink: TFDPhysFBDriverLink;
    procedure DataModuleCreate(Sender: TObject);
    procedure DataModuleDestroy(Sender: TObject);
  private
    { Private declarations }
    FControllerDatabase: TControllerDatabase;
  public
    { Public declarations }
  end;

var
  DmConn: TDmConn;

implementation

uses
  System.SysUtils, FMX.Dialogs;

{%CLASSGROUP 'FMX.Controls.TControl'}

{$R *.dfm}

procedure TDmConn.DataModuleCreate(Sender: TObject);
begin
  try
    FControllerDatabase := TControllerDatabase.Create(FdConnSQLite, FdConnFirebird);

    FControllerDatabase.CreateTables;
  except on E: Exception do
    raise Exception.Create(E.Message);
  end;
end;

procedure TDmConn.DataModuleDestroy(Sender: TObject);
begin
  if Assigned(FControllerDatabase) then
    FreeAndNil(FControllerDatabase);
end;

end.
