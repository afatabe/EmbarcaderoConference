object DmConn: TDmConn
  OnCreate = DataModuleCreate
  OnDestroy = DataModuleDestroy
  Height = 480
  Width = 640
  object FdConnSQLite: TFDConnection
    Params.Strings = (
      'DriverID=SQLite')
    Left = 88
    Top = 80
  end
  object FDGUIxWaitCursor: TFDGUIxWaitCursor
    Provider = 'FMX'
    Left = 344
    Top = 80
  end
  object FDPhysSQLiteDriverLink: TFDPhysSQLiteDriverLink
    Left = 208
    Top = 80
  end
  object FdConnFirebird: TFDConnection
    Params.Strings = (
      'DriverID=fB'
      'User_Name=sysdba'
      'Password=masterkey')
    Left = 88
    Top = 136
  end
  object FDPhysFBDriverLink: TFDPhysFBDriverLink
    Left = 208
    Top = 136
  end
end
