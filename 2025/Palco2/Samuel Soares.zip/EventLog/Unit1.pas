unit Unit1;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.StdCtrls;

type
  TForm4 = class(TForm)
    btnExecucao: TButton;
    btnError: TButton;
    mmo: TMemo;
    procedure btnExecucaoClick(Sender: TObject);
    procedure btnErrorClick(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  Form4: TForm4;

implementation

{$R *.dfm}

procedure TForm4.btnErrorClick(Sender: TObject);
begin
  raise Exception.Create('Error Message');
end;

procedure TForm4.btnExecucaoClick(Sender: TObject);
var
  I: Integer;
begin
  for I := 0 to 100 do
  begin
    mmo.Lines.Add(I.ToString);
    OutputDebugStringW(PWideChar(I.ToString));
  end;
end;

end.
