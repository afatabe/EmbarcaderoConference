object Form4: TForm4
  Left = 0
  Top = 0
  Caption = 'Form4'
  ClientHeight = 441
  ClientWidth = 624
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -12
  Font.Name = 'Segoe UI'
  Font.Style = []
  TextHeight = 15
  object btnExecucao: TButton
    Left = 104
    Top = 136
    Width = 75
    Height = 25
    Caption = 'btnExecucao'
    TabOrder = 0
    OnClick = btnExecucaoClick
  end
  object btnError: TButton
    Left = 256
    Top = 136
    Width = 75
    Height = 25
    Caption = 'btnExecucao'
    TabOrder = 1
    OnClick = btnErrorClick
  end
  object mmo: TMemo
    Left = 104
    Top = 16
    Width = 185
    Height = 89
    Lines.Strings = (
      'mmo')
    TabOrder = 2
  end
end
