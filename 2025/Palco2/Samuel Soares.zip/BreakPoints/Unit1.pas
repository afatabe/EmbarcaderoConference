unit Unit1;

interface

uses
  System.SysUtils, System.Types, System.UITypes, System.Classes, System.Variants,
  FMX.Types, FMX.Controls, FMX.Forms, FMX.Graphics, FMX.Dialogs,
  FMX.Controls.Presentation, FMX.StdCtrls, FMX.Memo.Types, FMX.ScrollBox,
  FMX.Memo;

type
  TForm1 = class(TForm)
    btnBreakpoint: TButton;
    mmo1: TMemo;
    btn2: TButton;
    btnAtalhos: TButton;
    procedure btnBreakpointClick(Sender: TObject);
    procedure btn2Click(Sender: TObject);
    procedure btnAtalhosClick(Sender: TObject);
  private
    procedure ListarNumeros;
    procedure EscreverLog(ANumero: Integer);
  public
    { Public declarations }
  end;

var
  Form1: TForm1;

implementation

{$R *.fmx}

procedure TForm1.btnAtalhosClick(Sender: TObject);
begin
  //F5
  //F7
  //F8
  //F9
  //Mover breakpoints
  ListarNumeros;
end;

procedure TForm1.btnBreakpointClick(Sender: TObject);
var
  I: Integer;
begin
  mmo1.Lines.Clear;
  for I := 0 to 10 do
  begin
    mmo1.Lines.Add(i.ToString);
  end;
end;

procedure TForm1.EscreverLog(ANumero: Integer);
begin
  mmo1.Lines.Add(ANumero.ToString);
end;

procedure TForm1.ListarNumeros;
var
  I: Integer;
begin
  mmo1.Lines.Clear;
  for I := 0 to 10 do
    EscreverLog(I);
end;

procedure TForm1.btn2Click(Sender: TObject);
var
  I: Integer;
  LEstado: string;
const
  cListaEstados: array [0..26] of string = ('AC', 'AL', 'AM', 'AP', 'BA', 'CE', 'DF',
   'ES', 'GO', 'MA', 'MG', 'MS', 'MT', 'PA', 'PB', 'PE', 'PI', 'PR', 'RJ', 'RN', 'RO',
   'RR', 'RS', 'SC', 'SE', 'SP', 'TO');
begin
  for LEstado in cListaEstados do
  begin
    if LEstado = 'RJ' then
    begin
      // ... Fa�a sua rotina aqui
    end;
  end;
end;

end.
