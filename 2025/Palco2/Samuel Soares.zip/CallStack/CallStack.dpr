program CallStack;

uses
  Vcl.Forms,
  Unit1 in 'Unit1.pas' {Form3},
  uNotaFiscal in 'uNotaFiscal.pas';

{$R *.res}

begin
  Application.Initialize;
  Application.MainFormOnTaskbar := True;
  Application.CreateForm(TForm3, Form3);
  Application.Run;
end.
