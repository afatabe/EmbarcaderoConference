unit uNotaFiscal;

interface

type
  TNotaFiscal = class
  private
    { private declarations }
  protected
    procedure CalcularIcms;
    procedure CalcularIPI;
  public
    procedure CalcularImposto;
  end;

implementation

uses
  System.SysUtils;

{ TNotaFiscal }

procedure TNotaFiscal.CalcularIcms;
begin
  CalcularIPI;
end;

procedure TNotaFiscal.CalcularImposto;
begin
  CalcularIcms;
end;

procedure TNotaFiscal.CalcularIPI;
begin
  raise Exception.Create('Simula��o de erro!');
end;

end.
