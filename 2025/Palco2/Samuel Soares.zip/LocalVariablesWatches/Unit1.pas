unit Unit1;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.StdCtrls, uPessoa;

type
  TForm2 = class(TForm)
    btnDebug: TButton;
    mmo1: TMemo;
    procedure btnDebugClick(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  Form2: TForm2;

implementation

{$R *.dfm}

procedure TForm2.btnDebugClick(Sender: TObject);
var
  LPessoa: TPessoa;
begin
  mmo1.Lines.Clear;
  LPessoa := TPessoa.Create;
  try
    LPessoa.id := 1;
    LPessoa .nome := 'Teste';

    mmo1.Lines.Add(LPessoa.nome);
  finally
    LPessoa.Free;
  end;
end;

end.
