object Form2: TForm2
  Left = 0
  Top = 0
  Caption = 'Form2'
  ClientHeight = 441
  ClientWidth = 624
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -12
  Font.Name = 'Segoe UI'
  Font.Style = []
  TextHeight = 15
  object btnDebug: TButton
    Left = 264
    Top = 192
    Width = 75
    Height = 25
    Caption = 'Debug'
    TabOrder = 0
    OnClick = btnDebugClick
  end
  object mmo1: TMemo
    Left = 160
    Top = 56
    Width = 185
    Height = 89
    Lines.Strings = (
      'mmo1')
    TabOrder = 1
  end
end
