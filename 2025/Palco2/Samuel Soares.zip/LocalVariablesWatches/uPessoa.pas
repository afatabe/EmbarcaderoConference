unit uPessoa;

interface

type
  TPessoa = class
  private
    Fid: Integer;
    Fnome: string;
  public
    property id: Integer read Fid write Fid;
    property nome: string read Fnome write Fnome;
  end;

implementation

end.
