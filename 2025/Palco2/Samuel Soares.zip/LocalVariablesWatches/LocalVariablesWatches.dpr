program LocalVariablesWatches;

uses
  Vcl.Forms,
  Unit1 in 'Unit1.pas' {Form2},
  uPessoa in 'uPessoa.pas';

{$R *.res}

begin
  Application.Initialize;
  Application.MainFormOnTaskbar := True;
  Application.CreateForm(TForm2, Form2);
  Application.Run;
end.
