program Project1;

uses
  System.StartUpCopy,
  FMX.Forms,
  uFormRelatorio in 'uFormRelatorio.pas' {FormRelatorio};

{$R *.res}

begin
  Application.Initialize;
  Application.CreateForm(TFormRelatorio, FormRelatorio);
  Application.Run;
end.
