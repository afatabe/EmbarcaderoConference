unit uFormRelatorio;

interface

uses
  System.SysUtils,
  System.Types,
  System.UITypes,
  System.Classes,
  System.Variants,
  FMX.Types,
  FMX.Controls,
  FMX.Forms,
  FMX.Graphics,
  FMX.Dialogs,
  FMX.Controls.Presentation,
  FMX.StdCtrls,
  FMX.ListBox,
  FMX.WebBrowser,
  FMX.Layouts, FMX.Memo.Types, FMX.ScrollBox, FMX.Memo;

type
  TFormRelatorio = class(TForm)
    Layout1: TLayout;
    Layout2: TLayout;
    Layout3: TLayout;
    WebBrowser1: TWebBrowser;
    SpeedButton1: TSpeedButton;
    Memo1: TMemo;
    SpeedButton2: TSpeedButton;
    Layout4: TLayout;
    ComboBoxRelatorios: TComboBox;
    SpeedButton3: TSpeedButton;
    procedure SpeedButton1Click(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure SpeedButton2Click(Sender: TObject);
    procedure SpeedButton3Click(Sender: TObject);
  private
    FCaminhoRelatorio: String;
    procedure CarregarRelatorios;
  public
    { Public declarations }
  end;

var
  FormRelatorio: TFormRelatorio;

implementation

{$R *.fmx}

uses
  RESTRequest4D,
  System.JSON;

procedure TFormRelatorio.CarregarRelatorios;
var
  SR: TSearchRec;
begin
  FCaminhoRelatorio := 'C:\Users\aleme\Desktop\Conference2025\erp-ambiente-n8n-ollama\relatorios\delphi_reports\';
  ComboBoxRelatorios.Clear;
  if FindFirst(FCaminhoRelatorio + '*.html', faAnyFile, SR) = 0 then
  repeat
    ComboBoxRelatorios.Items.Add(SR.Name);
  until FindNext(SR) <> 0;
  FindClose(SR);
end;

procedure TFormRelatorio.FormCreate(Sender: TObject);
begin
  CarregarRelatorios;
end;

procedure TFormRelatorio.SpeedButton1Click(Sender: TObject);
begin
  var LArquivo := FCaminhoRelatorio + ComboBoxRelatorios.Items[ComboBoxRelatorios.ItemIndex];
  WebBrowser1.Navigate(Larquivo);
end;

procedure TFormRelatorio.SpeedButton2Click(Sender: TObject);
begin
  var LJSON := TJSONObject.Create;
  try
    LJSON.AddPair('prompt', Memo1.Text.Trim);
    var LResponse := TRequest.New.BaseURL('http://localhost:5678/webhook/relatorio-pronto')
    .Accept('aplication/json')
    .AddBody(LJSON.ToString)
    .Timeout(120000)
    .Post;

    if LResponse.StatusCode = 200 then
    begin
      var LContent := LResponse.Content;
      var LJsonValue := TJSONObject.ParseJSONValue(LResponse.Content);
      ShowMessage('Relat�rio Gerado com Sucesso ' + LJsonValue.GetValue<string>('filename'));
    end;
  finally
    LJSON.free;
  end;
end;

procedure TFormRelatorio.SpeedButton3Click(Sender: TObject);
begin
  CarregarRelatorios;
end;

end.
