
unit FormRelatorio;

interface

uses
  System.SysUtils, System.Types, System.UITypes, System.Classes, FMX.Types,
  FMX.Controls, FMX.Forms, FMX.WebBrowser, FMX.StdCtrls, FMX.Layouts, FMX.ComboBox;

type
  TFormRelatorio = class(TForm)
    Layout1: TLayout;
    ComboBoxRelatorios: TComboBox;
    BtnAbrir: TButton;
    WebBrowser1: TWebBrowser;
    procedure FormCreate(Sender: TObject);
    procedure BtnAbrirClick(Sender: TObject);
  private
    procedure CarregarRelatorios;
  public
  end;

var
  FormRelatorio: TFormRelatorio;

implementation

{$R *.fmx}

procedure TFormRelatorio.FormCreate(Sender: TObject);
begin
  CarregarRelatorios;
end;

procedure TFormRelatorio.CarregarRelatorios;
var
  SR: TSearchRec;
begin
  ComboBoxRelatorios.Clear;
  if FindFirst('/opt/erp/relatorios/*.html', faAnyFile, SR) = 0 then
  repeat
    ComboBoxRelatorios.Items.Add(SR.Name);
  until FindNext(SR) <> 0;
  SysUtils.FindClose(SR);
end;

procedure TFormRelatorio.BtnAbrirClick(Sender: TObject);
begin
  if ComboBoxRelatorios.ItemIndex >= 0 then
    WebBrowser1.Navigate('file:///opt/erp/relatorios/' + ComboBoxRelatorios.Items[ComboBoxRelatorios.ItemIndex]);
end;

end.
