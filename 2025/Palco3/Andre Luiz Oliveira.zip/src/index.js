/**
 * AVISO: ESTE CÓDIGO É INTENCIONALMENTE INSEGURO — DEMO APENAS
 * Contém:
 * - Credenciais hardcoded (AWS, OpenAI)
 * - PII (CPF, email)
 * - Dependência vulnerável (lodash 4.17.19)
 */

const _ = require("lodash"); // versão antiga vulnerável (Prototype Pollution)

// === SEGREDOS HARDCODED (má prática) ===
const AWS_ACCESS_KEY_ID = "AKIA1234567890DEMO";
const AWS_SECRET_ACCESS_KEY = "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY";
const OPENAI_API_KEY = "sk-live-THIS_IS_A_DEMO_KEY"; // nunca faça isso

// === PII DIRETO NO CÓDIGO (má prática) ===
const user = {
  name: "João da Silva",
  cpf: "123.456.789-09",           // dado sensível
  email: "joao.silva@example.com" // dado sensível
};

// === Uso inseguro de lodash.merge (pode causar prototype pollution) ===
let config = { featureFlags: { beta: false } };
const payload = JSON.parse('{"__proto__": {"isAdmin": true}}');
_.merge(config, payload);

// === Simulação de log inseguro ===
console.log("Credenciais:", AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, OPENAI_API_KEY);
console.log("Usuário:", user);
console.log("Config após merge:", config);

// === Saída esperada (insegura) ===
// Logs mostram credenciais e dados pessoais em claro
// config.isAdmin pode aparecer true devido à prototype pollution
