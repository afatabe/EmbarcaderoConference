"""
AVISO: Código intencionalmente inseguro — apenas para demo
"""
import yaml
import requests  # suponha que foi importado corretamente

# Hardcoded secrets (má prática)
AWS_ACCESS_KEY_ID = "AKIA1234567890DEMO"
AWS_SECRET_ACCESS_KEY = "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"

user = {
    "name": "João da Silva",
    "cpf": "123.456.789-09",
    "email": "joao.silva@example.com"
}

# Vulnerabilidade em PyYAML (usa load() em vez de safe_load)
with open("payload.yaml") as f:
    data = yaml.load(f, Loader=yaml.Loader)  # inseguro! pode executar código arbitrário

print("User:", user)
print("Dados do YAML:", data)
