unit ClientApp.MainForm;

interface

uses
  System.SysUtils,
  System.Variants,
  System.Classes,
  System.UITypes,
  System.Generics.Collections,
  Vcl.Themes,
  System.Math,
  Vcl.Graphics,
  Vcl.Controls,
  Vcl.Forms,
  Vcl.Dialogs,
  Vcl.StdCtrls,
  Vcl.ExtCtrls,
  Vcl.Samples.Spin,
  Vcl.ComCtrls,
  ClientApp.Card.Widget,
  ClientApp.UserModel,
  ClientApp.Result,
  ClientApp.Pipeline.Interfaces;

type
  TMainForm = class(TForm)
    ButtonsPanel: TPanel;
    CancelarButton: TButton;
    FlowLayoutResults: TFlowPanel;
    IniciarParallelPPLButton: TButton;
    IniciarPPLButton: TButton;
    IniciarTThreadButton: TButton;
    ScrollBox: TScrollBox;
    QuantidadeLabel: TLabel;
    QuantidadeSpinEdit: TSpinEdit;
    ProgressBar: TProgressBar;
    SimularLatenciaCheckBox: TCheckBox;
    FixCardFontCheckBox: TCheckBox;
    procedure FormCreate(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure IniciarParallelPPLButtonClick(Sender: TObject);
    procedure IniciarPPLButtonClick(Sender: TObject);
    procedure IniciarTThreadButtonClick(Sender: TObject);
    procedure CancelarButtonClick(Sender: TObject);
  private
    FCardMap: TDictionary<Integer, TPanel>;
    FCurrentPipeline: IPipelineStrategy;
    FFontSize: Integer;
    FIsCancelling: Boolean;
    FIsDestroying: Boolean;
    FStartTime: TDateTime;

    function CanStartThreadStrategy: Boolean;
    function CreateNewCards(Count: Integer): TArray<Integer>;
    function CanStartPipeline: Boolean;
    procedure UpdateCardStatus(Id: Integer; Status: TPipelineStatus;
      Data: TObject);
    procedure ClearResults;
    procedure PipelineCompleted;
    procedure SetUIState(IsRunning: Boolean);
    procedure StartPipeline(const StrategyClass: TPipelineStrategyClass);
    procedure ConfigControls;
  end;

var
  MainForm: TMainForm;

implementation

{$R *.dfm}

uses
  System.DateUtils,
  System.TypInfo,
  System.Threading,
  ClientApp.Client.Service,
  ClientApp.ParallelFor.Strategy,
  ClientApp.Task.Strategy,
  ClientApp.Thread.Strategy,
  ClientApp.Utils;

{ TMainForm }

procedure TMainForm.FormCreate(Sender: TObject);
begin
  FIsDestroying := False;
  FCardMap := TDictionary<Integer, TPanel>.Create;
  ConfigControls;
  SetUIState(False);
end;

procedure TMainForm.FormDestroy(Sender: TObject);
begin
  FIsDestroying := True;
  if Assigned(FCurrentPipeline) then
    FCurrentPipeline.Cancel;
  FCurrentPipeline := nil;
  FCardMap.Free;
end;

procedure TMainForm.ConfigControls;
begin
  IniciarTThreadButton.Caption := 'Executar com TThread';
  IniciarPPLButton.Caption := 'Executar com Task';
  IniciarParallelPPLButton.Caption := 'Executar com Parallel.For';
  CancelarButton.Caption := 'Cancelar';
  QuantidadeLabel.Caption := 'Requisi��es:';
end;

procedure TMainForm.SetUIState(IsRunning: Boolean);
begin
  IniciarTThreadButton.Enabled := not IsRunning;
  IniciarPPLButton.Enabled := not IsRunning;
  IniciarParallelPPLButton.Enabled := not IsRunning;
  QuantidadeSpinEdit.Enabled := not IsRunning;
  SimularLatenciaCheckBox.Enabled := not IsRunning;
  FixCardFontCheckBox.Enabled := not IsRunning;
  CancelarButton.Enabled := IsRunning;

  if IsRunning then
  begin
    CancelarButton.SetFocus;
    ProcessControlMessages(CancelarButton);
  end;
end;

function TMainForm.CanStartPipeline: Boolean;
begin
  Result := not Assigned(FCurrentPipeline);
end;

procedure TMainForm.ClearResults;
begin
  FlowLayoutResults.Visible := False;
  try
    FIsCancelling := False;
    ProgressBar.Position := 0;
    ProgressBar.Refresh;
    FCardMap.Clear;
    while FlowLayoutResults.ControlCount > 0 do
      FlowLayoutResults.Controls[0].Free;

    FlowLayoutResults.Align := alTop;
    FlowLayoutResults.Height := FlowLayoutResults.Parent.ClientHeight;
    FlowLayoutResults.AutoSize := True;
  finally
    FlowLayoutResults.Visible := True;
  end;
  Application.ProcessMessages;
end;

function TMainForm.CanStartThreadStrategy: Boolean;
begin
  Result := True;
  var MaxtThreads := TThreadPoolStats.Default.MaxLimitWorkerThreadCount;
  var ThreadsRequested := QuantidadeSpinEdit.Value;

  if QuantidadeSpinEdit.Value > MaxtThreads then
  begin
    var Msg := Format('Voc� est� requisitando %d Threads.' + sLineBreak +
       'O n�mero m�ximo recomendado para a sua CPU � de %d.' + sLineBreak +
       'Deseja Continuar?', [ThreadsRequested, MaxtThreads]);

    Result := MessageDlg(Msg, mtWarning, [mbOK, mbCancel], 0) = mrOK;
    if not Result then
    begin
      QuantidadeSpinEdit.SetFocus;
    end;
  end;
end;

procedure TMainForm.IniciarTThreadButtonClick(Sender: TObject);
begin
  if CanStartThreadStrategy then
    StartPipeline(TThreadStrategy);
end;

procedure TMainForm.IniciarPPLButtonClick(Sender: TObject);
begin
  StartPipeline(TTaskStrategy);
end;

procedure TMainForm.IniciarParallelPPLButtonClick(Sender: TObject);
begin
  StartPipeline(TParallelForStrategy);
end;

procedure TMainForm.CancelarButtonClick(Sender: TObject);
begin
  FIsCancelling := True;
  if Assigned(FCurrentPipeline) then
  begin
    FCurrentPipeline.Cancel;
  end;
  PipelineCompleted;
end;

procedure TMainForm.StartPipeline(const StrategyClass: TPipelineStrategyClass);
var
  Ids: TArray<Integer>;
  Count: Integer;
  ClientService: IClientService;
begin
  if not CanStartPipeline then
    Exit;

  ClearResults;
  Count := QuantidadeSpinEdit.Value;
  ProgressBar.Max := Count;
  SetUIState(True);
  FStartTime := Now;

  if FixCardFontCheckBox.Checked then
    FFontSize := Trunc(MainForm.Font.Size * 50 / 75)
  else
    FFontSize := MainForm.Font.Size;

  Ids := CreateNewCards(Count);

  // Inje��o de Depend�ncia manual do servi�o
  ClientService := TClientService.Create(SimularLatenciaCheckBox.Checked);

  // Cria a estrat�gia escolhida, injetando o servi�o
  FCurrentPipeline := StrategyClass.Create(ClientService);

  // Executa o pipeline
  FCurrentPipeline.Execute(Ids, UpdateCardStatus, PipelineCompleted);
end;

procedure TMainForm.UpdateCardStatus(Id: Integer; Status: TPipelineStatus;
  Data: TObject);
var
  Card: TPanel;
  Color: TColor;
  Text: string;
begin
  if FIsDestroying or not FCardMap.TryGetValue(Id, Card) then
  begin
    if Assigned(Data) then
      Data.Free;
    Exit;
  end;

  case Status of
    TPipelineStatus.Downloading:
      begin
        Color := TColors.Royalblue;
        Text := 'Baixando...' + sLineBreak + '(ID: ' + Id.ToString + ')';
      end;
    TPipelineStatus.Serializing:
      begin
        Color := TColors.Goldenrod;
        Text := 'Serializando...' + sLineBreak + '(ID: ' + Id.ToString + ')';
      end;
    TPipelineStatus.Success:
      begin
        Color := TColors.Green;
        var User := Data as TUserModel;
        Text := Format('ID: %d' + sLineBreak + '%s' + sLineBreak + '[%s]',
          [User.Id, User.Name, User.Source]);
      end;
    TPipelineStatus.Error:
      begin
        Color := TColors.Darkred;

        if Assigned(Data) then
        begin
          var Error := Data as Exception;
          Text := Format('ID: %d' + sLineBreak + '%s', [Id, Error.Message]);
        end
        else
        if FIsCancelling then
        begin
          Color := TColors.Orange;
          Text := Format('ID: %d' + sLineBreak + '%s', [Id, 'Cancelado']);
        end
        else
          Text := Format('ID: %d' + sLineBreak + '%s', [Id, 'Erro']);
      end;
    TPipelineStatus.Cancelled:
      begin
        Color := TColors.Orange;
        Text := Format('ID: %d' + sLineBreak + 'Cancelado', [Id]);
      end;
  else
    Color := TColors.Mediumpurple;
    Text := 'Estado Desconhecido';
  end;

  (Card as TCard).UpdateStatus(CalculateColorShadeByTime(Color, Id,
    QuantidadeSpinEdit.Value, FStartTime), Text);

  if Status in [TPipelineStatus.Success, TPipelineStatus.Error, TPipelineStatus.Cancelled] then
    ProgressBar.Position := ProgressBar.Position + 1;

  if Assigned(Data) then
    Data.Free;
end;

procedure TMainForm.PipelineCompleted;
begin
  if FIsDestroying then
    Exit;
  SetUIState(False);
  FCurrentPipeline := nil;

  if FIsCancelling then
  begin
    for var i := 0 to FlowLayoutResults.ControlCount -1 do
    begin
      var Card := TPanel(FlowLayoutResults.Controls[i]);
      var CardText := TLabel(Card.Controls[0]);
      var Text: string := CardText.Caption;
      if Text.Contains('Aguardando') or
         Text.Contains('Baixando') or
         Text.Contains('Serializando') then
      begin
        CardText.Caption := Format('ID: %d' + sLineBreak + '%s',
          [Card.Tag, 'Cancelado']);
        Card.Color := CalculateColorShadeByTime(TColors.Orangered, Card.Tag,
          QuantidadeSpinEdit.Value, FStartTime);

        if ProgressBar.Position < ProgressBar.Max then
          ProgressBar.Position := ProgressBar.Position + 1;
      end;
    end;
  end;
end;

function TMainForm.CreateNewCards(Count: Integer): TArray<Integer>;
begin
  FlowLayoutResults.Visible := False;
  try
    SetLength(Result, Count);
    for var i := 1 to Count do
    begin
      var CardCaption := 'Aguardando...' + sLineBreak + '(ID: ' + i.ToString + ')';
      // Agora criamos uma inst�ncia da nossa classe TCard
      var Card := TCard.Create(Self, CardCaption, i, FFontSize);
      FCardMap.Add(i, Card);
      Card.Parent := FlowLayoutResults;
      Result[i - 1] := i;
    end;
  finally
    FlowLayoutResults.Visible := True;
    FlowLayoutResults.Refresh;
  end;
end;

end.

