unit ClientApp.Task.Strategy;

interface

uses
  System.Classes, System.Generics.Collections, System.SysUtils,
  System.Threading,
  ClientApp.Pipeline.Interfaces;

type
  TTaskStrategy = class(TPipelineStrategy)
  private
    FOrchestrator: ITask;
    function CreateWorkerTask(Id: Integer;
      const StatusCallback: TStatusUpdateCallback): ITask;
  public
    procedure Execute(const Ids: TArray<Integer>;
      const StatusCallback: TStatusUpdateCallback;
      const CompletionCallback: TCompletionEvent); override;
    procedure Cancel; override;
  end;

implementation

uses
  ClientApp.Result,
  ClientApp.UserModel;

procedure TTaskStrategy.Execute(const Ids: TArray<Integer>;
  const StatusCallback: TStatusUpdateCallback;
  const CompletionCallback: TCompletionEvent);
begin
  FOrchestrator := TTask.Run(
    procedure
    var
      RunningTasks: TList<ITask>;
      Token: ITask;
    begin
      Token := TTask.CurrentTask;
      RunningTasks := TList<ITask>.Create;
      try
        // Dispara uma tarefa para cada Id usando a fun��o auxiliar
        for var i := 0 to High(Ids) do
          RunningTasks.Add(CreateWorkerTask(Ids[i], StatusCallback));

        // A tarefa pai espera por todas as filhas
        TTask.WaitForAll(RunningTasks.ToArray);
      finally
        // Quando tudo termina, chama o callback de conclus�o
        if Assigned(CompletionCallback) then
          TThread.Synchronize(nil, CompletionCallback);
        RunningTasks.Free;
      end;
    end);
end;

// Esta fun��o encapsula a l�gica de UMA unidade de trabalho
function TTaskStrategy.CreateWorkerTask(Id: Integer;
  const StatusCallback: TStatusUpdateCallback): ITask;
var
  Token: ITask;
begin
  Token := TTask.CurrentTask;
  Result := TTask.Run(
    procedure
    var
      DownloadResult: TDownloadResult;
      FinalResult: TUserModelResult;
      Service: IClientService;

      function CheckCancelled(Id: Integer; const Token: ITask;
        const StatusCallback: TStatusUpdateCallback): Boolean;
      begin
        Result := Token.Status = TTaskStatus.Canceled;
        if Result then
        begin
          TThread.Synchronize(nil,
            procedure
            begin
              StatusCallback(Id, TPipelineStatus.Cancelled, nil);
            end);
        end;
      end;
    begin
      try
        Service := FClientService;
        if CheckCancelled(Id, Token, StatusCallback) then
          Exit;

        NotifyStatus(StatusCallback, Id, TPipelineStatus.Downloading);
        DownloadResult := Service.DownloadUserData(Id);

        if CheckCancelled(Id, Token, StatusCallback) then
          Exit;

        if DownloadResult.IsSuccess then
        begin
          NotifyStatus(StatusCallback, Id, TPipelineStatus.Serializing);
          FinalResult := Service.SerializeUserData(DownloadResult);
        end
        else
          FinalResult := TUserModelResult.Failure(DownloadResult.Error);

        if CheckCancelled(Id, Token, StatusCallback) then
        begin
          FinalResult.Finalize;
          Exit;
        end;

        if FinalResult.IsSuccess then
          NotifyStatus(StatusCallback, Id, TPipelineStatus.Success, FinalResult.Value)
        else
          NotifyStatus(StatusCallback, Id, TPipelineStatus.Error, FinalResult.Error);
      except
        on E: EOperationCancelled do
        begin
          FinalResult.Finalize;
          NotifyStatus(StatusCallback, Id, TPipelineStatus.Cancelled, AcquireExceptionObject);
        end;

        on E: Exception do
        begin
          FinalResult.Finalize;
          NotifyStatus(StatusCallback, Id, TPipelineStatus.Error, AcquireExceptionObject);
        end;
      end;
    end);
end;

procedure TTaskStrategy.Cancel;
begin
  inherited Cancel;
  FOrchestrator.Cancel;
end;

end.
