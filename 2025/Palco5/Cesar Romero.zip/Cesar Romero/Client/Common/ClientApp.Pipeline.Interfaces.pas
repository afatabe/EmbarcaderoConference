unit ClientApp.Pipeline.Interfaces;

interface

uses
  ClientApp.Result,
  ClientApp.UserModel;

type
  TPipelineStatus = (Loading, Downloading, Serializing, Success, Error, Cancelled);

  TStatusUpdateCallback = reference to procedure(Id: Integer;
    Status: TPipelineStatus; Data: TObject);

  TCompletionEvent = procedure of object;

  TUserModelResult = TResult<TUserModel>;
  TUserModelResultHelper = record helper for TUserModelResult
  public
    procedure Finalize;
  end;

  TDownloadResult = TResult<string>;

  IClientService = interface
    ['{E5B92B7C-5B8A-4A9A-9A82-8E303A4E5D6A}']
    function DownloadUserData(Id: Integer): TDownloadResult;
    function SerializeUserData(const JsonResult: TDownloadResult)
      : TUserModelResult;
  end;

  IPipelineStrategy = interface
    ['{BADD2E6E-255A-4A0B-A551-7E05C5E4700E}']
    procedure Execute(const Ids: TArray<Integer>;
      const StatusCallback: TStatusUpdateCallback;
      const CompletionCallback: TCompletionEvent);
    procedure Cancel;
    procedure NotifyStatus(StatusCallback: TStatusUpdateCallback; Id: Integer;
      Status: TPipelineStatus; Data: TObject = nil);
  end;

  // TODO : Implementar UnitOfWork para o Execute chamar
  TPipelineStrategyClass = class of TPipelineStrategy;
  TPipelineStrategy = class(TInterfacedObject, IPipelineStrategy)
  protected
    FClientService: IClientService;
  public
    constructor Create(const ClientService: IClientService);
    procedure Execute(const Ids: TArray<Integer>;
      const StatusCallback: TStatusUpdateCallback;
      const CompletionCallback: TCompletionEvent); virtual; abstract;
    procedure Cancel; virtual;
    procedure NotifyStatus(StatusCallback: TStatusUpdateCallback; Id: Integer;
      Status: TPipelineStatus; Data: TObject = nil);
  end;

implementation

uses
  System.Classes,
  System.SyncObjs;

{ TThreadStrategy }

procedure TPipelineStrategy.Cancel;
begin
  //
end;

constructor TPipelineStrategy.Create(const ClientService: IClientService);
begin
  inherited Create;
  FClientService := ClientService;
end;

procedure TPipelineStrategy.NotifyStatus(StatusCallback: TStatusUpdateCallback;
  Id: Integer; Status: TPipelineStatus; Data: TObject = nil);
begin
  if Assigned(StatusCallback) then
  begin
    TThread.Queue(nil,
      procedure
      begin
        StatusCallback(Id, Status, Data);
      end);
  end;
end;

{ TUserModelResultHelper }

procedure TUserModelResultHelper.Finalize;
begin
  try
    if Assigned(Value) then Value.Free;
    if Assigned(Error) then Error.Free;
    Success(nil);
  except
    Success(nil);
  end;
end;

end.
