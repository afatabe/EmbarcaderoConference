unit ClientApp.Result;

interface

uses
  System.SysUtils;

type
  // Record gen�rico para encapsular o resultado de uma opera��o,
  // que pode ser um sucesso (com um valor) ou uma falha (com uma exce��o).
  TResult<T> = record
  private
    FValue: T;
    FError: Exception;
  public
    function IsSuccess: Boolean;

    property Value: T read FValue;
    property Error: Exception read FError;

    class function Success(const Value: T): TResult<T>; static;
    class function Failure(const Error: Exception): TResult<T>; static;
  end;

implementation

{ TResult<T> }

class function TResult<T>.Success(const Value: T): TResult<T>;
begin
  Result.FValue := Value;
  Result.FError := nil;
end;

class function TResult<T>.Failure(const Error: Exception): TResult<T>;
begin
  Result.FValue := Default(T);
  Result.FError := Error;
end;

function TResult<T>.IsSuccess: Boolean;
begin
  Result := (FError = nil) and (FValue <> Default(T));
end;

end.
