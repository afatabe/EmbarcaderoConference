unit ClientApp.UserModel;

interface

type
  // Objeto simples para representar os dados do JSON
  TUserModel = class
  private
    FID: Integer;
    FName: string;
    FSource: string;
  public
    constructor Create(const ID: Integer; const Name, Source: string);

    property ID: Integer read FID;
    property Name: string read FName;
    property Source: string read FSource;
  end;

implementation

constructor TUserModel.Create(const ID: Integer; const Name, Source: string);
begin
  inherited Create;
  FID := ID;
  FName := Name;
  FSource := Source;
end;

end.
