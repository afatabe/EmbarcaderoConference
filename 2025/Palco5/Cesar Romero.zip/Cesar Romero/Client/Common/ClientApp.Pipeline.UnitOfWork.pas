unit ClientApp.Pipeline.UnitOfWork;

interface

uses
  System.SysUtils,
  ClientApp.ClientService,
  ClientApp.Pipeline.Interfaces,
  ClientApp.Result,
  ClientApp.UserModel;

procedure ExecuteUnitOfWork(Id: Integer;
  const ClientService: IClientService;
  const StatusCallback: TStatusUpdateCallback;
  const CancellationCheck: TFunc<Boolean>);

implementation

uses
  System.Classes,
  System.Threading;

procedure ExecuteUnitOfWork(Id: Integer;
  const ClientService: IClientService;
  const StatusCallback: TStatusUpdateCallback;
  const CancellationCheck: TFunc<Boolean>);
var
  DownloadResult: TResult<string>;
  FinalResult: TResult<TUserModel>;
begin
  try
    // --- ETAPA 1: DOWNLOAD ---
    var capturedIdForDownload := Id; // << CORRE��O
    TThread.Synchronize(nil, procedure
    begin
      StatusCallback(capturedIdForDownload, TPipelineStatus.Downloading, nil);
    end);
    DownloadResult := ClientService.DownloadUserData(Id);

    if CancellationCheck() then // << CORRE��O
      raise EOperationCancelled.Create('Cancelled');

    // --- ETAPA 2: SERIALIZA��O ---
    if DownloadResult.IsSuccess then
    begin
      var capturedIdForSerializing := Id; // << CORRE��O
      TThread.Synchronize(nil, procedure
      begin
        StatusCallback(capturedIdForSerializing, TPipelineStatus.Serializing, nil);
      end);
    end;

    FinalResult := ClientService.SerializeUserData(DownloadResult);
    // << CORRE��O >> Libera o erro do download para evitar leak
    if not DownloadResult.IsSuccess then
      DownloadResult.Error.Free;

    if CancellationCheck() then // << CORRE��O
      raise EOperationCancelled.Create('Cancelled');

    // --- ETAPA 3: RESULTADO FINAL ---
    var capturedIdForFinal := Id; // << CORRE��O
    var capturedResult := FinalResult; // Captura o record tamb�m
    TThread.Synchronize(nil, procedure
    begin
      if capturedResult.IsSuccess then
        StatusCallback(capturedIdForFinal, TPipelineStatus.Success, capturedResult.Value)
      else
        StatusCallback(capturedIdForFinal, TPipelineStatus.Error, capturedResult.Error);
    end);
  except
    on E: EOperationCancelled do
    begin
      var capturedIdForCancel := Id; // << CORRE��O
      TThread.Synchronize(nil, procedure begin StatusCallback(capturedIdForCancel, TPipelineStatus.Cancelled, E); end);
    end;
    on E: Exception do
    begin
      var capturedIdForError := Id; // << CORRE��O
      TThread.Synchronize(nil, procedure begin StatusCallback(capturedIdForError, TPipelineStatus.Error, E); end);
    end;
  end;
end;

end.
