unit ClientApp.Card.Widget;

interface

uses
  System.Classes,
  System.UITypes,
  Vcl.Controls,
  Vcl.ExtCtrls,
  Vcl.StdCtrls,
  Vcl.Graphics;

type
  TCard = class(TPanel)
  private
    FCardLabel: TLabel;
  public
    constructor Create(Owner: TComponent; const Text: string;
      Index, FontSize: Integer); reintroduce;
    procedure UpdateStatus(Color: TColor; const Text: string);
  end;

implementation

uses
  ClientApp.Utils;

{ TCard }

constructor TCard.Create(Owner: TComponent; const Text: string;
  Index, FontSize: Integer);
begin
  inherited Create(Owner);

  Tag := Index;
  ParentBackground := False;
  ParentColor := False;
  StyleName := 'Windows';
  Color := TColors.Gray;
  Caption := '';
  BevelOuter := bvNone;
  Height := 80;
  Width := 180;
  AlignWithMargins := True;
  Margins.SetBounds(1, 1, 1, 1);

  FCardLabel := TLabel.Create(Self);
  FCardLabel.Align := TAlign.alClient;
  FCardLabel.Alignment := TAlignment.taCenter;
  FCardLabel.Caption := Text;
  FCardLabel.Font.Color := clWhite;
  FCardLabel.Font.Size := FontSize;
  FCardLabel.Parent := Self;
  FCardLabel.Transparent := True;
  FCardLabel.WordWrap := True;
  FCardLabel.AlignWithMargins := True;
end;

procedure TCard.UpdateStatus(Color: TColor; const Text: string);
begin
  Self.Color := Color;
  FCardLabel.Caption := Text;
  Self.Refresh;
end;

end.
