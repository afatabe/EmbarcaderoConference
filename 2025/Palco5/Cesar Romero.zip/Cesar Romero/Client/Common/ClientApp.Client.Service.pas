unit ClientApp.Client.Service;

interface

uses
  System.Classes, System.SysUtils,
  ClientApp.Result, ClientApp.UserModel, ClientApp.Pipeline.Interfaces;

type
  TClientService = class(TInterfacedObject, IClientService)
  private
    FSimulateLatency: Boolean;
  public
    constructor Create(SimulateLatency: Boolean);
    function DownloadUserData(Id: Integer): TDownloadResult;
    function SerializeUserData(const JsonResult: TDownloadResult): TUserModelResult;
  public
    class var SimularLatencia: Boolean;
  end;

implementation

uses
  System.JSON, System.Net.HttpClient;

const
  UserApiUrl = 'http://localhost:8080/user/';

  { TClientService }

constructor TClientService.Create(SimulateLatency: Boolean);
begin
  inherited Create;
  FSimulateLatency := SimulateLatency;
end;

function TClientService.DownloadUserData(Id: Integer): TDownloadResult;
var
  HttpClient: THTTPClient;
  Response: IHTTPResponse;
  Url: string;
begin
  try
    if FSimulateLatency then
      // Simula lat�ncia de rede
      TThread.Sleep(250 + Random(2000));

    Url := UserApiUrl + Id.ToString;
    HttpClient := THTTPClient.Create;
    try
      Response := HttpClient.Get(Url);
      if Response.StatusCode = 200 then
        Result := TDownloadResult.Success(Response.ContentAsString)
      else
        raise Exception.CreateFmt('HTTP Error %d', [Response.StatusCode]);
    finally
      HttpClient.Free;
    end;
  except
    on E: Exception do
      Result := TDownloadResult.Failure(AcquireExceptionObject as Exception);
  end;
end;

function TClientService.SerializeUserData(const JsonResult: TDownloadResult)
  : TUserModelResult;
var
  JsonObj: TJSONObject;
  UserModel: TUserModel;
begin
  if not JsonResult.IsSuccess then
  begin
    Result := TUserModelResult.Failure(JsonResult.Error);
    Exit;
  end;

  try
    if FSimulateLatency then
    begin
      // Simula um pequeno tempo de processamento
      TThread.Sleep(50 + Random(500));
    end;

    JsonObj := TJSONObject.ParseJSONValue(JsonResult.Value) as TJSONObject;
    try
      UserModel := TUserModel.Create(
        JsonObj.GetValue<Integer>('id'),
        JsonObj.GetValue<string>('name'),
        JsonObj.GetValue<string>('source')
      );
      Result := TUserModelResult.Success(UserModel);
    finally
      JsonObj.Free;
    end;
  except
    on E: Exception do
      Result := TUserModelResult.Failure(E);
  end;
end;

end.
