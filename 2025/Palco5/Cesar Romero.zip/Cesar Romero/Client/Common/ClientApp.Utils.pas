unit ClientApp.Utils;

interface

uses
  System.DateUtils,
  System.Math,
  System.SysUtils,
  Vcl.Controls,
  Vcl.Graphics,
  Winapi.Messages,
  Winapi.Windows;

function CalculateColorShade(const BaseColor: TColor;
  CurrentIndex, TotalCount: Integer): TColor;

function CalculateColorShadeByTime(const BaseColor: TColor;
  CurrentIndex, TotalCount: Integer; const StartTime: TDateTime): TColor;

procedure ProcessControlMessages(Control: TWinControl);

implementation

function CalculateColorShade(const BaseColor: TColor;
  CurrentIndex, TotalCount: Integer): TColor;
const
  DarkFactor = 0.5;
var
  BaseRGB: TColor;
  R, G, B: Byte;
begin
  if (TotalCount <= 1) or (CurrentIndex <= 0) then
  begin
    Result := BaseColor;
    Exit;
  end;

  BaseRGB := ColorToRGB(BaseColor);
  R := GetRValue(BaseRGB);
  G := GetGValue(BaseRGB);
  B := GetBValue(BaseRGB);

  var Ratio := CurrentIndex / TotalCount;
  var Brightness := DarkFactor + (1 - DarkFactor) * Ratio;

  R := Trunc(Min(R * Brightness, 255));
  G := Trunc(Min(G * Brightness, 255));
  B := Trunc(Min(B * Brightness, 255));

  Result := RGB(R, G, B);
end;

function CalculateColorShadeByTime(const BaseColor: TColor;
  CurrentIndex, TotalCount: Integer; const StartTime: TDateTime): TColor;
begin
  var ElapsedMS := MillisecondsBetween(Now, StartTime);
  var Shade := ElapsedMS div 750;
  Result := CalculateColorShade(BaseColor, CurrentIndex + Shade,
    TotalCount + Shade);
end;

procedure ProcessControlMessages(Control: TWinControl);
var
  Msg: TMsg;
begin
  while PeekMessage(Msg, Control.Handle, 0, 0, PM_REMOVE) do
  begin
    case Msg.message of
      WM_LBUTTONDOWN,
      WM_LBUTTONUP,
      WM_LBUTTONDBLCLK,
      WM_RBUTTONDOWN,
      WM_RBUTTONUP,
      WM_MBUTTONDOWN,
      WM_MBUTTONUP,
      WM_KEYDOWN,
      WM_KEYUP,
      WM_CHAR,
      WM_MOUSEMOVE,
      WM_MOUSELEAVE,
      WM_MOUSEHOVER,
      WM_SETFOCUS,
      WM_KILLFOCUS:
      begin
        TranslateMessage(Msg);
        DispatchMessage(Msg);
      end;
    end;
  end;
  Control.Refresh;
end;

end.
