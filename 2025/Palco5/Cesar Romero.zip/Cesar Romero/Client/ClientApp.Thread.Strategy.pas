unit ClientApp.Thread.Strategy;

interface

uses
  System.Classes,
  System.SyncObjs,
  System.SysUtils,
  ClientApp.Pipeline.Interfaces;

type
  TThreadStrategy = class(TPipelineStrategy)
  private
    FOrchestrator: TThread;
  public
    procedure Execute(const Ids: TArray<Integer>;
      const StatusCallback: TStatusUpdateCallback;
      const CompletionCallback: TCompletionEvent); override;
    procedure Cancel; override;
  end;

implementation

uses
  ClientApp.Thread.Worker;

procedure TThreadStrategy.Execute(const Ids: TArray<Integer>;
  const StatusCallback: TStatusUpdateCallback;
  const CompletionCallback: TCompletionEvent);
var
  TotalWorkers: Integer;
begin
  TotalWorkers := Length(Ids);
  FOrchestrator := TThread.CreateAnonymousThread(
    procedure
    var
      Workers: TArray<TThread>;
    begin
      try
        SetLength(Workers, TotalWorkers);
        for var i := 0 to High(Ids) do
        begin
          // Cria a nova TWorkerThread e inicia imediatamente
          Workers[i] := TWorkerThread.Create(Self, Ids[i],
            FClientService, StatusCallback);
        end;

        try
          // Espera todas as threads de trabalho terminarem
          for var Thread in Workers do
          begin
            if FOrchestrator.CheckTerminated then
              Thread.Terminate
            else
              Thread.WaitFor;
          end;

          // Notifica a conclus�o geral na UI
          if Assigned(CompletionCallback) then
            TThread.Synchronize(nil, CompletionCallback);
        finally
          for var Thread in Workers do
          begin
            Thread.WaitFor;
            Thread.Free;
          end;

          SetLength(Workers, 0);
        end;
      except on
        E: Exception do
        begin
          FOrchestrator.Free;
        end;
      end;
    end);
  // A thread monitora pode se auto-liberar
  FOrchestrator.FreeOnTerminate := True;
  FOrchestrator.Start;
end;

procedure TThreadStrategy.Cancel;
begin
  if Assigned(FOrchestrator) then
  begin
    FOrchestrator.Terminate;
  end;
  inherited Cancel;
end;

end.
