object MainForm: TMainForm
  Left = 0
  Top = 0
  Caption = 
    'Embarcadero Conference 2025 - Da Complexidade do TThread '#224' Maest' +
    'ria da PPL'
  ClientHeight = 511
  ClientWidth = 884
  Color = clBtnFace
  Constraints.MinHeight = 550
  Constraints.MinWidth = 900
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -12
  Font.Name = 'Segoe UI'
  Font.Style = []
  Position = poScreenCenter
  RoundedCorners = rcOn
  WindowState = wsMaximized
  OnCreate = FormCreate
  OnDestroy = FormDestroy
  TextHeight = 15
  object ButtonsPanel: TPanel
    Left = 0
    Top = 0
    Width = 884
    Height = 41
    Align = alTop
    BevelOuter = bvNone
    TabOrder = 0
    object QuantidadeLabel: TLabel
      Left = 579
      Top = 13
      Width = 62
      Height = 15
      Caption = 'Quantidade'
    end
    object IniciarTThreadButton: TButton
      AlignWithMargins = True
      Left = 5
      Top = 9
      Width = 150
      Height = 25
      Caption = 'Iniciar Thread'
      TabOrder = 0
      OnClick = IniciarTThreadButtonClick
    end
    object CancelarButton: TButton
      Left = 473
      Top = 9
      Width = 100
      Height = 25
      Caption = 'CancelarButton'
      TabOrder = 3
      OnClick = CancelarButtonClick
    end
    object QuantidadeSpinEdit: TSpinEdit
      Left = 647
      Top = 10
      Width = 51
      Height = 24
      MaxValue = 0
      MinValue = 0
      TabOrder = 4
      Value = 16
    end
    object IniciarPPLButton: TButton
      AlignWithMargins = True
      Left = 161
      Top = 9
      Width = 150
      Height = 25
      Caption = 'Iniciar Task'
      TabOrder = 1
      OnClick = IniciarPPLButtonClick
    end
    object IniciarParallelPPLButton: TButton
      AlignWithMargins = True
      Left = 317
      Top = 9
      Width = 150
      Height = 25
      Caption = 'Iniciar ParallelFor'
      TabOrder = 2
      OnClick = IniciarParallelPPLButtonClick
    end
    object SimularLatenciaCheckBox: TCheckBox
      Left = 704
      Top = 13
      Width = 114
      Height = 17
      Caption = 'Simular Lat'#234'ncia'
      Checked = True
      State = cbChecked
      TabOrder = 5
    end
    object FixCardFontCheckBox: TCheckBox
      Left = 824
      Top = 13
      Width = 169
      Height = 17
      Caption = 'Card Fonts Auto Size'
      TabOrder = 6
    end
  end
  object ScrollBox: TScrollBox
    AlignWithMargins = True
    Left = 3
    Top = 44
    Width = 878
    Height = 433
    HorzScrollBar.Smooth = True
    HorzScrollBar.Visible = False
    VertScrollBar.Smooth = True
    Align = alClient
    BevelInner = bvLowered
    BevelOuter = bvRaised
    TabOrder = 1
    UseWheelForScrolling = True
    object FlowLayoutResults: TFlowPanel
      Left = 0
      Top = 0
      Width = 874
      Height = 429
      Align = alClient
      BevelOuter = bvNone
      DoubleBuffered = True
      FlowStyle = fsLeftRightBottomTop
      FullRepaint = False
      ParentDoubleBuffered = False
      TabOrder = 0
    end
  end
  object ProgressBar: TProgressBar
    AlignWithMargins = True
    Left = 3
    Top = 483
    Width = 878
    Height = 25
    Align = alBottom
    TabOrder = 2
  end
end
