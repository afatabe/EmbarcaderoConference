unit ClientApp.Thread.Worker;

interface

uses
  System.Classes, System.SysUtils,
  ClientApp.Pipeline.Interfaces, ClientApp.Result, ClientApp.UserModel;

type
  TWorkerThread = class(TThread)
  private
    FId: Integer;
    FClientService: IClientService;
    FPipeline: IPipelineStrategy;
    FStatusCallback: TStatusUpdateCallback;
  protected
    function CheckTerminated(Data: TObject = nil): Boolean;
    procedure Execute; override;
    procedure NotifyStatus(Id: Integer; Status: TPipelineStatus; Data: TObject = nil);
  public
    constructor Create(const Pipeline: IPipelineStrategy; Id: Integer; const ClientService: IClientService;
      const StatusCallback: TStatusUpdateCallback);
  end;

implementation

uses System.Threading;

function TWorkerThread.CheckTerminated(Data: TObject = nil): Boolean;
begin
  Result := Terminated;
  if Result then
  begin
    NotifyStatus(FId, TPipelineStatus.Cancelled, Data);
  end;
end;

constructor TWorkerThread.Create(const Pipeline: IPipelineStrategy; Id: Integer;
  const ClientService: IClientService;
  const StatusCallback: TStatusUpdateCallback);
begin
  inherited Create(False);
  FreeOnTerminate := False;
  FId := Id;
  FClientService := ClientService;
  FPipeline := Pipeline;
  FStatusCallback := StatusCallback;
  NameThreadForDebugging('TWorkerThread_' + FId.ToString);
end;

procedure TWorkerThread.Execute;
var
  DownloadResult: TDownloadResult;
  FinalResult: TUserModelResult;
begin
  // A l�gica da UnitOfWork agora vive aqui.
  // Como FId, FStatusCallback, etc, s�o campos do objeto, eles
  // podem ser capturados com seguran�a pelos m�todos an�nimos.
  try
    if CheckTerminated then
      Exit;

    NotifyStatus(FId, TPipelineStatus.Downloading);
    DownloadResult := FClientService.DownloadUserData(FId);

    if DownloadResult.IsSuccess then
    begin
      NotifyStatus(FId, TPipelineStatus.Serializing);
      if not CheckTerminated then
        FinalResult := FClientService.SerializeUserData(DownloadResult);
    end
    else
      FinalResult := TUserModelResult.Failure(DownloadResult.Error);

    if CheckTerminated then
    begin
      FinalResult.Finalize;
      Exit;
    end;

    if FinalResult.IsSuccess then
      NotifyStatus(FId, TPipelineStatus.Success, FinalResult.Value)
    else
      NotifyStatus(FId, TPipelineStatus.Error, FinalResult.Error);
  except
    on E: EOperationCancelled do
    begin
      FinalResult.Finalize;
      NotifyStatus(FId, TPipelineStatus.Cancelled, AcquireExceptionObject);
    end;

    on E: Exception do
    begin
      FinalResult.Finalize;
      NotifyStatus(FId, TPipelineStatus.Error, AcquireExceptionObject);
    end;
  end;
end;

procedure TWorkerThread.NotifyStatus(Id: Integer; Status: TPipelineStatus; Data: TObject);
begin
  if Assigned(FPipeline) and Assigned(FStatusCallback) then
  begin
    FPipeline.NotifyStatus(FStatusCallback, Id, Status, Data);
  end;
end;

end.
