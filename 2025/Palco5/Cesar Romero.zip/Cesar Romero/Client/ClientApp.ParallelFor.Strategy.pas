unit ClientApp.ParallelFor.Strategy;

interface

uses
  System.Classes,
  System.SyncObjs,
  System.SysUtils,
  System.Threading,
  ClientApp.Pipeline.Interfaces;

type
  TParallelForStrategy = class(TPipelineStrategy)
  private
    FParentTask: ITask;
  public
    procedure Execute(const Ids: TArray<Integer>;
      const StatusCallback: TStatusUpdateCallback;
      const CompletionCallback: TCompletionEvent); override;

    function CheckCancelled(Id: Integer; Token: ITask; const StatusCallback:
      TStatusUpdateCallback; LoopState: TParallel.TLoopState): Boolean;
    procedure Cancel; override;
  end;

implementation

uses
  ClientApp.Result,
  ClientApp.UserModel;

function TParallelForStrategy.CheckCancelled(Id: Integer; Token: ITask;
  const StatusCallback: TStatusUpdateCallback; LoopState: TParallel.TLoopState): Boolean;
begin
  Result := Token.Status = TTaskStatus.Canceled;
  if Result then
  begin
    TThread.Synchronize(nil,
      procedure
      begin
        StatusCallback(Id, TPipelineStatus.Cancelled, nil);
      end);
    LoopState.Stop;
  end;
end;

procedure TParallelForStrategy.Execute(const Ids: TArray<Integer>;
  const StatusCallback: TStatusUpdateCallback;
  const CompletionCallback: TCompletionEvent);
begin
  FParentTask := TTask.Run(
    procedure
    var
      LoopResult: TParallel.TLoopResult;
      Token: ITask;
    begin
      try
        Token := TTask.CurrentTask;
        LoopResult := TParallel.For(0, High(Ids),
          procedure(i: Integer; LoopState: TParallel.TLoopState)
          var
            DownloadResult: TDownloadResult;
            FinalResult: TUserModelResult;
            id: Integer;
          begin
            id := Ids[i];
            try
              if CheckCancelled(Id, Token, StatusCallback, LoopState) then
                Exit;

              NotifyStatus(StatusCallback,id, TPipelineStatus.Downloading);
              DownloadResult := FClientService.DownloadUserData(id);
              if DownloadResult.IsSuccess then
              begin
                NotifyStatus(StatusCallback,id, TPipelineStatus.Serializing);

                if CheckCancelled(Id, Token, StatusCallback, LoopState) then
                  Exit;

                FinalResult := FClientService.SerializeUserData(DownloadResult);
              end
              else
                FinalResult := TUserModelResult.Failure(DownloadResult.Error);

              if CheckCancelled(Id, Token, StatusCallback, LoopState) then
              begin
                FinalResult.Finalize;
                Exit;
              end;

              if FinalResult.IsSuccess then
                NotifyStatus(StatusCallback,id, TPipelineStatus.Success,
                  FinalResult.Value)
              else
                NotifyStatus(StatusCallback, id, TPipelineStatus.Error,
                  FinalResult.Error);
            except
              on E: EOperationCancelled do
              begin
                FinalResult.Finalize;
                NotifyStatus(StatusCallback, Id, TPipelineStatus.Cancelled,
                  AcquireExceptionObject);
              end;

              on E: Exception do
              begin
                FinalResult.Finalize;
                NotifyStatus(StatusCallback, Id, TPipelineStatus.Error,
                  AcquireExceptionObject);
              end;
            end;
          end);

        Token := nil;
      finally
        if Assigned(CompletionCallback) then
          TThread.Synchronize(nil, CompletionCallback);
      end;
    end);
end;

procedure TParallelForStrategy.Cancel;
begin
  inherited Cancel;
  FParentTask.Cancel;
end;

end.
