program ClientApp;

uses
  Vcl.Forms,
  Vcl.Themes,
  Vcl.Styles,
  ClientApp.MainForm in 'ClientApp.MainForm.pas' {MainForm},
  ClientApp.UserModel in 'Common\ClientApp.UserModel.pas',
  ClientApp.Result in 'Common\ClientApp.Result.pas',
  ClientApp.Client.Service in 'Common\ClientApp.Client.Service.pas',
  ClientApp.Pipeline.Interfaces in 'Common\ClientApp.Pipeline.Interfaces.pas',
  ClientApp.Thread.Strategy in 'ClientApp.Thread.Strategy.pas',
  ClientApp.Task.Strategy in 'ClientApp.Task.Strategy.pas',
  ClientApp.Utils in 'Common\ClientApp.Utils.pas',
  ClientApp.ParallelFor.Strategy in 'ClientApp.ParallelFor.Strategy.pas',
  ClientApp.Thread.Worker in 'ClientApp.Thread.Worker.pas',
  ClientApp.Card.Widget in 'Common\ClientApp.Card.Widget.pas';

{$R *.res}

begin
  Application.Initialize;
  Application.MainFormOnTaskbar := True;
  TStyleManager.TrySetStyle('Windows11 Modern Dark');
  Application.CreateForm(TMainForm, MainForm);
  Application.Run;
end.
