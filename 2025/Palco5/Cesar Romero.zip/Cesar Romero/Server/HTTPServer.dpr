program HTTPServer;
{$APPTYPE CONSOLE}

uses
  FastMM5,
  System.SysUtils,
  Web.WebReq,
  HTTPServer.WebModule in 'HTTPServer.WebModule.pas' {HttpWebModule: TWebModule},
  HTTPServer.Consts in 'HTTPServer.Consts.pas',
  HTTPServer.Repository in 'HTTPServer.Repository.pas',
  HTTPServer.Startup in 'HTTPServer.Startup.pas';

{$R *.res}

begin
  ReportMemoryLeaksOnShutdown := True;
  try
    if WebRequestHandler <> nil then
      WebRequestHandler.WebModuleClass := WebModuleClass;
    THTTPServerStartup.RunServer(8080);
  except
    on E: Exception do
      Writeln(E.ClassName, ': ', E.Message);
  end
end.
