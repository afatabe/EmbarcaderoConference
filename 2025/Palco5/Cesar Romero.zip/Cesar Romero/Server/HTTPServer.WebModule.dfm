object HttpWebModule: THttpWebModule
  Actions = <
    item
      Default = True
      Name = 'DefaultHandlerAction'
      PathInfo = '/'
      OnAction = WebModuleDefaultHandlerAction
    end
    item
      MethodType = mtGet
      Name = 'UserAction'
      PathInfo = '/user/*'
      OnAction = HttpWebModuleUserAction
    end>
  BeforeDispatch = WebModuleBeforeDispatch
  Height = 230
  Width = 415
end
