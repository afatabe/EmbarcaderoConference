unit HTTPServer.Startup;

interface

uses
  System.SysUtils,
  IPPeerServer,
  IPPeerAPI,
  IdHTTPWebBrokerBridge,
  Web.WebBroker;

type
  THTTPServerStartup = class
  private
    class function BindPort(Port: Integer): Boolean; static;
    class function CheckPort(Port: Integer): Integer; static;
    class procedure SetPort(const Server: TIdHTTPWebBrokerBridge; Port: String); static;
    class procedure StartServer(const Server: TIdHTTPWebBrokerBridge); static;
    class procedure StopServer(const Server: TIdHTTPWebBrokerBridge); static;
    class procedure WriteCommands; static;
    class procedure WriteStatus(const Server: TIdHTTPWebBrokerBridge); static;
  public
    class procedure RunServer(Port: Integer; AutoStart: Boolean = True); static;
  end;

implementation

uses
  HTTPServer.Consts;

class function THTTPServerStartup.BindPort(Port: Integer): Boolean;
var
  TestServer: IIPTestServer;
begin
  Result := True;
  try
    TestServer := PeerFactory.CreatePeer('', IIPTestServer) as IIPTestServer;
    TestServer.TestOpenPort(Port, nil);
  except
    Result := False;
  end;
end;

class function THTTPServerStartup.CheckPort(Port: Integer): Integer;
begin
  if BindPort(Port) then
    Result := Port
  else
    Result := 0;
end;

class procedure THTTPServerStartup.RunServer(Port: Integer; AutoStart: Boolean = True);
var
  Response: string;
  Server: TIdHTTPWebBrokerBridge;
begin
  WriteCommands;
  Server := TIdHTTPWebBrokerBridge.Create(nil);
  try
    Server.DefaultPort := Port;

    if AutoStart then
    begin
      StartServer(Server);
    end;

    while True do
    begin
      Readln(Response);
      Response := LowerCase(Response);
      if Response.StartsWith(cCommandSetPort) then
        SetPort(Server, Response)
      else if sametext(Response, cCommandStart) then
        StartServer(Server)
      else if sametext(Response, cCommandStatus) then
        WriteStatus(Server)
      else if sametext(Response, cCommandStop) then
        StopServer(Server)
      else if sametext(Response, cCommandHelp) then
        WriteCommands
      else if sametext(Response, cCommandExit) then
        if Server.Active then
        begin
          StopServer(Server);
          break
        end
        else
          break
      else
      begin
        Writeln(sInvalidCommand);
        Write(cArrow);
      end;
    end;
  finally
    Server.Free;
  end;
end;

class procedure THTTPServerStartup.SetPort(const Server:
  TIdHTTPWebBrokerBridge; Port: String);
begin
  if not Server.Active then
  begin
    Port := Port.Replace(cCommandSetPort, '').Trim;
    if CheckPort(Port.ToInteger) > 0 then
    begin
      Server.DefaultPort := Port.ToInteger;
      Writeln(Format(sPortSet, [Port]));
    end
    else
      Writeln(Format(sPortInUse, [Port]));
  end
  else
    Writeln(sServerRunning);
  Write(cArrow);
end;

class procedure THTTPServerStartup.StartServer(const Server:
  TIdHTTPWebBrokerBridge);
begin
  if not Server.Active then
  begin
    if CheckPort(Server.DefaultPort) > 0 then
    begin
      Writeln(Format(sStartingServer, [Server.DefaultPort]));
      Server.Bindings.Clear;
      Server.Active := True;
    end
    else
      Writeln(Format(sPortInUse, [Server.DefaultPort.ToString]));
  end
  else
    Writeln(sServerRunning);
  Write(cArrow);
end;

class procedure THTTPServerStartup.StopServer(const Server:
  TIdHTTPWebBrokerBridge);
begin
  if Server.Active then
  begin
    Writeln(sStoppingServer);
    Server.Active := False;
    Server.Bindings.Clear;
    Writeln(sServerStopped);
  end
  else
    Writeln(sServerNotRunning);
  Write(cArrow);
end;

class procedure THTTPServerStartup.WriteCommands;
begin
  Writeln(sCommands);
  Write(cArrow);
end;

class procedure THTTPServerStartup.WriteStatus(const Server:
  TIdHTTPWebBrokerBridge);
begin
  Writeln(sIndyVersion + Server.SessionList.Version);
  Writeln(sActive + Server.Active.ToString(TUseBoolStrs.True));
  Writeln(sPort + Server.DefaultPort.ToString);
  Writeln(sSessionID + Server.SessionIDCookieName);
  Write(cArrow);
end;

end.
