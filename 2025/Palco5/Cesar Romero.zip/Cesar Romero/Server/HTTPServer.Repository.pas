﻿unit HTTPServer.Repository;

interface

uses
  System.Generics.Collections,
  System.JSON,
  System.SysUtils;

type
  TUserRepository = class
  private
    class var FUserCache: TDictionary<Integer, string>;
    class procedure EnsureCache; static;
    class constructor Create;
    class destructor Destroy;
  public
    class function GetUsers: string; static;
    class function GetUserById(const Id: Integer): string; static;
  end;

const
  // JSON com a lista completa e atualizada de MVPs da Embarcadero.
  // Fonte: Coleta manual do diretório em Setembro de 2025.
  USERS_DATA = '[' +
    '{"id":1,"name":"Abdelali Zekiri","source":"France"},' +
    '{"id":2,"name":"Abdullah ILGAZ","source":"Turkey"},' +
    '{"id":3,"name":"Adriano Santos","source":"São Paulo, Brazil"},' +
    '{"id":4,"name":"Ahmed Sayed","source":"Al Qahira, Egypt"},' +
    '{"id":5,"name":"Ahmet Nuri DENİZ","source":"İstanbul, Turkey"},' +
    '{"id":6,"name":"Alan Fletcher","source":"Bothell, WA, United States"},' +
    '{"id":7,"name":"Alan Glei Gomes da Silva","source":"Natal-RN, Brazil"},' +
    '{"id":8,"name":"Alessandro Porto Medeiros","source":"Rio de Janeiro, Brazil"},' +
    '{"id":9,"name":"Alexander Bozhko","source":"Pesochin Kharkov rgn., Ukraine"},' +
    '{"id":10,"name":"Ali Dehbansiahkarbon","source":"Germany"},' +
    '{"id":11,"name":"Alister Christie","source":"Wellington, New Zealand"},' +
    '{"id":12,"name":"Allen Bauer","source":"United States"},' +
    '{"id":13,"name":"Allen Drennan","source":"California, United States"},' +
    '{"id":14,"name":"Anders Ohlsson","source":"Scotts Valley, CA, United States"},' +
    '{"id":15,"name":"André Luis Celestino","source":"Paraná, Brazil"},' +
    '{"id":16,"name":"Andrea Magni","source":"Milan, Italy"},' +
    '{"id":17,"name":"Andreas Rejbrand","source":"Östergötlands län, Sweden"},' +
    '{"id":18,"name":"Andrey Efimov","source":"Moscow, Russian Federation"},' +
    '{"id":19,"name":"Ansgar Becker","source":"Neuenkirchen, Nordrhein-Westfalen, Germany"},' +
    '{"id":20,"name":"Armando Corrêa Henrique Neto","source":"Santa Catarina, Brazil"},' +
    '{"id":21,"name":"Arnaud Bouchez","source":"Europe, France"},' +
    '{"id":22,"name":"Bernd Ua","source":"Hannover, Niedersachsen, Germany"},' +
    '{"id":23,"name":"Bertie Buitendag","source":"Pretoria, South Africa"},' +
    '{"id":24,"name":"Bob Calco","source":"Florida, United States"},' +
    '{"id":25,"name":"Bob Swart","source":"Helmond, Netherlands"},' +
    '{"id":26,"name":"Boian Mitov","source":"California, United States"},' +
    '{"id":27,"name":"Brandon Long","source":"Eastern Cape, South Africa"},' +
    '{"id":28,"name":"Brian Long","source":"Aylesbury, United Kingdom"},' +
    '{"id":29,"name":"Bruce McGee","source":"Ontario, Canada"},' +
    '{"id":30,"name":"Bruno Fierens","source":"West Flanders, Belgium"},' +
    '{"id":31,"name":"Bruno Sonnino","source":"São Paulo, Canada"},' +
    '{"id":32,"name":"Carlos Alberto Reyes Garcia","source":"San marcos/San Salvador, El Salvador"},' +
    '{"id":33,"name":"Carlos Henrique Agnes","source":"Porto Alegre - Rio Grande do Sul, Brazil"},' +
    '{"id":34,"name":"Cary Jensen","source":"Houston, TX, United States"},' +
    '{"id":35,"name":"César Augusto Santiago Cardoso","source":"Paraná, Brazil"},' +
    '{"id":36,"name":"Cesar Romero","source":"Blumenau, Brazil"},' +
    '{"id":37,"name":"Chee-Wee Chua","source":"Singapore"},' +
    '{"id":38,"name":"Christina Louise Warne","source":"Leicester, United Kingdom"},' +
    '{"id":39,"name":"Christoph Schneider","source":"Zug, Switzerland"},' +
    '{"id":40,"name":"Conrad Vermeulen","source":"Buckinghamshire, United Kingdom"},' +
    '{"id":41,"name":"Craig Chapman","source":"Idaho, United States"},' +
    '{"id":42,"name":"Dalija Prasnikar","source":"Zagreb, Croatia"},' +
    '{"id":43,"name":"Daniel Fernandes Rodrigues","source":"São Paulo, Brazil"},' +
    '{"id":44,"name":"Daniele Spinetti","source":"Rome, Italy"},' +
    '{"id":45,"name":"Daniele Teti","source":"Rome, Italy"},' +
    '{"id":46,"name":"Danny Wind","source":"Netherlands"},' +
    '{"id":47,"name":"Darian Miller","source":"United States"},' +
    '{"id":48,"name":"David Clegg","source":"Auckland, New Zealand"},' +
    '{"id":49,"name":"David Cornelius","source":"Oregon, United States"},' +
    '{"id":50,"name":"David Hoyle","source":"Warwickshire, Rugby, United Kingdom"},' +
    '{"id":51,"name":"David Intersimone","source":"California, United States"},' +
    '{"id":52,"name":"David Millington","source":"Tallinn, Estonia"},' +
    '{"id":53,"name":"David Nottage","source":"Australia"},' +
    '{"id":54,"name":"Dennies Chang","source":"Taiwan, Taiwan"},' +
    '{"id":55,"name":"Detlef D. Overbeek","source":"IJsselstein (Utrecht), Netherlands"},' +
    '{"id":56,"name":"Didier Cabalé","source":"St-Gaudens, France"},' +
    '{"id":57,"name":"Dion Mai","source":"Porto Alegre, Brazil"},' +
    '{"id":58,"name":"Dmitrii Kuzmenko","source":"Moscow, Russian Federation"},' +
    '{"id":59,"name":"Dr. Holger Flick","source":"Florida, United States"},' +
    '{"id":60,"name":"Eliseo González Nieto","source":"Ciudad de Mexico, Mexico"},' +
    '{"id":61,"name":"Emilio Pérez","source":"Sevilla, Spain"},' +
    '{"id":62,"name":"Erik van Bilsen","source":"California, United States"},' +
    '{"id":63,"name":"Evgeny Parkhomenko","source":"Moscow, Russian Federation"},' +
    '{"id":64,"name":"Fabrizio Bitti","source":"Roma (RM), Italy"},' +
    '{"id":65,"name":"Felix Colibri","source":"Paris, France"},' +
    '{"id":66,"name":"Filip Lagrou","source":"Lommel, Belgium"},' +
    '{"id":67,"name":"FMX Express","source":"United States"},' +
    '{"id":68,"name":"Francisco Muro","source":"Lima, Peru"},' +
    '{"id":69,"name":"Francois Piette","source":"Liege, Belgium"},' +
    '{"id":70,"name":"Frank Lauter","source":"Stolberg, Nordrhein-Westfalien, Germany"},' +
    '{"id":71,"name":"Gabriel de Oliveira Silva","source":"São paulo, Brazil"},' +
    '{"id":72,"name":"George De Luca","source":"Porto, Portugal"},' +
    '{"id":73,"name":"Gerhard Stoltz","source":"Gauteng, South Africa"},' +
    '{"id":74,"name":"Germán Estévez -Neftalí-","source":"Barcelona, Spain"},' +
    '{"id":75,"name":"Glenn Dufke","source":"Denmark"},' +
    '{"id":76,"name":"Greg Reese","source":"Oxford, Ohio, United States"},' +
    '{"id":77,"name":"Gregory Bersegeay","source":"Nouvelle Aquitaine, France"},' +
    '{"id":78,"name":"Gustavo Enriquez","source":"Colombia"},' +
    '{"id":79,"name":"Gustavo Mena Barreto","source":"Rio Grande do Sul, Brazil"},' +
    '{"id":80,"name":"Gustavo Meneses Carreno Silva","source":"Lancashire, United Kingdom"},' +
    '{"id":81,"name":"Hans Kremer","source":"Zuid Holland, Netherlands"},' +
    '{"id":82,"name":"Harry Stahl","source":"Bonn, Nordrhein-Westfalen, Germany"},' +
    '{"id":83,"name":"Heber Stein Mazutti","source":"Sao Paulo, Brazil"},' +
    '{"id":84,"name":"Hicham Laichi","source":"Bou-saada, Algeria"},' +
    '{"id":85,"name":"Humphrey Kim","source":"Seoul, Korea, Republic of"},' +
    '{"id":86,"name":"Ian Barker","source":"Texas, United States"},' +
    '{"id":87,"name":"Isaque Pinheiro","source":"Brazil, Brazil"},' +
    '{"id":88,"name":"Iwan Cahyadi Sugeng","source":"Indonesia"},' +
    '{"id":89,"name":"J. Peter Mugaas","source":"United States"},' +
    '{"id":90,"name":"Jan Goyvaerts","source":"Thailand"},' +
    '{"id":91,"name":"Jaques Rodrigues do Nascimento Júnior","source":"SC, Brazil"},' +
    '{"id":92,"name":"Jarrod Davis","source":"Florida, United States"},' +
    '{"id":93,"name":"Javier Gutiérrez Chamorro","source":"Barcelona, Spain"},' +
    '{"id":94,"name":"Javier Pareja","source":"Madrid, Spain"},' +
    '{"id":95,"name":"Jeff Overcash","source":"United States"},' +
    '{"id":96,"name":"Jens Fudge","source":"Middelfart, Denmark"},' +
    '{"id":97,"name":"Jhonny Suarez","source":"Cali, Colombia"},' +
    '{"id":98,"name":"John Kaster","source":"California, United States"},' +
    '{"id":99,"name":"Jon-Lennart Aasenden","source":"Tolvsrod, Norway"},' +
    '{"id":100,"name":"Jordan Russell","source":"Texas, United States"},' +
    '{"id":101,"name":"Jorge L. Cangas Bardón","source":"Barcelona, Spain"},' +
    '{"id":102,"name":"José Araújo","source":"Caucaia, Brazil"},' +
    '{"id":103,"name":"Jose Castillo Reyes","source":"Lima, Peru"},' +
    '{"id":104,"name":"José Mário Silva Guedes","source":"Sao Paulo, Brazil"},' +
    '{"id":105,"name":"Juan Antonio Castillo Hernández","source":"Guatemala City, Guatemala"},' +
    '{"id":106,"name":"Juliomar Marchetti","source":"Santa Catarina, Brazil"},' +
    '{"id":107,"name":"Jun Hosokawa","source":"Tokyo, Japan"},' +
    '{"id":108,"name":"Kees de Kraker","source":"Papendrecht, Netherlands"},' +
    '{"id":109,"name":"Kelver Merlotti","source":"Sao Paulo, Brazil"},' +
    '{"id":110,"name":"Kevin Roy Bond","source":"United Kingdom"},' +
    '{"id":111,"name":"Khaled Bouchareb","source":"Algeria, Algeria"},' +
    '{"id":112,"name":"Kivian Emerim","source":"Rio Grande do Sul, Brazil"},' +
    '{"id":113,"name":"Landerson Gomes dos Santos","source":"Itaocara, Brazil"},' +
    '{"id":114,"name":"Larry Hengen","source":"Alberta, Canada"},' +
    '{"id":115,"name":"Laurent Navarro","source":"Toulouse, France"},' +
    '{"id":116,"name":"Leo Singh","source":"Arizona, United States"},' +
    '{"id":117,"name":"Loy Anderson","source":"Texas, United States"},' +
    '{"id":118,"name":"Luca Zoller","source":"Milan, Italy"},' +
    '{"id":119,"name":"Ludo Stroetenga","source":"Leeuwarden, Netherlands"},' +
    '{"id":120,"name":"Luis Felipe González Torres","source":"Caracas, Venezuela, Bolivarian Republic of"},' +
    '{"id":121,"name":"Malcolm Groves","source":"New South Wales, Australia"},' +
    '{"id":122,"name":"Marcelo Varela de Souza","source":"Natal/RN, Brazil"},' +
    '{"id":123,"name":"Marco Antonio Santin Torres","source":"Zitacuaro, Mexico"},' +
    '{"id":124,"name":"Marco Geuze","source":"Netherlands"},' +
    '{"id":125,"name":"Marcos Antonio Moreira","source":"Minas Gerais, Brazil"},' +
    '{"id":126,"name":"Marion Candau","source":"Bordeaux, France"},' +
    '{"id":127,"name":"Markus Humm","source":"Baden-Württemberg, Germany"},' +
    '{"id":128,"name":"Martijn Laan","source":"Noord-Holland, Netherlands"},' +
    '{"id":129,"name":"Matthew Vesperman","source":"Culpeper, Virginia, United States"},' +
    '{"id":130,"name":"Miguel Angel Moreno","source":"Baja California, Mexico"},' +
    '{"id":131,"name":"Miguel Angel Suarez Rodriguez","source":"Bogota, Colombia"},' +
    '{"id":132,"name":"Moraru Ion Gabriel","source":"Europe, Germany"},' +
    '{"id":133,"name":"Nader Shallabi","source":"Abu Dhabi, United Arab Emirates"},' +
    '{"id":134,"name":"Newton Michel de Oliveira","source":"Canoas, Brazil"},' +
    '{"id":135,"name":"Nick Hodges","source":"Philadelphia, United States"},' +
    '{"id":136,"name":"Nirav Kaku","source":"Mumbai, India"},' +
    '{"id":137,"name":"Olaf Monien","source":"Hadamar, Hessen, Germany"},' +
    '{"id":138,"name":"Paolo Rossi","source":"Piacenza, Italy"},' +
    '{"id":139,"name":"Patrick Prémartin","source":"Orléans, France"},' +
    '{"id":140,"name":"Paul Toth","source":"Paris, France"},' +
    '{"id":141,"name":"Peter David Johnson","source":"United Kingdom"},' +
    '{"id":142,"name":"Peter Turtle","source":"Essex, United Kingdom"},' +
    '{"id":143,"name":"Primož Gabrijelčič","source":"Vrhnika, Slovenia"},' +
    '{"id":144,"name":"Quinn Wildman","source":"California, United States"},' +
    '{"id":145,"name":"Radek Cervinka","source":"Doubravy, Czech Republic"},' +
    '{"id":146,"name":"Raouf Rahiche","source":"Mihoub, Algeria"},' +
    '{"id":147,"name":"Ray Konopka","source":"Naperville, IL, United States"},' +
    '{"id":148,"name":"Regys Borges da Silveira","source":"Araxá/MG, Brazil"},' +
    '{"id":149,"name":"Remy Lebeau","source":"California, United States"},' +
    '{"id":150,"name":"Ricardo C. Boaro","source":"Corumbatai, Brazil"},' +
    '{"id":151,"name":"Richard Hatherall","source":"Loughborough, United Kingdom"},' +
    '{"id":152,"name":"Robin Valtot","source":"Lamarche sur Saone, France"},' +
    '{"id":153,"name":"Rodrigo Ruz Vidal","source":"Chile"},' +
    '{"id":154,"name":"Roger Swann","source":"Devon, United Kingdom"},' +
    '{"id":155,"name":"Roman Kassebaum","source":"Bünde, Nordrhein-Westfalen, Germany"},' +
    '{"id":156,"name":"Roman Yankovsky","source":"Saint-Petersburg, Russian Federation"},' +
    '{"id":157,"name":"Ryan Potts","source":"Ohio, United States"},' +
    '{"id":158,"name":"Samer Assil","source":"Ankara, Turkey"},' +
    '{"id":159,"name":"Samuel David","source":"Florianópolis, Brazil"},' +
    '{"id":160,"name":"Sanghyun Oh","source":"Seoul, Korea, Republic of"},' +
    '{"id":161,"name":"Serge Girard","source":"Pays de la Loire, France"},' +
    '{"id":162,"name":"Serge Pilko","source":"Warsaw, Poland"},' +
    '{"id":163,"name":"Shaun Roselt","source":"Bloemfontein, Free-State, South Africa"},' +
    '{"id":164,"name":"Sileide Santana Campos","source":"Brazil"},' +
    '{"id":165,"name":"Stanislav Piter","source":"Auckland, New Zealand"},' +
    '{"id":166,"name":"Stefan Glienke","source":"Soest, Nordrhein-Westfalen, Germany"},' +
    '{"id":167,"name":"Stefan Van As","source":"Zuid-Holland, Netherlands"},' +
    '{"id":168,"name":"Steffen Nyeland","source":"Copenhagen, Denmark"},' +
    '{"id":169,"name":"Stéphane Vander Clock","source":"Alpes Maritimes, France"},' +
    '{"id":170,"name":"Sunil Kumar Arora","source":"New Delhi, India"},' +
    '{"id":171,"name":"SylvainThouvenot","source":"Pays de Loire et Lorraine, France"},' +
    '{"id":172,"name":"Thiago Santiago Santos","source":"São Paulo, Brazil"},' +
    '{"id":173,"name":"Thierry Laborde","source":"France"},' +
    '{"id":174,"name":"Thomas Breitkreuz","source":"Stadthagen, Niedersachsen, Germany"},' +
    '{"id":175,"name":"Thomas „DelphiCoder“ Jourdan","source":"Ireland"},' +
    '{"id":176,"name":"Thulio Bittencourt Gomes","source":"Niteroi, Brazil"},' +
    '{"id":177,"name":"Tim Coates","source":"QLD, Australia"},' +
    '{"id":178,"name":"Tomas Chavez","source":"Guadalajara, Mexico"},' +
    '{"id":179,"name":"Ulf Klarmann","source":"Oldenburg, Niedersachsen, Germany"},' +
    '{"id":180,"name":"Uwe Raabe","source":"Lübbecke, Nordrhein-Westfalen, Germany"},' +
    '{"id":181,"name":"Victory Fernandes","source":"Salvador-Bahia, Brazil"},' +
    '{"id":182,"name":"Vinicius Scandelai Sanchez","source":"Brazil"},' +
    '{"id":183,"name":"Vladimir Timofeev","source":"Moscow, Russian Federation"},' +
    '{"id":184,"name":"Volker Hillmann","source":"Berlin, Germany"},' +
    '{"id":185,"name":"Vsevolod Gromov","source":"Moscow, Russian Federation"},' +
    '{"id":186,"name":"Vsevolod Leonov","source":"Moscow, Russian Federation"},' +
    '{"id":187,"name":"Wagner Landgraf","source":"Brazil"},' +
    '{"id":188,"name":"William Duarte","source":"Rio de Janeiro, Brazil"},' +
    '{"id":189,"name":"William Meyer","source":"Alabama, United States"},' +
    '{"id":190,"name":"Xavier Martinez Garsaball","source":"Andorra la Vella, Andorra"},' +
    '{"id":191,"name":"Yilmaz Yoru","source":"Eskisehir, Turkey"},' +
    '{"id":192,"name":"Žarko Gajić","source":"Osijek, Croatia"},' +
    '{"id":193,"name":"Željko Kovačević","source":"Rugvica, Croatia"},' +
    '{"id":194,"name":"Ziad Allaghi","source":"Libya, United Arab Emirates"}' +
    ']';

implementation

class constructor TUserRepository.Create;
begin
  TUserRepository.FUserCache := nil;
  TUserRepository.EnsureCache;
end;

class destructor TUserRepository.Destroy;
begin
  TUserRepository.FUserCache.Free;
end;

class procedure TUserRepository.EnsureCache;
var
  JsonArray: TJSONArray;
  JsonValue: TJSONValue;
  UserObject: TJSONObject;
  UserId: Integer;
begin
  // Pattern "Singleton" para o cache. Só executa na primeira vez.
  if Assigned(FUserCache) then
    Exit;

  FUserCache := TDictionary<Integer, string>.Create;
  JsonArray := TJSONObject.ParseJSONValue(USERS_DATA) as TJSONArray;
  try
    if not Assigned(JsonArray) then
      Exit;

    for JsonValue in JsonArray do
    begin
      UserObject := JsonValue as TJSONObject;
      UserId := UserObject.GetValue<Integer>('id', -1);
      if UserId > 0 then
        FUserCache.Add(UserId, UserObject.ToString);
    end;
  finally
    JsonArray.Free;
  end;
end;

class function TUserRepository.GetUsers: string;
begin
  Result := USERS_DATA;
end;

class function TUserRepository.GetUserById(const Id: Integer): string;
begin
  if not FUserCache.TryGetValue(Id, Result) then
    // Retorna string vazia se não encontrou no cache
    Result := '';
end;

end.
