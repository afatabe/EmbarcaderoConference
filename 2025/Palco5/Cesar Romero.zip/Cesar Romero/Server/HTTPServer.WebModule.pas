unit HTTPServer.WebModule;

interface

uses
  System.SysUtils,
  System.Classes,
  System.IOUtils,
  Web.HTTPApp;

type
  THttpWebModule = class(TWebModule)
    procedure WebModuleDefaultHandlerAction(Sender: TObject;
      Request: TWebRequest; Response: TWebResponse; var Handled: Boolean);
    procedure HttpWebModuleUserAction(Sender: TObject; Request: TWebRequest;
      Response: TWebResponse; var Handled: Boolean);
    procedure WebModuleBeforeDispatch(Sender: TObject; Request: TWebRequest;
      Response: TWebResponse; var Handled: Boolean);
  end;

var
  WebModuleClass: TComponentClass = THttpWebModule;

implementation

{%CLASSGROUP 'Vcl.Controls.TControl'}

{$R *.dfm}

uses
  HTTPServer.Repository;

procedure THttpWebModule.HttpWebModuleUserAction(Sender: TObject;
  Request: TWebRequest; Response: TWebResponse; var Handled: Boolean);
var
  UserIdStr: string;
  UserId: Integer;
  JsonResult: string;
begin
  Response.ContentType := 'application/json;charset=UTF-8';

  UserIdStr :=  TPath.GetFileName(Request.PathInfo);
  if UserIdStr.IsEmpty or (UserIdStr.ToLower = '/user') then
  begin
    // Nenhum ID foi passado, retorna a lista completa de usu�rios.
    JsonResult := TUserRepository.GetUsers;
  end
  else
  begin
    // Um ID foi passado, tenta converter para inteiro.
    if TryStrToInt(UserIdStr, UserId) then
    begin
      JsonResult := TUserRepository.GetUserById(UserId);
      if JsonResult.IsEmpty then
      begin
        Response.StatusCode := 404; // Not Found
        JsonResult := '{"error": "User not found"}';
      end;
    end
    else
    begin
      Response.StatusCode := 400; // Bad Request
      JsonResult := '{"error": "Invalid user ID"}';
    end;
  end;

  Response.Content := JsonResult;
end;

procedure THttpWebModule.WebModuleBeforeDispatch(Sender: TObject; Request:
  TWebRequest; Response: TWebResponse; var Handled: Boolean);
begin
  if Request.PathInfo = '/user' then
  begin
    Response.SendRedirect('/user/');
  end;
end;

procedure THttpWebModule.WebModuleDefaultHandlerAction(Sender: TObject;
  Request: TWebRequest; Response: TWebResponse; var Handled: Boolean);
begin
  Response.Content :=
    '<html>' +
    '<head><title>Delphi Conference - Demo Server</title></head>' +
    '<body><p>Endpoints dispon�veis:</p><ul><li>/user</li><li>/user/{id}</li></ul></body>' +
    '</html>';
end;

end.
