program LoadingProgressInterface;

uses
  Vcl.Forms,
  uPessoaController in 'Controller\uPessoaController.pas',
  FPrincipal in 'Source\FPrincipal.pas' {frmPrincipal},
  IInterfaces in 'Interfaces\IInterfaces.pas',
  uInterfaces in 'Controller\uInterfaces.pas',
  FProgress in 'Notificacao\Source\FProgress.pas' {frmProgress};

{$R *.res}

begin
  Application.Initialize;
  ReportMemoryLeaksOnShutdown   := True;
  Application.MainFormOnTaskbar := True;
  Application.CreateForm(TfrmPrincipal, frmPrincipal);
  Application.CreateForm(TfrmProgress, frmProgress);
  Application.Run;
end.
