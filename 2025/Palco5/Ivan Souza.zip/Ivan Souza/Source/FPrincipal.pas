unit FPrincipal;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Data.DB, Vcl.StdCtrls, Datasnap.DBClient, Vcl.ExtCtrls,
  Vcl.Grids, Vcl.DBGrids, System.Threading, Vcl.Imaging.jpeg, FireDAC.Stan.Intf, FireDAC.Stan.Option,
  FireDAC.Stan.Error, FireDAC.UI.Intf, FireDAC.Phys.Intf, FireDAC.Stan.Def, FireDAC.Stan.Pool,
  FireDAC.Stan.Async, FireDAC.Phys, FireDAC.VCLUI.Wait, FireDAC.Stan.Param, FireDAC.DatS, FireDAC.DApt.Intf,
  FireDAC.DApt, FireDAC.Comp.DataSet, FireDAC.Comp.Client, Datasnap.Provider,
  uPessoaController, IInterfaces, FireDAC.Phys.FBDef, FireDAC.Comp.UI, FireDAC.Phys.IBBase, FireDAC.Phys.FB;

type
  TfrmPrincipal = class(TForm)
    DBGrid1: TDBGrid;
    Panel1: TPanel;
    btnExportar: TButton;
    FDConn: TFDConnection;
    fdqPessoa: TFDQuery;
    btnInserir: TButton;
    dsPessoa: TDataSource;
    btnLimpar: TButton;
    btnCarregar: TButton;
    Panel2: TPanel;
    btnExportarTask: TButton;
    btnInserirTask: TButton;
    Button3: TButton;
    /// <associates>
    /// </associates>
    btnCarregarTask: TButton;
    Label1: TLabel;
    Label2: TLabel;
    btnSair: TButton;
    fdqPessoaidpessoa: TFDAutoIncField;
    fdqPessoanome: TStringField;
    fdqPessoalogradouro: TStringField;
    fdqPessoaemail: TStringField;
    FDPhysFBDriverLink1: TFDPhysFBDriverLink;
    FDGUIxWaitCursor1: TFDGUIxWaitCursor;
    procedure FormCreate(Sender: TObject);
    procedure btnLimparClick(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure btnCarregarClick(Sender: TObject);
    procedure btnInserirClick(Sender: TObject);
    procedure btnExportarClick(Sender: TObject);
    procedure btnSairClick(Sender: TObject);
    procedure btnExportarTaskClick(Sender: TObject);
  private
    _Controller: TPessoaController;

    { Private declarations }
    procedure carregar;
    procedure exportar(ANotificator : INotificator = nil);
    procedure inserir ;

  public
    { Public declarations }
  end;

var
  frmPrincipal: TfrmPrincipal;


implementation

uses
  FProgress;

{$R *.dfm}

procedure TfrmPrincipal.btnCarregarClick(Sender: TObject);
begin
  carregar;
end;

procedure TfrmPrincipal.btnExportarClick(Sender: TObject);
begin
  exportar;
end;

procedure TfrmPrincipal.btnExportarTaskClick(Sender: TObject);
var
  task : ITask;
begin
  Application.CreateForm(TfrmProgress, frmProgress);
  frmProgress.Show;

  task := TTask.Create(procedure()
            begin
              try
                exportar(frmProgress)
              finally
                frmProgress.Close;
              end;
            end
          );

  task.Start;
end;

procedure TfrmPrincipal.btnInserirClick(Sender: TObject);
begin
  inserir;
end;

procedure TfrmPrincipal.btnLimparClick(Sender: TObject);
begin
  fdqPessoa.Active   := False;
  fdqPessoa.SQL.Text := 'DELETE FROM PESSOA';
  fdqPessoa.ExecSQL;
  carregar;
end;

procedure TfrmPrincipal.btnSairClick(Sender: TObject);
begin
  Close;
end;

procedure TfrmPrincipal.carregar;
begin
  fdqPessoa.Active   := False;
  fdqPessoa.SQL.Text := 'SELECT * FROM PESSOA';
  _Controller.carregar(fdqPessoa);
end;

procedure TfrmPrincipal.exportar(ANotificator : INotificator = nil);
begin
  _Controller.exportar(fdqPessoa, ANotificator);
end;

procedure TfrmPrincipal.FormCreate(Sender: TObject);
begin
  _Controller := TPessoaController.Create;
end;

procedure TfrmPrincipal.FormDestroy(Sender: TObject);
begin
  FreeAndNil(_Controller);
end;

procedure TfrmPrincipal.inserir;
begin
  _Controller.inserir(fdqPessoa);
end;

end.
