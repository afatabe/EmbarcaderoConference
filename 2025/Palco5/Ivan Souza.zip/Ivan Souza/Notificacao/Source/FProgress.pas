unit FProgress;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.ComCtrls, Vcl.StdCtrls, Vcl.ExtCtrls,
  IInterfaces, System.threading;

type
  TfrmProgress = class(TForm, INotificator)
    Shape1: TShape;
    lblText: TLabel;
    lblDetailText: TLabel;
    progressBar: TProgressBar;
    { Private declarations }
  public
    procedure Notify(ANotification: INotification);
    { Public declarations }
  end;

var
  frmProgress: TfrmProgress;

implementation

{$R *.dfm}

{ TfrmProgress }

procedure TfrmProgress.Notify(ANotification: INotification);
begin
  TThread.Queue(nil, procedure
    begin
      progressBar.Max       := ANotification.maxPosition;
      progressBar.Position  := ANotification.CurrentPosition;
      lblText.Caption       := ANotification.Title;
      lblDetailText.Caption := ANotification.Description;
    end
  );
end;

end.
