unit uPessoaController;

interface

uses Datasnap.DBClient, System.Classes, System.SysUtils, Data.DB, IInterfaces, uInterfaces;

type TPessoaController = class
  private
    procedure Notifying(ANotification : INotification; ANotificator : INotificator);
  public
    procedure inserir (ADataSet: TDataSet);
    procedure carregar(ADataSet: TDataSet);
    procedure exportar(ADataSet: TDataSet; ANotificator : INotificator);
  end;

implementation

{ TPessoaController }

procedure TPessoaController.carregar(ADataSet: TDataSet);
begin
  ADataSet.Open;
end;

procedure TPessoaController.exportar(ADataSet: TDataSet; ANotificator : INotificator);
var
  arquivo      : TStringList;
  Notification : INotification;
begin
  arquivo := TStringList.Create;
  Notification := TNotificationFactory
                      .New
                      .CreateNotification
                      .Title('Exportando dados ...')
                      .MaxPosition(ADataSet.RecordCount);

  ADataSet.First;

  while not ADataSet.Eof do
  begin
    Notification
        .Description('Exportando registro ' + ADataSet.RecNo.ToString + ' de ' + ADataSet.RecordCount.ToString)
        .CurrentPosition(ADataSet.RecNo);

    Notifying(Notification, ANotificator);

    arquivo.Add(ADataSet.FieldByName('NOME').AsString  + ';' +
                ADataSet.FieldByName('EMAIL').AsString + ';' +
                ADataSet.FieldByName('LOGRADOURO').AsString);

    ADataSet.Next;
  end;

  arquivo.SaveToFile('pessoa.txt');
  FreeAndNil(arquivo);
end;

procedure TPessoaController.inserir(ADataSet: TDataSet);
var
  i      : Integer;
  numero : Integer;
  total  : Integer;
  nome   : String;
begin
  total := 5000;

  for I := 1 to total do
  begin
    numero := Random(total);

    ADataset.Append;
    ADataSet.FieldByName('NOME').AsString       := 'PESSOA ' + i.ToString + ' ' + numero.ToString;
    ADataSet.FieldByName('EMAIL').AsString      := ADataSet.FieldByName('NOME').AsString + '@gmail.com'.ToLower;
    ADataSet.FieldByName('LOGRADOURO').AsString := 'ENDERE�O ' + ADataSEt.FieldByName('NOME').AsString;
    ADataSet.Post;
  end;
end;

procedure TPessoaController.Notifying(ANotification: INotification; ANotificator: INotificator);
begin
  if Assigned(ANotification) then
    ANotificator.Notify(ANotification);
end;

end.
