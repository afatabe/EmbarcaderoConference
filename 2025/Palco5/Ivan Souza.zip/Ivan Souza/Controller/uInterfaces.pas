unit uInterfaces;

interface

uses IInterfaces;

type TNotification = class(TInterfacedObject, INotification)
  private
    FTitle       : String;
    FDescription : String;

    FCurrentPosition : Integer;
    FMaxPosition     : Integer;
  public
    function Title       : String; overload;
    function Description : String; overload;

    function CurrentPosition : Integer; overload;
    function MaxPosition     : Integer; overload;

    {Function to receive parameters}
    function Title(ATitle : String)             : INotification ; overload;
    function Description(ADescription : String) : INotification ; overload;

    function CurrentPosition(ACurrentPosition : Integer) : INotification; overload;
    function MaxPosition(AMaxPosition : Integer)         : INotification; overload;
end;

type TNotificationFactory = class(TInterfacedObject, INotificationFactory)
  public
    function CreateNotification : INotification;
    class function New : INotificationFactory;
end;

implementation

{ TNotification }

function TNotification.CurrentPosition(ACurrentPosition: Integer): INotification;
begin
  FCurrentPosition := ACurrentPosition;
  result := Self;
end;

function TNotification.CurrentPosition: Integer;
begin
  result := FCurrentPosition;
end;

function TNotification.Description: String;
begin
  result := FDescription;
end;

function TNotification.Description(ADescription: String): INotification;
begin
  FDescription := ADescription;
  result := Self;
end;

function TNotification.MaxPosition: Integer;
begin
  result := FMaxPosition;
end;

function TNotification.MaxPosition(AMaxPosition: Integer): INotification;
begin
  FMaxPosition := AMaxPosition;
  result := Self;
end;

function TNotification.Title(ATitle: String): INotification;
begin
  FTitle := ATitle;
  result := Self;
end;

function TNotification.Title: String;
begin
  result := FTitle;
end;



{ TNotificationFactory }

function TNotificationFactory.CreateNotification: INotification;
begin
  result := TNotification.Create;
end;

class function TNotificationFactory.New: INotificationFactory;
begin
  result := Self.Create;
end;

end.
