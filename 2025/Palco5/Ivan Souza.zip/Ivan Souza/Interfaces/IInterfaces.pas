unit IInterfaces;

interface

type INotification = Interface ['{918AA68D-801E-43E7-A782-BAB45342A1AE}']
  {Functions to inform values}
  function Title       : String; overload;
  function Description : String; overload;

  function CurrentPosition : Integer; overload;
  function MaxPosition     : Integer; overload;

  {Function to receive parameters}
  function Title(ATitle : String)             : INotification ; overload;
  function Description(ADescription : String) : INotification ; overload;

  function CurrentPosition(ACurrentPosition : Integer) : INotification; overload;
  function MaxPosition(AMaxPosition : Integer)         : INotification; overload;
end;

type INotificationFactory = Interface ['{07B88B5C-8AE3-459D-83A6-EACC4B241439}']
  function CreateNotification : INotification;
end;

type INotificator = Interface ['{CD1DBC8B-E264-45AA-A99E-9D1E094C1428}']
  procedure Show;
  procedure Close;
  procedure Notify(ANotification : INotification);
end;



implementation

end.
