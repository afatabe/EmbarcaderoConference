unit Main;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants,
  System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, IdBaseComponent, IdComponent,
  IdTCPConnection, IdTCPClient, IdHTTP, Vcl.ExtCtrls, IdContext,
  IdCustomHTTPServer, IdCustomTCPServer, IdHTTPServer, Vcl.StdCtrls,
  Web.HTTPApp, Web.Stencils, Data.DB, Datasnap.DBClient, FireDAC.Stan.Intf, FireDAC.Stan.Option, FireDAC.Stan.Param, FireDAC.Stan.Error, FireDAC.DatS,
  FireDAC.Phys.Intf, FireDAC.DApt.Intf, FireDAC.Comp.DataSet, FireDAC.Comp.Client, Vcl.Grids, Vcl.DBGrids;

type
  TForm1 = class(TForm)
    Panel1: TPanel;
    IdHTTPServer1: TIdHTTPServer;
    Panel2: TPanel;
    Panel3: TPanel;
    Memo1: TMemo;
    Panel4: TPanel;
    WebStencilsEngine1: TWebStencilsEngine;
    WebStencilsProcessor1: TWebStencilsProcessor;
    Button1: TButton;
    Button2: TButton;
    Splitter1: TSplitter;
    Splitter2: TSplitter;
    Panel5: TPanel;
    Panel6: TPanel;
    Splitter3: TSplitter;
    Memo2: TMemo;
    Button3: TButton;
    DBGrid1: TDBGrid;
    DataSource1: TDataSource;
    FDMemTable1: TFDMemTable;
    Button4: TButton;
    procedure IdHTTPServer1CommandGet(AContext: TIdContext; ARequestInfo: TIdHTTPRequestInfo; AResponseInfo: TIdHTTPResponseInfo);
    procedure FormCreate(Sender: TObject);
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure Button3Click(Sender: TObject);
    procedure Button4Click(Sender: TObject);
  private
    { Private declarations }
    procedure Cenario1();
    procedure Cenario2();
    procedure Cenario3();
    procedure Cenario4();
  public
    { Public declarations }
  end;

var
  Form1: TForm1;

implementation

{$R *.dfm}

procedure TForm1.Button1Click(Sender: TObject);
begin
  Self.Cenario1;
end;

procedure TForm1.Button2Click(Sender: TObject);
begin
  Self.Cenario2;
end;

procedure TForm1.Button3Click(Sender: TObject);
begin
  Self.Cenario3;
end;

procedure TForm1.Button4Click(Sender: TObject);
begin
  Self.Cenario4;
end;

procedure TForm1.Cenario1;
begin
  Self.Memo1.Clear;
  Self.Memo1.Lines.Add('<html>');
  Self.Memo1.Lines.Add('    <body>');
  Self.Memo1.Lines.Add('        <p>Ola Mundo</p>');
  Self.Memo1.Lines.Add('    </body>');
  Self.Memo1.Lines.Add('<html>');

  Self.Memo2.Clear;
end;

procedure TForm1.Cenario2;
begin
  Self.Memo1.Clear;
  Self.Memo1.Lines.Add('<html>');
  Self.Memo1.Lines.Add('    <head>');
  Self.Memo1.Lines.Add('        <script src="https://cdn.jsdelivr.net/npm/htmx.org@2.0.7/dist/htmx.min.js"');
  Self.Memo1.Lines.Add('                integrity="sha384-ZBXiYtYQ6hJ2Y0ZNoYuI+Nq5MqWBr+chMrS/RkXpNzQCApHEhOt2aY8EJgqwHLkJ"');
  Self.Memo1.Lines.Add('                crossorigin="anonymous"');
  Self.Memo1.Lines.Add('        ></script>');
  Self.Memo1.Lines.Add('    </head>');
  Self.Memo1.Lines.Add('    <body>');
  Self.Memo1.Lines.Add('');
  Self.Memo1.Lines.Add('        <button hx-get="/memo2"');
  Self.Memo1.Lines.Add('                hx-target="#conteudo"');
  Self.Memo1.Lines.Add('        >Me Clique</button>');
  Self.Memo1.Lines.Add('');
  Self.Memo1.Lines.Add('        <hr>');
  Self.Memo1.Lines.Add('');
  Self.Memo1.Lines.Add('        <div id="conteudo">');
  Self.Memo1.Lines.Add('            <p style="background-color: green">Este conteudo sera substituido</p>');
  Self.Memo1.Lines.Add('        </div>');
  Self.Memo1.Lines.Add('    </body>');
  Self.Memo1.Lines.Add('<html>');

  Self.Memo2.Clear;
  Self.Memo2.Lines.Add('<p style="background-color: yellow">');
  Self.Memo2.Lines.Add('    Oi! Eu vim la do servidor.');
  Self.Memo2.Lines.Add('</p>');
end;

procedure TForm1.Cenario3;
begin
  Self.Memo1.Clear;
  Self.Memo1.Lines.Add('<html>');
  Self.Memo1.Lines.Add('    <head>');
  Self.Memo1.Lines.Add('        <script src="https://cdn.jsdelivr.net/npm/htmx.org@2.0.7/dist/htmx.min.js"');
  Self.Memo1.Lines.Add('                integrity="sha384-ZBXiYtYQ6hJ2Y0ZNoYuI+Nq5MqWBr+chMrS/RkXpNzQCApHEhOt2aY8EJgqwHLkJ"');
  Self.Memo1.Lines.Add('                crossorigin="anonymous"');
  Self.Memo1.Lines.Add('        ></script>');
  Self.Memo1.Lines.Add('');
  Self.Memo1.Lines.Add('        <script src="https://unpkg.com/hyperscript.org@0.9.14"></script>');
  Self.Memo1.Lines.Add('    </head>');
  Self.Memo1.Lines.Add('    <body>');
  Self.Memo1.Lines.Add('        <button hx-get="/memo2"');
  Self.Memo1.Lines.Add('                hx-target="#dialog_content"');
  Self.Memo1.Lines.Add('                _="on click call #dialog_content.showModal()"');
  Self.Memo1.Lines.Add('        >Mostrar Dialogo</button>');
  Self.Memo1.Lines.Add('');
  Self.Memo1.Lines.Add('        <dialog id="dialog_content"></dialog>');
  Self.Memo1.Lines.Add('    </body>');
  Self.Memo1.Lines.Add('<html>');

  Self.Memo2.Clear;
  Self.Memo2.Lines.Add('<h3>Titulo</h3>');
  Self.Memo2.Lines.Add('<p>Linha 1</p>');
  Self.Memo2.Lines.Add('<p>Linha 2</p>');
end;

procedure TForm1.Cenario4;
begin
  Self.Memo1.Clear;
  Self.Memo1.Lines.Add('<html>');
  Self.Memo1.Lines.Add('    <head>');
  Self.Memo1.Lines.Add('        <script src="https://cdn.jsdelivr.net/npm/htmx.org@2.0.7/dist/htmx.min.js"');
  Self.Memo1.Lines.Add('                integrity="sha384-ZBXiYtYQ6hJ2Y0ZNoYuI+Nq5MqWBr+chMrS/RkXpNzQCApHEhOt2aY8EJgqwHLkJ"');
  Self.Memo1.Lines.Add('                crossorigin="anonymous"');
  Self.Memo1.Lines.Add('        ></script>');
  Self.Memo1.Lines.Add('');
  Self.Memo1.Lines.Add('        <script src="https://unpkg.com/hyperscript.org@0.9.14"></script>');
  Self.Memo1.Lines.Add('    </head>');
  Self.Memo1.Lines.Add('    <body>');
  Self.Memo1.Lines.Add('        <button hx-get="/memo2"');
  Self.Memo1.Lines.Add('                hx-target="#dialog_content"');
  Self.Memo1.Lines.Add('                _="on click call #dialog_content.showModal()"');
  Self.Memo1.Lines.Add('        >Mostrar Dialogo</button>');
  Self.Memo1.Lines.Add('');
  Self.Memo1.Lines.Add('        <dialog id="dialog_content"></dialog>');
  Self.Memo1.Lines.Add('    </body>');
  Self.Memo1.Lines.Add('<html>');

  Self.Memo2.Clear;
  Self.Memo2.Lines.Add('<table>');
  Self.Memo2.Lines.Add('    <tr>');
  Self.Memo2.Lines.Add('        <th>Nome</th>');
  Self.Memo2.Lines.Add('        <th>Idade</th>');
  Self.Memo2.Lines.Add('    </tr>');
  Self.Memo2.Lines.Add('');
  Self.Memo2.Lines.Add('    @ForEach (var pessoa in dataset) {');
  Self.Memo2.Lines.Add('        <tr>');
  Self.Memo2.Lines.Add('            <td>@pessoa.NOME</td>');
  Self.Memo2.Lines.Add('            <td>@pessoa.IDADE</td>');
  Self.Memo2.Lines.Add('        </tr>');
  Self.Memo2.Lines.Add('    }');
  Self.Memo2.Lines.Add('');
  Self.Memo2.Lines.Add('</table>');
end;

procedure TForm1.FormCreate(Sender: TObject);
begin
  Self.IdHTTPServer1.Active := True;
  Self.FDMemTable1.Open;
  Self.FDMemTable1.AppendRecord(['Alice', 30]);
  Self.FDMemTable1.AppendRecord(['Bruno', 25]);
  Self.FDMemTable1.AppendRecord(['Carla', 28]);
  Self.FDMemTable1.AppendRecord(['Diego', 35]);
  Self.FDMemTable1.AppendRecord(['Elaine', 22]);
  Self.FDMemTable1.AppendRecord(['Fabio', 40]);
  Self.FDMemTable1.AppendRecord(['Gabriela', 27]);
  Self.FDMemTable1.AppendRecord(['Henrique', 33]);
  Self.FDMemTable1.AppendRecord(['Isabela', 29]);
  Self.FDMemTable1.AppendRecord(['Jo�o', 31]);
end;

procedure TForm1.IdHTTPServer1CommandGet(AContext: TIdContext; ARequestInfo: TIdHTTPRequestInfo; AResponseInfo: TIdHTTPResponseInfo);
var
  uri: string;
begin
  uri := ARequestInfo.uri;

  if uri = '/' then
  begin

    Self.WebStencilsProcessor1.InputLines.Text := Self.Memo1.Text;
    AResponseInfo.ContentText := Self.WebStencilsProcessor1.Content;

  end
  else if uri = '/memo2' then
  begin

    Self.WebStencilsProcessor1.AddVar('dataset', Self.FDMemTable1, False);
    Self.WebStencilsProcessor1.InputLines.Text := Self.Memo2.Text;
    AResponseInfo.ContentText := Self.WebStencilsProcessor1.Content;

  end;

end;

end.
