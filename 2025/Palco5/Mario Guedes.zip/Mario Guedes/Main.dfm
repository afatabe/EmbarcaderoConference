object Form1: TForm1
  Left = 0
  Top = 0
  Caption = 'ECon25 - WebStencils + HTMX + Hyperscript'
  ClientHeight = 1138
  ClientWidth = 1600
  Color = clBtnFace
  Font.Charset = ANSI_CHARSET
  Font.Color = clWindowText
  Font.Height = -32
  Font.Name = 'Consolas'
  Font.Style = []
  WindowState = wsMaximized
  OnCreate = FormCreate
  TextHeight = 37
  object Splitter2: TSplitter
    Left = 761
    Top = 113
    Height = 1025
    Color = clRed
    ParentColor = False
    ExplicitLeft = 808
    ExplicitTop = 536
    ExplicitHeight = 100
  end
  object Panel1: TPanel
    Left = 0
    Top = 0
    Width = 1600
    Height = 113
    Align = alTop
    Caption = 'Panel1'
    Color = clRed
    ParentBackground = False
    ShowCaption = False
    TabOrder = 0
    ExplicitWidth = 1590
    object Button1: TButton
      Left = 32
      Top = 21
      Width = 257
      Height = 73
      Caption = 'Cenario 1'
      TabOrder = 0
      OnClick = Button1Click
    end
    object Button2: TButton
      Left = 295
      Top = 21
      Width = 257
      Height = 73
      Caption = 'Cenario 2'
      TabOrder = 1
      OnClick = Button2Click
    end
    object Button3: TButton
      Left = 558
      Top = 21
      Width = 257
      Height = 73
      Caption = 'Cenario 3'
      TabOrder = 2
      OnClick = Button3Click
    end
    object Button4: TButton
      Left = 821
      Top = 21
      Width = 257
      Height = 73
      Caption = 'Cenario 4'
      TabOrder = 3
      OnClick = Button4Click
    end
  end
  object Panel2: TPanel
    Left = 0
    Top = 113
    Width = 761
    Height = 1025
    Align = alLeft
    Caption = 'Panel2'
    ShowCaption = False
    TabOrder = 1
    object Memo1: TMemo
      Left = 1
      Top = 73
      Width = 759
      Height = 951
      Align = alClient
      ScrollBars = ssBoth
      TabOrder = 0
      ExplicitLeft = 0
      ExplicitTop = 79
    end
    object Panel4: TPanel
      Left = 1
      Top = 1
      Width = 759
      Height = 72
      Align = alTop
      Caption = 'Panel4'
      ShowCaption = False
      TabOrder = 1
      ExplicitWidth = 463
    end
  end
  object Panel3: TPanel
    Left = 764
    Top = 113
    Width = 836
    Height = 1025
    Align = alClient
    Caption = 'Panel3'
    ShowCaption = False
    TabOrder = 2
    ExplicitLeft = 984
    ExplicitTop = 736
    ExplicitWidth = 185
    ExplicitHeight = 41
    object Splitter1: TSplitter
      Left = 1
      Top = 490
      Height = 534
      ExplicitLeft = 296
      ExplicitTop = 96
      ExplicitHeight = 100
    end
    object Splitter3: TSplitter
      Left = 1
      Top = 481
      Width = 834
      Height = 9
      Cursor = crVSplit
      Align = alTop
      Color = clRed
      ParentColor = False
      ExplicitTop = 600
    end
    object Panel5: TPanel
      Left = 1
      Top = 1
      Width = 834
      Height = 480
      Align = alTop
      Caption = 'Panel5'
      TabOrder = 0
      object Memo2: TMemo
        Left = 1
        Top = 1
        Width = 832
        Height = 478
        Align = alClient
        Lines.Strings = (
          'Memo2')
        TabOrder = 0
        ExplicitTop = 5
        ExplicitHeight = 574
      end
    end
    object Panel6: TPanel
      Left = 4
      Top = 490
      Width = 831
      Height = 534
      Align = alClient
      Caption = 'Panel6'
      TabOrder = 1
      ExplicitTop = 586
      ExplicitHeight = 438
      object DBGrid1: TDBGrid
        Left = 1
        Top = 1
        Width = 829
        Height = 532
        Align = alClient
        DataSource = DataSource1
        TabOrder = 0
        TitleFont.Charset = ANSI_CHARSET
        TitleFont.Color = clWindowText
        TitleFont.Height = -32
        TitleFont.Name = 'Consolas'
        TitleFont.Style = []
      end
    end
  end
  object IdHTTPServer1: TIdHTTPServer
    Bindings = <>
    DefaultPort = 8080
    OnCommandGet = IdHTTPServer1CommandGet
    Left = 80
    Top = 880
  end
  object WebStencilsEngine1: TWebStencilsEngine
    PathTemplates = <>
    Left = 80
    Top = 1048
  end
  object WebStencilsProcessor1: TWebStencilsProcessor
    Engine = WebStencilsEngine1
    Left = 80
    Top = 960
  end
  object DataSource1: TDataSource
    DataSet = FDMemTable1
    Left = 1296
    Top = 1035
  end
  object FDMemTable1: TFDMemTable
    FieldDefs = <
      item
        Name = 'NOME'
        DataType = ftString
        Size = 20
      end
      item
        Name = 'IDADE'
        DataType = ftInteger
      end>
    IndexDefs = <>
    FetchOptions.AssignedValues = [evMode]
    FetchOptions.Mode = fmAll
    ResourceOptions.AssignedValues = [rvSilentMode]
    ResourceOptions.SilentMode = True
    UpdateOptions.AssignedValues = [uvCheckRequired, uvAutoCommitUpdates]
    UpdateOptions.CheckRequired = False
    UpdateOptions.AutoCommitUpdates = True
    StoreDefs = True
    Left = 1296
    Top = 960
  end
end
